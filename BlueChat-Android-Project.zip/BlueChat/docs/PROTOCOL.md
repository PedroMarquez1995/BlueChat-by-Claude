# Protocolo BlueChat Mesh v1

## Transporte BLE

- Servicio GATT `7b1e0001-5a3c-4f6e-9b21-bc1e5a0c0001`, anunciado en la publicidad BLE (sin nombre del dispositivo).
- Característica **RX** `…0002` (escritura): central → periférico.
- Característica **TX** `…0003` (notificación, con CCCD): periférico → central.
- Cada teléfono es a la vez servidor (periférico) y cliente (central). Pide MTU 247; la trama máxima es `MTU − 3`.
- El enlace se considera establecido cuando el cliente ha activado las notificaciones (CCCD).
- Si dos teléfonos se conectan entre sí a la vez, el motor conserva un único enlace: el iniciado por el nodo de menor ID.

## Tramas (fragmentación)

`fragId(2) | index(1) | total(1) | datos` — un paquete se divide en tramas de `maxFrame − 4` bytes de datos. El receptor reensambla por `fragId`, descarta duplicados e inconsistentes, caduca sesiones incompletas (30 s), limita sesiones (8) y bytes (≤ 1305).

## Paquete (big-endian)

| Offset | Bytes | Campo |
|---|---|---|
| 0 | 1 | versión (=1) |
| 1 | 1 | tipo: 1 HELLO, 2 DATA, 3 ACK |
| 2 | 1 | flags (bit0 = firmado) |
| 3 | 1 | ttl (mutable por repetidores) |
| 4 | 1 | hops (mutable por repetidores) |
| 5 | 8 | msgId aleatorio |
| 13 | 8 | origen (nodeId) |
| 21 | 8 | destino (nodeId; 0 = difusión, solo HELLO) |
| 29 | 8 | timestamp del emisor (ms) |
| 37 | 2 | validez en minutos (1–1440) |
| 39 | 2 | longitud del payload (≤ 1200) |
| 41 | n | payload |
| 41+n | 64 | firma Ed25519 |

`nodeId` = primeros 8 bytes de SHA-256(signPub ‖ dhPub). La firma cubre todo salvo `ttl`, `hops` y la longitud; el receptor valida que `nodeId` coincide con las claves incluidas.

### HELLO (payload)
`signPub(32) | dhPub(32) | caps(1) | avatar(1) | aliasLen(1) | alias`. Se emite al conectar y cada 30 s con TTL 3; los repetidores lo reenvían (así se aprenden nodos y rutas a más de un salto).

### DATA (payload)
`signPub(32) | dhPub(32) | sealed`. `sealed = nonce(12) ‖ ChaCha20-Poly1305(inner) ‖ tag(16)`; clave = HKDF-SHA256(X25519(mia, suya), salt = msgId, info = "bluechat/v1/msg" ‖ origen ‖ destino); AAD = cabecera inmutable. `inner = tipo(1)=1 ‖ texto UTF-8`.

### ACK (payload)
`sealed` con `inner = tipo(1) ‖ msgId acusado(8)`, tipo 2 = entregado, 3 = leído. Solo se acepta si la firma verifica con la clave del destinatario original y proviene de él.

## Reglas de reenvío

1. Descartar si versión/formato inválido, `hops ≥ maxHops`, origen bloqueado, duplicado (`origen‖msgId` ya visto) o excede el límite por origen.
2. DATA/ACK no dirigido a mí: validar firma y, si el repetidor está activado y `ttl > 0`, encolar (cifrado) y reenviar con `ttl−1`, `hops+1`.
3. Selección de siguiente salto: destino vecino directo → solo él; ruta aprendida válida → ese vecino; si no, hasta *fanout* vecinos (excluyendo el de origen y los ya servidos).
4. Reintento en olas (cada 20 s, hasta 4) mientras no haya ACK; caducidad a los `validityMin`.
5. Un mensaje se marca *Entregado* solo con un ACK verificado del destinatario.

## Anti-repetición
Caché de identificadores vistos (persistente), validez limitada, y el destinatario rechaza mensajes con timestamp futuro (> 10 min) o más viejos que su validez + 10 min.
