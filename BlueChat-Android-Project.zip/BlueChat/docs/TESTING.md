# Pruebas manuales con teléfonos reales

Las pruebas automatizadas no usan Bluetooth. Esta es la única forma de saber si la malla funciona de verdad.

## Material
Tres teléfonos Android 8+ con BLE (A, B, C), BlueChat instalado y perfil creado en los tres (nombres distintos: «A», «B», «C»). Permisos concedidos y **malla activada** en los tres (notificación «BlueChat activo»). Bluetooth encendido. Ahorro de batería de BlueChat excluido.

## 1. Dos teléfonos (A ↔ B)
1. A y B a 1–2 m. En **Cercanos** cada uno debe ver al otro como «Conexión directa» en ≤ 30 s.
2. A escribe a B. Esperado: A ve «Enviado al destinatario · sin confirmar» y enseguida «Entregado»; B recibe notificación y el mensaje.
3. B abre el chat: A pasa a «Leído».
4. Apaga Bluetooth en B, escribe de A a B: «Pendiente». Enciende B: debe entregarse solo.

## 2. Prueba principal (A – B – C)
1. Coloca A y C **fuera de alcance entre sí** (otra habitación / 15–30 m / obstáculos) y B en un punto que alcance a ambos. Comprueba en **Malla** de B: 2 vecinos directos.
2. En **Malla** de A: C debe aparecer en «Nodos conocidos indirectamente» (2 saltos, vía B) en ≤ 1–2 min. Si no aparece, A y C no se están viendo por B: revisa que B tenga «Retransmitir» activado.
3. A abre C desde **Cercanos** y envía «hola desde A».
4. Esperado: A → «En retransmisión · sin confirmar»; C recibe el texto (con «2 saltos»); A pasa a «Entregado».
5. Verifica que B **no** muestra el mensaje en ningún sitio y que su cola no crece tras la entrega.
6. Desactiva «Retransmitir» en B y repite: el mensaje NO debe llegar a C.
7. Mueve C fuera de B, envía de A a C y comprueba «En retransmisión»; vuelve C junto a B: el mensaje se entrega (store-and-forward) y A recibe «Entregado».

## 3. Recuperación
- Apaga y enciende Bluetooth en B: la malla debe reanudarse sola (la pantalla Malla indica el estado).
- Cierra BlueChat desde recientes en B (con malla activa): el servicio debe seguir; si el fabricante lo mata, reabre la app y comprueba que reanuda y que los mensajes en cola siguen.

## 4. Seguridad
- En **Contacto** compara la huella de 60 dígitos en ambos teléfonos y marca «verificado».
- Bloquea a un contacto: no debe poder entregarte mensajes.

## Qué anotar si algo falla
Modelo y versión de Android de cada teléfono; si «Cercanos» muestra a los demás; el texto de error en la pantalla Malla; contadores de la pantalla Malla (recibidos/duplicados/inválidos); si el fallo es de descubrimiento, de conexión o de entrega.
