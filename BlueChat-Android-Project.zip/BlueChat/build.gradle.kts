// Versiones reales y compatibles entre sí:
//  - Gradle 8.14.3 (wrapper) + AGP 8.9.1 (requiere Gradle >= 8.11.1 y JDK 17)
//  - Kotlin 2.0.21 + plugin del compilador de Compose (mismo número de versión)
//  - KSP 2.0.21-1.0.28 (versión de KSP que corresponde a Kotlin 2.0.21)
plugins {
    id("com.android.application") version "8.9.1" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
    id("com.google.devtools.ksp") version "2.0.21-1.0.28" apply false
}
