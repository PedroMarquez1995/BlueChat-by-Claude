package com.bluechat.mesh.core

import java.util.ArrayDeque

class TestClock(var t: Long = 1_760_000_000_000L) : WallClock {
    override fun now(): Long = t
    fun advance(ms: Long) { t += ms }
    fun advanceMinutes(m: Long) { t += m * 60_000L }
}

class RecordingListener : MeshListener {
    val messages = ArrayList<IncomingMessage>()
    val statuses = ArrayList<Triple<String, String, DeliveryStatus>>()
    override fun onMessageReceived(message: IncomingMessage) { messages += message }
    override fun onOutgoingStatus(msgId: String, peerNodeId: String, status: DeliveryStatus) {
        statuses += Triple(msgId, peerNodeId, status)
    }
    fun statusesOf(msgId: String): List<DeliveryStatus> = statuses.filter { it.first == msgId }.map { it.third }
    fun lastStatus(msgId: String): DeliveryStatus? = statusesOf(msgId).lastOrNull()
}

/** Nodo de prueba: motor real + almacenamiento en memoria + listener que registra eventos. */
class SimNode(
    val name: String,
    val net: SimNetwork,
    config: MeshConfig = MeshConfig(),
    val store: InMemoryMeshStore = InMemoryMeshStore(),
    val keys: IdentityKeys = CryptoManager.generateIdentity()
) {
    val listener = RecordingListener()
    var engine: MeshEngine = createEngine(config)
    val id: String get() = keys.nodeId

    fun createEngine(config: MeshConfig): MeshEngine =
        MeshEngine(keys, Profile(name, 1), store, net.clock, config).also { it.listener = listener }

    /** Simula reinicio del proceso conservando almacenamiento e identidad. */
    fun restart(config: MeshConfig = engine.getConfig()) {
        engine = createEngine(config)
    }
}

/**
 * Red simulada en memoria: transporta tramas reales entre motores reales. NO sustituye a las
 * pruebas con teléfonos reales; solo permite verificar el protocolo sin hardware.
 */
class SimNetwork(val clock: TestClock = TestClock()) {
    private class Pending(val to: SimNode, val linkId: String, val frame: ByteArray)

    inner class SimLink(
        override val id: String,
        override val initiatedLocally: Boolean,
        override val maxFrameBytes: Int,
        val owner: SimNode,
        val remote: SimNode
    ) : Link {
        var peer: SimLink? = null
        var closed = false
        override val rssi: Int? = -60

        override fun send(frame: ByteArray): Boolean {
            if (closed) return false
            val p = peer ?: return false
            var f = frame
            tamper?.let { f = it(owner, remote, frame) }
            log += Triple(owner.name, remote.name, frame.copyOf())
            queue.add(Pending(remote, p.id, f))
            return true
        }

        override fun close() {
            if (closed) return
            closed = true
            peer?.closed = true
            // El transporte real notifica la caída de ambos extremos.
            pendingDown += this
            peer?.let { pendingDown += it }
        }
    }

    private val queue = ArrayDeque<Pending>()
    private val pendingDown = ArrayList<SimLink>()
    private val links = ArrayList<Pair<SimLink, SimLink>>()
    var tamper: ((SimNode, SimNode, ByteArray) -> ByteArray)? = null
    val log = ArrayList<Triple<String, String, ByteArray>>()
    private var counter = 0

    fun node(name: String, config: MeshConfig = MeshConfig()) = SimNode(name, this, config)

    fun connect(a: SimNode, b: SimNode, mtuFrame: Int = 100, initiator: SimNode = a): Pair<SimLink, SimLink> {
        counter++
        val la = SimLink("${a.name}>${b.name}#$counter", initiator === a, mtuFrame, a, b)
        val lb = SimLink("${b.name}<${a.name}#$counter", initiator === b, mtuFrame, b, a)
        la.peer = lb
        lb.peer = la
        links += la to lb
        a.engine.onLinkUp(la)
        b.engine.onLinkUp(lb)
        pump()
        return la to lb
    }

    fun disconnect(a: SimNode, b: SimNode) {
        val it = links.iterator()
        while (it.hasNext()) {
            val (la, lb) = it.next()
            if ((la.owner === a && lb.owner === b) || (la.owner === b && lb.owner === a)) {
                la.closed = true
                lb.closed = true
                la.owner.engine.onLinkDown(la.id)
                lb.owner.engine.onLinkDown(lb.id)
                it.remove()
            }
        }
        queue.removeAll { true }
    }

    /** Reparte tramas hasta que la red queda en reposo. */
    fun pump(maxSteps: Int = 100_000) {
        var steps = 0
        while (steps++ < maxSteps) {
            val p = queue.poll()
            if (p != null) {
                p.to.engine.onFrame(p.linkId, p.frame)
                continue
            }
            if (pendingDown.isNotEmpty()) {
                val d = ArrayList(pendingDown)
                pendingDown.clear()
                d.forEach { it.owner.engine.onLinkDown(it.id) }
                continue
            }
            return
        }
        error("La red simulada no se estabiliza (¿bucle?)")
    }

    fun tickAll(vararg nodes: SimNode) {
        nodes.forEach { it.engine.tick() }
        pump()
    }

    fun framesBetween(from: String, to: String): List<ByteArray> =
        log.filter { it.first == from && it.second == to }.map { it.third }
}
