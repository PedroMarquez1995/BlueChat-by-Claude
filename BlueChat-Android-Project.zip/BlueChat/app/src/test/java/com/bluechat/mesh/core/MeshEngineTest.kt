package com.bluechat.mesh.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Pruebas del motor con transporte simulado (no requieren hardware Bluetooth). */
class MeshEngineTest {

    /** Simula que [a] ya conoce a [b] (p. ej. contacto añadido antes por cercanía). */
    private fun introduce(a: SimNode, b: SimNode) {
        a.store.putNode(NodeRecord(b.id, b.name, 1, b.keys.signPub, b.keys.dhPub, true, 0L, isContact = true))
    }

    private fun send(from: SimNode, to: SimNode, text: String): String {
        val r = from.engine.sendText(to.id, text)
        assertTrue("envío: $r", r is SendResult.Queued)
        return (r as SendResult.Queued).msgId
    }

    @Test fun `dos nodos directos - mensaje cifrado, entrega y confirmacion`() {
        val net = SimNetwork()
        val a = net.node("A"); val b = net.node("B")
        net.connect(a, b)

        val id = send(a, b, "hola B")
        net.pump()

        assertEquals(listOf("hola B"), b.listener.messages.map { it.text })
        assertEquals(a.id, b.listener.messages[0].from)
        val states = a.listener.statusesOf(id)
        assertEquals(listOf(DeliveryStatus.PENDING, DeliveryStatus.SENT, DeliveryStatus.DELIVERED), states)
        assertEquals(0, a.store.queueSize()) // la cola se vacía al confirmar
    }

    @Test fun `prueba principal A-B-C - B retransmite, C descifra y A recibe confirmacion`() {
        val net = SimNetwork()
        val a = net.node("A"); val b = net.node("B"); val c = net.node("C")
        net.connect(a, b)
        net.connect(b, c)
        // A y C no tienen enlace directo.
        assertTrue(a.engine.neighbors().none { it.nodeId == c.id })

        // A descubre a C por el HELLO retransmitido por B.
        val infoC = a.engine.knownNodes().first { it.nodeId == c.id }
        assertFalse(infoC.direct)
        assertEquals(2, infoC.hops)
        assertEquals(b.id, infoC.viaNodeId)

        val secret = "mensaje secreto de A para C"
        val id = send(a, c, secret)
        net.pump()

        // C lo recibe y descifra; B (intermediario) no ve ningún mensaje.
        assertEquals(listOf(secret), c.listener.messages.map { it.text })
        assertEquals(2, c.listener.messages[0].hops)
        assertTrue(b.listener.messages.isEmpty())
        // La cola/almacenamiento de B no contiene el texto en claro.
        b.store.getQueue().forEach { assertFalse(String(it.packet, Charsets.ISO_8859_1).contains("secreto")) }
        net.log.forEach { assertFalse(String(it.third, Charsets.ISO_8859_1).contains("secreto")) }

        // Estados: A pasa por RELAYING (lo recibió un intermediario) y solo entonces DELIVERED.
        val states = a.listener.statusesOf(id)
        assertEquals(DeliveryStatus.PENDING, states.first())
        assertTrue(DeliveryStatus.RELAYING in states)
        assertFalse(DeliveryStatus.SENT in states)
        assertEquals(DeliveryStatus.DELIVERED, states.last())
        assertTrue(states.indexOf(DeliveryStatus.RELAYING) < states.indexOf(DeliveryStatus.DELIVERED))
    }

    @Test fun `no se marca entregado mientras el destino no confirma`() {
        val net = SimNetwork()
        val a = net.node("A"); val b = net.node("B"); val c = net.node("C")
        net.connect(a, b)
        net.connect(b, c)
        net.disconnect(b, c)          // C desaparece; B aún conoce a C por su HELLO
        net.pump()

        val id = send(a, c, "¿sigues ahí?")
        net.pump()

        assertTrue(c.listener.messages.isEmpty())
        val last = a.listener.lastStatus(id)
        assertTrue("estado=$last", last == DeliveryStatus.RELAYING)
        assertFalse(DeliveryStatus.DELIVERED in a.listener.statusesOf(id))
        assertEquals(1, b.store.queueSize())     // B lo conserva (store-and-forward)
    }

    @Test fun `store-and-forward - B guarda el mensaje hasta que reaparece C`() {
        val net = SimNetwork()
        val a = net.node("A"); val b = net.node("B"); val c = net.node("C")
        net.connect(a, b)
        net.connect(b, c)
        net.disconnect(b, c)
        net.pump()

        val id = send(a, c, "te espero")
        net.pump()
        assertTrue(c.listener.messages.isEmpty())

        net.connect(b, c)                         // C vuelve a estar al alcance de B
        net.pump()

        assertEquals(listOf("te espero"), c.listener.messages.map { it.text })
        assertEquals(DeliveryStatus.DELIVERED, a.listener.lastStatus(id))
        assertEquals(0, b.store.queueSize())
    }

    @Test fun `cadena de 4 nodos A-B-C-D`() {
        val net = SimNetwork()
        val a = net.node("A"); val b = net.node("B"); val c = net.node("C"); val d = net.node("D")
        net.connect(a, b); net.connect(b, c); net.connect(c, d)
        val id = send(a, d, "hasta D")
        net.pump()
        assertEquals(listOf("hasta D"), d.listener.messages.map { it.text })
        assertEquals(3, d.listener.messages[0].hops)
        assertEquals(DeliveryStatus.DELIVERED, a.listener.lastStatus(id))
    }

    @Test fun `un mensaje solo se entrega una vez aunque se reciban duplicados`() {
        val net = SimNetwork()
        val a = net.node("A"); val b = net.node("B")
        val (la, lb) = net.connect(a, b)
        send(a, b, "único")
        net.pump()
        // Se reinyectan todas las tramas que A envió a B
        net.framesBetween("A", "B").forEach { b.engine.onFrame(lb.id, it) }
        net.pump()
        assertEquals(1, b.listener.messages.size)
        assertTrue(b.engine.stats().duplicatesDropped > 0)
    }

    @Test fun `topologia con ciclo - sin bucles ni duplicados`() {
        val net = SimNetwork()
        val a = net.node("A"); val b = net.node("B"); val c = net.node("C"); val d = net.node("D")
        net.connect(a, b); net.connect(b, c); net.connect(c, a)   // triángulo
        net.connect(c, d)
        val id = send(a, d, "por el ciclo")
        net.pump()
        assertEquals(1, d.listener.messages.size)
        assertEquals(DeliveryStatus.DELIVERED, a.listener.lastStatus(id))
        // Ningún nodo intermedio entrega el mensaje a su aplicación
        assertTrue(b.listener.messages.isEmpty() && c.listener.messages.isEmpty())
    }

    @Test fun `limite de saltos - no llega si supera maxHops`() {
        val net = SimNetwork()
        val cfg = MeshConfig(maxHops = 2)
        val n = (0..4).map { net.node("N$it", cfg) }
        for (i in 0 until 4) net.connect(n[i], n[i + 1])
        introduce(n[0], n[4])
        val id = send(n[0], n[4], "demasiado lejos")
        net.pump()
        assertTrue(n[4].listener.messages.isEmpty())
        assertFalse(DeliveryStatus.DELIVERED in n[0].listener.statusesOf(id))
        // ...pero con el límite por defecto (6) sí llega
        val net2 = SimNetwork()
        val m = (0..4).map { net2.node("M$it") }
        for (i in 0 until 4) net2.connect(m[i], m[i + 1])
        introduce(m[0], m[4]); introduce(m[4], m[0])
        send(m[0], m[4], "alcanzable")
        net2.pump()
        assertEquals(1, m[4].listener.messages.size)
    }

    @Test fun `caducidad - mensaje sin ruta pasa a FAILED y se elimina de la cola`() {
        val net = SimNetwork()
        val a = net.node("A"); val b = net.node("B")
        net.connect(a, b)
        net.disconnect(a, b)
        val id = send(a, b, "nadie escucha")
        net.pump()
        assertEquals(DeliveryStatus.PENDING, a.listener.lastStatus(id))
        assertEquals(1, a.store.queueSize())

        net.clock.advanceMinutes(1441)
        a.engine.tick()
        assertEquals(DeliveryStatus.FAILED, a.listener.lastStatus(id))
        assertEquals(0, a.store.queueSize())
    }

    @Test fun `caducidad - un repetidor descarta lo que no pudo entregar`() {
        val net = SimNetwork()
        val a = net.node("A"); val b = net.node("B"); val c = net.node("C")
        net.connect(a, b); net.connect(b, c); net.disconnect(b, c); net.pump()
        send(a, c, "caduca en B")
        net.pump()
        assertEquals(1, b.store.queueSize())
        net.clock.advanceMinutes(1500)
        b.engine.tick()
        assertEquals(0, b.store.queueSize())
    }

    @Test fun `la cola persiste y sobrevive al reinicio del motor`() {
        val net = SimNetwork()
        val a = net.node("A"); val b = net.node("B")
        net.connect(a, b)
        net.disconnect(a, b)
        val id = send(a, b, "sobrevivo al reinicio")
        assertEquals(1, a.store.queueSize())

        a.restart()                                  // mismo store e identidad, motor nuevo
        net.connect(a, b)                            // reconexión -> se entrega lo pendiente
        net.pump()

        assertEquals(listOf("sobrevivo al reinicio"), b.listener.messages.map { it.text })
        assertEquals(DeliveryStatus.DELIVERED, a.listener.lastStatus(id))
    }

    @Test fun `un repetidor malicioso que altera el paquete no logra entregar nada`() {
        val net = SimNetwork()
        val a = net.node("A"); val b = net.node("B"); val c = net.node("C")
        net.connect(a, b); net.connect(b, c)
        // B corrompe todo lo que envía a C
        net.tamper = { from, to, frame ->
            if (from === b && to === c && frame.size > 30) frame.copyOf().also { it[frame.size - 5] = (it[frame.size - 5].toInt() xor 0x55).toByte() } else frame
        }
        val id = send(a, c, "intacto o nada")
        net.pump()
        assertTrue(c.listener.messages.isEmpty())
        assertFalse(DeliveryStatus.DELIVERED in a.listener.statusesOf(id))
    }

    @Test fun `repeticion tardia de un paquete capturado es rechazada`() {
        val net = SimNetwork()
        val a = net.node("A"); val b = net.node("B")
        val (_, lb) = net.connect(a, b)
        send(a, b, "una sola vez")
        net.pump()
        assertEquals(1, b.listener.messages.size)
        val captured = net.framesBetween("A", "B")

        net.clock.advanceMinutes(60L * 48)           // 2 días después
        b.engine.tick()                              // purga la caché de vistos
        captured.forEach { b.engine.onFrame(lb.id, it) }
        net.pump()
        assertEquals(1, b.listener.messages.size)    // no se vuelve a entregar
    }

    @Test fun `un destinatario no entrega mensajes de contactos bloqueados`() {
        val net = SimNetwork()
        val a = net.node("A"); val b = net.node("B")
        net.connect(a, b)
        b.engine.setBlocked(a.id, true)
        send(a, b, "no me molestes")
        net.pump()
        assertTrue(b.listener.messages.isEmpty())
    }

    @Test fun `limite de tasa frena un flujo abusivo`() {
        val net = SimNetwork()
        val a = net.node("A", MeshConfig(maxQueue = 1000)); val b = net.node("B")
        net.connect(a, b)
        repeat(120) { send(a, b, "spam $it") }
        net.pump()
        assertTrue(b.listener.messages.size < 120)
        assertTrue(b.engine.stats().rateLimited > 0)
    }

    @Test fun `el modo repetidor desactivado no retransmite`() {
        val net = SimNetwork()
        val a = net.node("A"); val c = net.node("C")
        val b = net.node("B", MeshConfig(relayEnabled = false))
        net.connect(a, b); net.connect(b, c)
        introduce(a, c)
        send(a, c, "¿pasará?")
        net.pump()
        assertTrue(c.listener.messages.isEmpty())
        assertEquals(0, b.store.queueSize())
    }

    @Test fun `destinatario desconocido, vacio o demasiado largo`() {
        val net = SimNetwork()
        val a = net.node("A"); val b = net.node("B")
        assertTrue(a.engine.sendText(b.id, "hola") is SendResult.UnknownRecipient)
        net.connect(a, b)
        assertTrue(a.engine.sendText(b.id, "   ") is SendResult.Empty)
        assertTrue(a.engine.sendText(b.id, "x".repeat(601)) is SendResult.TooLong)
    }

    @Test fun `con MTU minimo (frames de 20 bytes) la fragmentacion funciona de extremo a extremo`() {
        val net = SimNetwork()
        val a = net.node("A"); val b = net.node("B"); val c = net.node("C")
        net.connect(a, b, mtuFrame = 20); net.connect(b, c, mtuFrame = 20)
        val text = "mensaje largo con acentos áéíóú ñ y emoji 😀 ".repeat(8)
        val id = send(a, c, text)
        net.pump()
        assertEquals(listOf(text), c.listener.messages.map { it.text })
        assertEquals(DeliveryStatus.DELIVERED, a.listener.lastStatus(id))
    }

    @Test fun `enlaces duplicados con el mismo vecino convergen en uno solo`() {
        val net = SimNetwork()
        val a = net.node("A"); val b = net.node("B")
        net.connect(a, b, initiator = a)
        net.connect(a, b, initiator = b)
        net.pump()
        assertEquals(1, a.engine.neighbors().count { it.nodeId == b.id })
        assertEquals(1, b.engine.neighbors().count { it.nodeId == a.id })
        send(a, b, "sigue funcionando")
        net.pump()
        assertEquals(1, b.listener.messages.size)
    }

    @Test fun `confirmacion de lectura marca el mensaje como leido`() {
        val net = SimNetwork()
        val a = net.node("A"); val b = net.node("B")
        net.connect(a, b)
        val id = send(a, b, "léeme")
        net.pump()
        b.engine.sendReadReceipt(a.id, id)
        net.pump()
        assertEquals(DeliveryStatus.READ, a.listener.lastStatus(id))
    }

    @Test fun `un ACK falsificado por un intermediario no confirma la entrega`() {
        val net = SimNetwork()
        val a = net.node("A"); val b = net.node("B"); val c = net.node("C")
        net.connect(a, b); net.connect(b, c); net.disconnect(b, c); net.pump()
        val id = send(a, c, "¿llegó?")
        net.pump()
        // B intenta fabricar un ACK "de C" usando sus propias claves: A debe rechazarlo.
        val forged = ForgedAck.build(b.keys, c.id, a.id, id, a.store.getNode(c.id)!!.dhPub, net.clock.now())
        val lb = net.framesBetween("B", "A") // enlace B->A existe; se inyecta directamente
        val linkId = a.engine.neighbors().first { it.nodeId == b.id }.linkId
        Fragmenter.split(forged, 100, 999).forEach { a.engine.onFrame(linkId, it) }
        net.pump()
        assertFalse(DeliveryStatus.DELIVERED in a.listener.statusesOf(id))
        assertNotNull(lb)
    }
}

/** Fabrica un ACK con origen suplantado (firmado con una clave ajena) para la prueba anterior. */
object ForgedAck {
    fun build(attacker: IdentityKeys, spoofedOrigin: String, dest: String, ackedMsgId: String, destDhPub: ByteArray, now: Long): ByteArray {
        val msgId = ByteArray(8) { (it + 1).toByte() }
        val draft = MeshPacket(1, PacketType.ACK, 0, 6, 0, msgId, Hex.decode(spoofedOrigin), Hex.decode(dest),
            now, 360, ByteArray(0), null)
        val inner = byteArrayOf(InnerKind.ACK_DELIVERED.toByte()) + Hex.decode(ackedMsgId)
        val sealed = CryptoManager.seal(inner, attacker.dhPriv, destDhPub, msgId, spoofedOrigin, dest, draft.authHeader())!!
        val p = MeshPacket(1, PacketType.ACK, 0, 6, 0, msgId, Hex.decode(spoofedOrigin), Hex.decode(dest), now, 360, sealed, null)
        return p.withSignature(CryptoManager.sign(attacker.signPriv, p.signedBytes())).encode()
    }
}

class MeshRouterTest {
    private fun n(id: String, seen: Long = 0) = NeighborView("l-$id", id, seen)

    @Test fun `prefiere unicast al destino directo`() {
        val r = MeshRouter(60_000)
        val sel = r.select("D", listOf(n("X"), n("D"), n("Y")), null, emptySet(), 0, 2)
        assertEquals(listOf("D"), sel.map { it.nodeId })
    }

    @Test fun `usa la ruta aprendida y si no inunda con fanout limitado`() {
        val r = MeshRouter(60_000)
        val nb = listOf(n("X", 1), n("Y", 3), n("Z", 2))
        assertEquals(listOf("Y", "Z"), r.select("D", nb, null, emptySet(), 0, 2).map { it.nodeId })
        r.learnRoute("D", "X", 3, 0)
        assertEquals(listOf("X"), r.select("D", nb, null, emptySet(), 10, 2).map { it.nodeId })
        r.forgetVia("X")
        assertEquals(2, r.select("D", nb, null, emptySet(), 10, 2).size)
    }

    @Test fun `excluye el origen y los vecinos ya servidos - evita bucles`() {
        val r = MeshRouter(60_000)
        val nb = listOf(n("X"), n("Y"))
        assertEquals(listOf("Y"), r.select("D", nb, "X", emptySet(), 0, 5).map { it.nodeId })
        assertTrue(r.select("D", nb, "X", setOf("Y"), 0, 5).isEmpty())
    }

    @Test fun `las rutas caducan`() {
        val r = MeshRouter(1000)
        r.learnRoute("D", "X", 2, 0)
        assertNotNull(r.routeFor("D", 500))
        assertEquals(null, r.routeFor("D", 2000))
    }
}
