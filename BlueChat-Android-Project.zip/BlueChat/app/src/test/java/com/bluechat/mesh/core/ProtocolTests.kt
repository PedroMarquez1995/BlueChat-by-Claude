package com.bluechat.mesh.core

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.SecureRandom

class MeshPacketTest {
    private val rnd = SecureRandom()
    private fun id(): ByteArray = ByteArray(8).also { rnd.nextBytes(it); it[0] = 1 }

    private fun sample(type: Int = PacketType.DATA, payload: ByteArray = ByteArray(40) { it.toByte() }) = MeshPacket(
        1, type, 0, 5, 0, id(), id(), id(), 1_700_000_000_000L, 1440, payload, null
    )

    @Test fun `serializa y deserializa sin perdida`() {
        val keys = CryptoManager.generateIdentity()
        val p = sample()
        val signed = p.withSignature(CryptoManager.sign(keys.signPriv, p.signedBytes()))
        val d = MeshPacket.decode(signed.encode())
        assertNotNull(d)
        d!!
        assertEquals(signed.type, d.type)
        assertEquals(signed.ttl, d.ttl)
        assertEquals(signed.timestamp, d.timestamp)
        assertEquals(signed.validityMin, d.validityMin)
        assertArrayEquals(signed.msgId, d.msgId)
        assertArrayEquals(signed.origin, d.origin)
        assertArrayEquals(signed.dest, d.dest)
        assertArrayEquals(signed.payload, d.payload)
        assertArrayEquals(signed.signature, d.signature)
        assertEquals(signed.key, d.key)
    }

    @Test fun `rechaza paquetes malformados sin lanzar excepciones`() {
        val good = sample().encode()
        assertNull(MeshPacket.decode(ByteArray(0)))
        assertNull(MeshPacket.decode(good.copyOf(10)))
        assertNull(MeshPacket.decode(good.copyOf(good.size - 1)))
        assertNull(MeshPacket.decode(good + byteArrayOf(0)))
        val badVersion = good.copyOf().also { it[0] = 9 }
        assertNull(MeshPacket.decode(badVersion))
        val badType = good.copyOf().also { it[1] = 77 }
        assertNull(MeshPacket.decode(badType))
        val badFlags = good.copyOf().also { it[2] = 0x80.toByte() }
        assertNull(MeshPacket.decode(badFlags))
        val badTtl = good.copyOf().also { it[3] = 120 }
        assertNull(MeshPacket.decode(badTtl))
        // Basura aleatoria
        repeat(500) {
            val junk = ByteArray(rnd.nextInt(200) + 1).also { b -> rnd.nextBytes(b) }
            MeshPacket.decode(junk) // no debe lanzar
        }
    }

    @Test fun `rechaza DATA dirigido a difusion y validez fuera de rango`() {
        val bcast = MeshPacket(1, PacketType.DATA, 0, 3, 0, id(), id(), Hex.decode(NodeIds.BROADCAST),
            1_700_000_000_000L, 10, ByteArray(5), null)
        assertNull(MeshPacket.decode(bcast.encode()))
        val zero = MeshPacket(1, PacketType.DATA, 0, 3, 0, id(), id(), id(), 1_700_000_000_000L, 0, ByteArray(5), null)
        assertNull(MeshPacket.decode(zero.encode()))
        val big = MeshPacket(1, PacketType.DATA, 0, 3, 0, id(), id(), id(), 1_700_000_000_000L, 5000, ByteArray(5), null)
        assertNull(MeshPacket.decode(big.encode()))
    }

    @Test fun `la firma cubre el contenido pero no ttl ni hops`() {
        val keys = CryptoManager.generateIdentity()
        val p = sample()
        val signed = p.withSignature(CryptoManager.sign(keys.signPriv, p.signedBytes()))
        val relayed = signed.withHop()
        assertNotEquals(signed.ttl, relayed.ttl)
        assertTrue(CryptoManager.verify(keys.signPub, relayed.signedBytes(), relayed.signature!!))
        // Manipular el payload invalida la firma
        val tamperedPayload = signed.payload.copyOf().also { it[0] = (it[0] + 1).toByte() }
        val tampered = MeshPacket(1, signed.type, signed.flags, signed.ttl, signed.hops, signed.msgId,
            signed.origin, signed.dest, signed.timestamp, signed.validityMin, tamperedPayload, signed.signature)
        assertFalse(CryptoManager.verify(keys.signPub, tampered.signedBytes(), tampered.signature!!))
        // Cambiar el destino también
        val redirected = MeshPacket(1, signed.type, signed.flags, signed.ttl, signed.hops, signed.msgId,
            signed.origin, id(), signed.timestamp, signed.validityMin, signed.payload, signed.signature)
        assertFalse(CryptoManager.verify(keys.signPub, redirected.signedBytes(), redirected.signature!!))
    }
}

class FragmenterTest {
    private val clock = TestClock()
    private fun data(n: Int) = ByteArray(n) { (it * 7).toByte() }

    @Test fun `fragmenta y reconstruye con distintos MTU`() {
        for (frame in listOf(8, 20, 64, 185, 244)) {
            for (size in listOf(1, 3, 16, 17, 200, 1000, 1300)) {
                val chunk = frame - Fragmenter.FRAME_HEADER
                if ((size + chunk - 1) / chunk > Fragmenter.MAX_FRAGMENTS) continue
                val frames = Fragmenter.split(data(size), frame, 77)
                assertTrue(frames.all { it.size <= frame })
                val r = Reassembler(clock)
                var out: ByteArray? = null
                frames.forEachIndexed { i, f ->
                    val res = r.accept(f)
                    if (i < frames.size - 1) assertNull(res) else out = res
                }
                assertArrayEquals("frame=$frame size=$size", data(size), out)
            }
        }
    }

    @Test fun `reconstruye tramas desordenadas y descarta duplicadas`() {
        val frames = Fragmenter.split(data(300), 40, 5).toMutableList()
        frames.shuffle(java.util.Random(3))
        val r = Reassembler(clock)
        var out: ByteArray? = null
        for (f in frames) {
            val res = r.accept(f)
            if (res != null) out = res
            // Reenviar la misma trama no debe romper nada
            if (out == null) assertNull(r.accept(f))
        }
        assertArrayEquals(data(300), out)
    }

    @Test fun `sesiones intercaladas no se mezclan`() {
        val a = Fragmenter.split(data(100), 20, 1)
        val b = Fragmenter.split(data(100).reversedArray(), 20, 2)
        val r = Reassembler(clock)
        var ra: ByteArray? = null
        var rb: ByteArray? = null
        for (i in a.indices) {
            r.accept(a[i])?.let { ra = it }
            r.accept(b[i])?.let { rb = it }
        }
        assertArrayEquals(data(100), ra)
        assertArrayEquals(data(100).reversedArray(), rb)
    }

    @Test fun `caduca sesiones incompletas y limita el numero`() {
        val r = Reassembler(clock, maxSessions = 3, timeoutMs = 1000)
        for (id in 1..10) r.accept(Fragmenter.split(data(100), 20, id)[0])
        assertTrue(r.pendingSessions() <= 3)
        clock.advance(5000)
        r.purge()
        assertEquals(0, r.pendingSessions())
    }

    @Test fun `rechaza tramas inconsistentes o excesivas`() {
        val r = Reassembler(clock, maxBytes = 100)
        assertNull(r.accept(byteArrayOf(0, 1, 5, 3, 9, 9)))          // index >= total
        assertNull(r.accept(byteArrayOf(0, 1, 0, 0, 9, 9)))          // total = 0
        assertNull(r.accept(byteArrayOf(0, 1)))                      // demasiado corta
        val big = Fragmenter.split(data(400), 30, 9)
        var out: ByteArray? = null
        big.forEach { r.accept(it)?.let { o -> out = o } }
        assertNull(out)                                              // supera maxBytes
    }
}

class CryptoManagerTest {
    private val alice = CryptoManager.generateIdentity()
    private val bob = CryptoManager.generateIdentity()
    private val eve = CryptoManager.generateIdentity()
    private val msgId = ByteArray(8) { it.toByte() }
    private val aad = "cabecera".toByteArray()

    @Test fun `cifra y descifra entre dos usuarios`() {
        val plain = "hola mesh".toByteArray()
        val sealed = CryptoManager.seal(plain, alice.dhPriv, bob.dhPub, msgId, alice.nodeId, bob.nodeId, aad)!!
        assertEquals(plain.size + CryptoManager.SEAL_OVERHEAD, sealed.size)
        val opened = CryptoManager.open(sealed, bob.dhPriv, alice.dhPub, msgId, alice.nodeId, bob.nodeId, aad)
        assertArrayEquals(plain, opened)
    }

    @Test fun `un tercero no puede descifrar`() {
        val sealed = CryptoManager.seal("secreto".toByteArray(), alice.dhPriv, bob.dhPub, msgId, alice.nodeId, bob.nodeId, aad)!!
        assertNull(CryptoManager.open(sealed, eve.dhPriv, alice.dhPub, msgId, alice.nodeId, bob.nodeId, aad))
        assertNull(CryptoManager.open(sealed, eve.dhPriv, bob.dhPub, msgId, alice.nodeId, bob.nodeId, aad))
    }

    @Test fun `detecta manipulacion del texto cifrado, la cabecera o el msgId`() {
        val sealed = CryptoManager.seal("integridad".toByteArray(), alice.dhPriv, bob.dhPub, msgId, alice.nodeId, bob.nodeId, aad)!!
        for (i in sealed.indices) {
            val t = sealed.copyOf().also { it[i] = (it[i].toInt() xor 1).toByte() }
            assertNull("byte $i", CryptoManager.open(t, bob.dhPriv, alice.dhPub, msgId, alice.nodeId, bob.nodeId, aad))
        }
        assertNull(CryptoManager.open(sealed, bob.dhPriv, alice.dhPub, msgId, alice.nodeId, bob.nodeId, "otra".toByteArray()))
        assertNull(CryptoManager.open(sealed, bob.dhPriv, alice.dhPub, ByteArray(8), alice.nodeId, bob.nodeId, aad))
    }

    @Test fun `el mismo texto produce cifrados distintos (nonce aleatorio)`() {
        val a = CryptoManager.seal("x".toByteArray(), alice.dhPriv, bob.dhPub, msgId, alice.nodeId, bob.nodeId, aad)!!
        val b = CryptoManager.seal("x".toByteArray(), alice.dhPriv, bob.dhPub, msgId, alice.nodeId, bob.nodeId, aad)!!
        assertFalse(a.contentEquals(b))
    }

    @Test fun `firma y verificacion`() {
        val data = "paquete".toByteArray()
        val sig = CryptoManager.sign(alice.signPriv, data)
        assertTrue(CryptoManager.verify(alice.signPub, data, sig))
        assertFalse(CryptoManager.verify(bob.signPub, data, sig))
        assertFalse(CryptoManager.verify(alice.signPub, "otro".toByteArray(), sig))
        assertFalse(CryptoManager.verify(alice.signPub, data, ByteArray(10)))
    }

    @Test fun `identificador y huella son deterministas y no dependen del hardware`() {
        val again = CryptoManager.identityFromPrivate(alice.signPriv, alice.dhPriv)
        assertEquals(alice.nodeId, again.nodeId)
        assertEquals(alice.fingerprint, again.fingerprint)
        assertEquals(16, alice.nodeId.length)
        assertNotEquals(alice.nodeId, bob.nodeId)
        assertTrue(Regex("^(\\d{5} ){11}\\d{5}$").matches(alice.fingerprint))
    }
}
