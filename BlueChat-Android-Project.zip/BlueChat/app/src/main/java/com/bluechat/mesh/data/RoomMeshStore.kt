package com.bluechat.mesh.data

import com.bluechat.mesh.core.MeshStore
import com.bluechat.mesh.core.NodeRecord
import com.bluechat.mesh.core.QueueEntry

/**
 * Implementación Room de [MeshStore]. Las operaciones son bloqueantes: el motor las invoca desde
 * hilos de Bluetooth/servicio, nunca desde el hilo principal (Room lo impediría).
 */
class RoomMeshStore(private val db: AppDatabase) : MeshStore {

    override fun putQueue(entry: QueueEntry) {
        db.queue().put(
            QueueEntity(
                key = entry.key, packet = entry.packet, receivedAt = entry.receivedAt, own = entry.own,
                sentTo = entry.sentTo.joinToString(","), waves = entry.waves, lastAttemptAt = entry.lastAttemptAt
            )
        )
    }

    private fun QueueEntity.toEntry() = QueueEntry(
        key = key, packet = packet, receivedAt = receivedAt, own = own,
        sentTo = if (sentTo.isEmpty()) emptySet() else sentTo.split(',').toSet(),
        waves = waves, lastAttemptAt = lastAttemptAt
    )

    override fun getQueue(): List<QueueEntry> = db.queue().all().map { it.toEntry() }
    override fun getQueueEntry(key: String): QueueEntry? = db.queue().get(key)?.toEntry()
    override fun removeQueue(key: String) = db.queue().delete(key)
    override fun queueSize(): Int = db.queue().count()

    override fun isSeen(key: String): Boolean = db.seen().has(key) > 0
    override fun markSeen(key: String, at: Long) = db.seen().put(SeenEntity(key, at))
    override fun purgeSeen(olderThan: Long) = db.seen().purge(olderThan)

    override fun getNode(nodeId: String): NodeRecord? = db.nodes().get(nodeId)?.toRecord()

    override fun putNode(node: NodeRecord) {
        db.nodes().put(node.toEntity())
        val excess = db.nodes().count() - MAX_NODES
        if (excess > 0) db.nodes().deleteOldestAnonymous(excess)
    }

    override fun allNodes(): List<NodeRecord> = db.nodes().all().map { it.toRecord() }

    companion object {
        const val MAX_NODES = 500
    }
}

fun NodeEntity.toRecord() = NodeRecord(
    nodeId, alias, avatar, signPub, dhPub, relayCapable, lastSeen, isContact, blocked, verified
)

fun NodeRecord.toEntity() = NodeEntity(
    nodeId, alias, avatar, signPub, dhPub, relayCapable, lastSeen, isContact, blocked, verified
)
