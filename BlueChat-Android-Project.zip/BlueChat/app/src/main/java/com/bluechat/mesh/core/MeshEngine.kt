package com.bluechat.mesh.core

import java.security.SecureRandom

/**
 * Motor Mesh: protocolo, enrutamiento, Store-and-Forward, confirmaciones y cifrado.
 *
 * No conoce Bluetooth: habla con [Link]s y recibe eventos mediante [LinkEvents]. Eso permite
 * probarlo en JVM con transportes simulados y usarlo en producción con GATT.
 * Es seguro entre hilos (todas las operaciones públicas están sincronizadas).
 */
class MeshEngine(
    private val identity: IdentityKeys,
    profile: Profile,
    private val store: MeshStore,
    private val clock: WallClock = SystemWallClock,
    config: MeshConfig = MeshConfig(),
    private val random: SecureRandom = SecureRandom(),
    private val advertisesRole: Boolean = true
) : LinkEvents {

    val selfId: String = identity.nodeId

    @Volatile var listener: MeshListener? = null

    private var config: MeshConfig = config
    private var profile: Profile = profile
    private val router = MeshRouter(config.routeTtlMs)
    private val rateLimiter = RateLimiter(clock)

    private class LinkState(val link: Link, val since: Long, clock: WallClock) {
        var nodeId: String? = null
        var lastRx: Long = since
        val reassembler = Reassembler(clock)
    }

    private val links = LinkedHashMap<String, LinkState>()
    private val helloCache = LinkedHashMap<String, MeshPacket>()
    private val ackResendAt = LinkedHashMap<String, Long>()

    private var fragCounter = random.nextInt(0x10000)
    private var lastHelloAt = 0L
    private var lastSeenPurge = 0L

    private var relayed = 0L
    private var sent = 0L
    private var received = 0L
    private var duplicates = 0L
    private var invalid = 0L
    private var rateLimited = 0L
    private var lastActivity = 0L

    // ------------------------------------------------------------------ configuración

    @Synchronized fun updateConfig(newConfig: MeshConfig) { config = newConfig }

    @Synchronized fun getConfig(): MeshConfig = config

    @Synchronized fun updateProfile(newProfile: Profile) {
        profile = newProfile
        broadcastHello()
    }

    // ------------------------------------------------------------------ consultas

    @Synchronized fun neighbors(): List<NeighborInfo> = links.values.map { ls ->
        NeighborInfo(
            linkId = ls.link.id,
            nodeId = ls.nodeId,
            alias = ls.nodeId?.let { store.getNode(it)?.alias },
            since = ls.since,
            rssi = ls.link.rssi
        )
    }

    @Synchronized fun linkCount(): Int = links.size

    @Synchronized fun knownNodes(): List<NodeInfo> {
        val now = clock.now()
        val direct = links.values.mapNotNull { it.nodeId }.toSet()
        return store.allNodes().filter { it.nodeId != selfId }.map { nodeInfo(it, now, direct) }
    }

    private fun nodeInfo(n: NodeRecord, now: Long, direct: Set<String>): NodeInfo {
        val isDirect = n.nodeId in direct
        val route = router.routeFor(n.nodeId, now)
        return NodeInfo(
            nodeId = n.nodeId, alias = n.alias, avatar = n.avatar,
            hops = if (isDirect) 1 else route?.hops ?: 0,
            direct = isDirect,
            viaNodeId = if (isDirect) n.nodeId else route?.viaNodeId,
            lastSeen = n.lastSeen, isContact = n.isContact, blocked = n.blocked,
            verified = n.verified, relayCapable = n.relayCapable
        )
    }

    @Synchronized fun stats() = MeshStats(
        queued = store.queueSize(), relayed = relayed, sent = sent, received = received,
        duplicatesDropped = duplicates, invalidDropped = invalid, rateLimited = rateLimited,
        lastActivity = lastActivity
    )

    // ------------------------------------------------------------------ envío (API pública)

    /**
     * Cifra [text] para [to] y lo encola. [beforeDispatch] recibe el msgId ANTES de intentar
     * entregarlo (así la app puede guardar el mensaje antes de recibir su primer estado).
     */
    @Synchronized
    fun sendText(to: String, text: String, beforeDispatch: (String) -> Unit = {}): SendResult {
        if (text.isBlank()) return SendResult.Empty
        val bytes = text.toByteArray(Charsets.UTF_8)
        if (bytes.size > config.maxTextBytes) return SendResult.TooLong
        val node = store.getNode(to) ?: return SendResult.UnknownRecipient
        if (node.blocked) return SendResult.Blocked
        val pkt = buildSealed(PacketType.DATA, node, byteArrayOf(InnerKind.TEXT.toByte()) + bytes)
            ?: return SendResult.CryptoFailure
        val entry = enqueueOwn(pkt)
        beforeDispatch(pkt.msgIdHex)
        attempt(entry)
        return SendResult.Queued(pkt.msgIdHex)
    }

    /** Confirmación de lectura (cuando el usuario abre la conversación). */
    @Synchronized
    fun sendReadReceipt(to: String, ackedMsgId: String) {
        val node = store.getNode(to) ?: return
        if (node.blocked) return
        sendAck(node, Hex.decode(ackedMsgId), InnerKind.ACK_READ)
    }

    @Synchronized
    fun setBlocked(nodeId: String, blocked: Boolean) {
        val n = store.getNode(nodeId) ?: return
        store.putNode(n.copy(blocked = blocked))
        listener?.onNodeUpdated(nodeInfo(n.copy(blocked = blocked), clock.now(), directIds()))
    }

    // ------------------------------------------------------------------ eventos del transporte

    @Synchronized
    override fun onLinkUp(link: Link) {
        if (links.size >= config.maxLinks || links.containsKey(link.id)) {
            link.close()
            return
        }
        val ls = LinkState(link, clock.now(), clock)
        links[link.id] = ls
        sendPacketTo(ls, buildHello().encode())
        if (config.relayEnabled) {
            for (cached in helloCache.values.toList().takeLast(16)) {
                if (cached.ttl > 0 && cached.hops + 1 < config.maxHops) {
                    sendPacketTo(ls, cached.withHop().encode())
                }
            }
        }
        touch()
    }

    @Synchronized
    override fun onLinkDown(linkId: String) {
        val ls = links.remove(linkId) ?: return
        val nid = ls.nodeId
        if (nid != null && links.values.none { it.nodeId == nid }) router.forgetVia(nid)
        listener?.onNeighborsChanged(neighbors())
        touch()
    }

    @Synchronized
    override fun onFrame(linkId: String, frame: ByteArray) {
        val ls = links[linkId] ?: return
        ls.lastRx = clock.now()
        val bytes = ls.reassembler.accept(frame) ?: return
        val pkt = MeshPacket.decode(bytes)
        if (pkt == null) {
            invalid++
            return
        }
        handlePacket(pkt, ls)
    }

    // ------------------------------------------------------------------ temporizador

    /** Llamar periódicamente (p. ej. cada 5 s): HELLO, reintentos, caducidad y limpieza. */
    @Synchronized
    fun tick() {
        val now = clock.now()
        if (links.isNotEmpty() && now - lastHelloAt >= config.helloIntervalMs) broadcastHello()
        for (e in store.getQueue()) {
            processQueueEntry(e, now)
        }
        if (now - lastSeenPurge > 60_000) {
            lastSeenPurge = now
            store.purgeSeen(now - (PacketLimits.MAX_VALIDITY_MS + 3_600_000L))
            links.values.forEach { it.reassembler.purge(now) }
            helloCache.entries.removeAll { now - it.value.timestamp > 5 * 60_000L && false }
        }
    }

    private fun processQueueEntry(e0: QueueEntry, now: Long) {
        var e = e0
        val pkt = MeshPacket.decode(e.packet)
        if (pkt == null) {
            store.removeQueue(e.key)
            return
        }
        if (isExpired(e, pkt, now)) {
            expire(e, pkt)
            return
        }
        if (e.own && e.lastAttemptAt != 0L && e.waves < config.maxWaves &&
            now - e.lastAttemptAt >= config.retryIntervalMs
        ) {
            val pending = router.select(pkt.destHex, neighborViews(), null, e.sentTo, now, config.fanout)
            if (pending.isEmpty() && links.isNotEmpty()) {
                // Nueva ola: sin confirmación tras el intervalo, se reintenta el camino.
                e = e.copy(sentTo = emptySet(), waves = e.waves + 1, lastAttemptAt = now)
                store.putQueue(e)
            }
        }
        attempt(e)
    }

    // ------------------------------------------------------------------ recepción

    private fun handlePacket(pkt: MeshPacket, ls: LinkState) {
        val now = clock.now()
        val origin = pkt.originHex
        if (origin == selfId) return
        if (pkt.hops >= config.maxHops) return
        if (store.getNode(origin)?.blocked == true) return

        val key = pkt.key
        if (store.isSeen(key)) {
            duplicates++
            if (pkt.type == PacketType.DATA && pkt.destHex == selfId) resendDeliveredAck(pkt, now)
            return
        }

        val allowed = if (pkt.type == PacketType.HELLO) {
            rateLimiter.allow("h:$origin", 3, 12)
        } else {
            rateLimiter.allow("d:$origin", 10, config.maxPacketsPerOriginPerMinute)
        }
        if (!allowed) {
            rateLimited++
            return
        }

        val ok = when (pkt.type) {
            PacketType.HELLO -> handleHello(pkt, ls, now)
            PacketType.DATA -> handleData(pkt, ls, now)
            PacketType.ACK -> handleAck(pkt, ls, now)
            else -> false
        }
        if (!ok) {
            invalid++
            return
        }
        store.markSeen(key, now)
        ls.nodeId?.let { router.learnRoute(origin, it, pkt.hops + 1, now) }
        received++
        touch()
    }

    // --- HELLO

    private class HelloData(val signPub: ByteArray, val dhPub: ByteArray, val caps: Int, val avatar: Int, val alias: String)

    private fun parseHello(payload: ByteArray): HelloData? {
        if (payload.size < 67) return null
        val aliasLen = payload[66].toInt() and 0xFF
        if (payload.size != 67 + aliasLen || aliasLen > 100) return null
        val alias = String(payload, 67, aliasLen, Charsets.UTF_8).trim()
        return HelloData(
            payload.copyOfRange(0, 32), payload.copyOfRange(32, 64),
            payload[64].toInt() and 0xFF, payload[65].toInt() and 0xFF, alias
        )
    }

    private fun handleHello(pkt: MeshPacket, ls: LinkState, now: Long): Boolean {
        val h = parseHello(pkt.payload) ?: return false
        if (CryptoManager.nodeIdFor(h.signPub, h.dhPub) != pkt.originHex) return false
        val sig = pkt.signature ?: return false
        if (!CryptoManager.verify(h.signPub, pkt.signedBytes(), sig)) return false

        val existing = store.getNode(pkt.originHex)
        val record = NodeRecord(
            nodeId = pkt.originHex,
            alias = h.alias.ifBlank { "Usuario ${NodeIds.short(pkt.originHex)}" },
            avatar = h.avatar, signPub = h.signPub, dhPub = h.dhPub,
            relayCapable = h.caps and CAP_RELAY != 0,
            lastSeen = now,
            isContact = existing?.isContact ?: false,
            blocked = existing?.blocked ?: false,
            verified = existing?.verified ?: false
        )
        store.putNode(record)
        if (config.relayEnabled) {
            helloCache[pkt.originHex] = pkt
            while (helloCache.size > 32) helloCache.remove(helloCache.keys.first())
        }

        if (pkt.hops == 0 && (ls.nodeId == null || ls.nodeId == pkt.originHex)) {
            bindNeighbor(ls, pkt.originHex)
        }
        // Se anota el enrutamiento antes de notificar para que hops/direct sean coherentes.
        if (ls.nodeId != null) router.learnRoute(pkt.originHex, ls.nodeId!!, pkt.hops + 1, now)
        listener?.onNodeUpdated(nodeInfo(record, now, directIds()))

        if (config.relayEnabled && pkt.ttl > 0) {
            val fwd = pkt.withHop().encode()
            for (other in links.values) {
                if (other !== ls && other.nodeId != null) sendPacketTo(other, fwd)
            }
        }
        return true
    }

    private fun bindNeighbor(ls: LinkState, nodeId: String) {
        val dup = links.values.firstOrNull { it !== ls && it.nodeId == nodeId }
        if (dup != null) {
            // Dos enlaces con el mismo vecino: se conserva el iniciado por el nodo de menor id
            // (ambos extremos aplican la misma regla y convergen en el mismo enlace).
            val canonicalInitiatedLocally = selfId < nodeId
            val keepNew = ls.link.initiatedLocally == canonicalInitiatedLocally
            val loser = if (keepNew) dup else ls
            links.remove(loser.link.id)
            loser.link.close()
            if (loser === ls) return
        }
        ls.nodeId = nodeId
        listener?.onNeighborsChanged(neighbors())
        // Entrega lo almacenado que este vecino aún no ha visto.
        for (e in store.getQueue()) attempt(e)
    }

    // --- DATA

    private class DataParts(val signPub: ByteArray, val dhPub: ByteArray, val sealed: ByteArray)

    private fun parseData(payload: ByteArray): DataParts? {
        if (payload.size < 64 + CryptoManager.SEAL_OVERHEAD + 1) return null
        return DataParts(payload.copyOfRange(0, 32), payload.copyOfRange(32, 64), payload.copyOfRange(64, payload.size))
    }

    private fun handleData(pkt: MeshPacket, ls: LinkState, now: Long): Boolean {
        val parts = parseData(pkt.payload) ?: return false
        if (CryptoManager.nodeIdFor(parts.signPub, parts.dhPub) != pkt.originHex) return false
        val sig = pkt.signature ?: return false
        if (!CryptoManager.verify(parts.signPub, pkt.signedBytes(), sig)) return false

        if (pkt.destHex != selfId) {
            if (!config.relayEnabled || pkt.ttl <= 0) return true // válido, pero no se reenvía
            relayPacket(pkt, ls)
            return true
        }

        // Somos el destinatario.
        var sender = store.getNode(pkt.originHex)
        if (sender == null) {
            sender = NodeRecord(
                nodeId = pkt.originHex, alias = "Usuario ${NodeIds.short(pkt.originHex)}", avatar = 0,
                signPub = parts.signPub, dhPub = parts.dhPub, relayCapable = false, lastSeen = now
            )
            store.putNode(sender)
        }
        val plain = CryptoManager.open(
            parts.sealed, identity.dhPriv, parts.dhPub, pkt.msgId, pkt.originHex, selfId, pkt.authHeader()
        ) ?: return false
        if (plain.isEmpty()) return false
        if (pkt.timestamp > now + 10 * 60_000L) return false
        if (now - pkt.timestamp > pkt.validityMin * 60_000L + 10 * 60_000L) return false // anti-repetición

        if (plain[0].toInt() == InnerKind.TEXT) {
            val text = String(plain, 1, plain.size - 1, Charsets.UTF_8)
            listener?.onMessageReceived(
                IncomingMessage(pkt.msgIdHex, pkt.originHex, text, pkt.timestamp, pkt.hops + 1)
            )
            ackResendAt[pkt.key] = now
            while (ackResendAt.size > 256) ackResendAt.remove(ackResendAt.keys.first())
            sendAck(sender, pkt.msgId, InnerKind.ACK_DELIVERED)
        }
        return true
    }

    // --- ACK

    private fun handleAck(pkt: MeshPacket, ls: LinkState, now: Long): Boolean {
        val sig = pkt.signature ?: return false
        val sender = store.getNode(pkt.originHex)

        if (pkt.destHex != selfId) {
            // Un repetidor solo puede verificar la firma si ya conoce al emisor.
            if (sender != null && !CryptoManager.verify(sender.signPub, pkt.signedBytes(), sig)) return false
            if (!config.relayEnabled || pkt.ttl <= 0) return true
            relayPacket(pkt, ls)
            return true
        }

        if (sender == null) return false // no confirmamos nada de quien no conocemos
        if (!CryptoManager.verify(sender.signPub, pkt.signedBytes(), sig)) return false
        val plain = CryptoManager.open(
            pkt.payload, identity.dhPriv, sender.dhPub, pkt.msgId, pkt.originHex, selfId, pkt.authHeader()
        ) ?: return false
        if (plain.size != 9) return false
        val kind = plain[0].toInt()
        val ackedId = Hex.encode(plain.copyOfRange(1, 9))
        val status = when (kind) {
            InnerKind.ACK_DELIVERED -> DeliveryStatus.DELIVERED
            InnerKind.ACK_READ -> DeliveryStatus.READ
            else -> return false
        }
        // La entrega se confirma solo si el ACK proviene del destinatario original.
        val ownKey = selfId + ackedId
        val q = store.getQueueEntry(ownKey)
        if (q != null) {
            val orig = MeshPacket.decode(q.packet)
            if (orig != null && orig.destHex != pkt.originHex) return false
            if (status == DeliveryStatus.DELIVERED || status == DeliveryStatus.READ) store.removeQueue(ownKey)
        }
        listener?.onOutgoingStatus(ackedId, pkt.originHex, status)
        return true
    }

    private fun resendDeliveredAck(pkt: MeshPacket, now: Long) {
        val last = ackResendAt[pkt.key] ?: return
        if (now - last < 20_000) return
        val sender = store.getNode(pkt.originHex) ?: return
        ackResendAt[pkt.key] = now
        sendAck(sender, pkt.msgId, InnerKind.ACK_DELIVERED)
    }

    private fun sendAck(to: NodeRecord, ackedMsgId: ByteArray, kind: Int) {
        val pkt = buildSealed(PacketType.ACK, to, byteArrayOf(kind.toByte()) + ackedMsgId) ?: return
        attempt(enqueueOwn(pkt))
    }

    // ------------------------------------------------------------------ reenvío / cola

    private fun relayPacket(pkt: MeshPacket, from: LinkState) {
        val fwd = pkt.withHop()
        val entry = QueueEntry(
            key = fwd.key, packet = fwd.encode(), receivedAt = clock.now(), own = false,
            sentTo = setOfNotNull(from.nodeId), waves = 0, lastAttemptAt = 0L
        )
        makeRoom(entry.own)
        store.putQueue(entry)
        attempt(entry, from.nodeId)
    }

    private fun enqueueOwn(pkt: MeshPacket): QueueEntry {
        val entry = QueueEntry(
            key = pkt.key, packet = pkt.encode(), receivedAt = clock.now(), own = true,
            sentTo = emptySet(), waves = 0, lastAttemptAt = 0L
        )
        makeRoom(true)
        store.putQueue(entry)
        store.markSeen(pkt.key, clock.now())
        if (pkt.type == PacketType.DATA) {
            listener?.onOutgoingStatus(pkt.msgIdHex, pkt.destHex, DeliveryStatus.PENDING)
        }
        touch()
        return entry
    }

    private fun makeRoom(incomingOwn: Boolean) {
        if (store.queueSize() < config.maxQueue) return
        val q = store.getQueue()
        val victim = q.filter { !it.own }.minByOrNull { it.receivedAt }
            ?: if (incomingOwn) q.minByOrNull { it.receivedAt } else null
        if (victim != null) {
            store.removeQueue(victim.key)
            if (victim.own) MeshPacket.decode(victim.packet)?.let { expire(victim, it) }
        }
    }

    private fun attempt(entry: QueueEntry, cameFrom: String? = null) {
        val now = clock.now()
        val pkt = MeshPacket.decode(entry.packet) ?: run {
            store.removeQueue(entry.key); return
        }
        if (isExpired(entry, pkt, now)) {
            expire(entry, pkt); return
        }
        // El registro puede haber cambiado (p. ej. ACK recibido): se relee el estado persistido.
        val cur = store.getQueueEntry(entry.key) ?: return
        val targets = router.select(pkt.destHex, neighborViews(), cameFrom, cur.sentTo, now, config.fanout)
        if (targets.isEmpty()) return

        val sentNow = HashSet<String>()
        var directToDest = false
        for (t in targets) {
            val ls = links[t.linkId] ?: continue
            if (sendPacketTo(ls, cur.packet)) {
                sentNow += t.nodeId
                if (t.nodeId == pkt.destHex) directToDest = true
            }
        }
        if (sentNow.isEmpty()) return

        val updated = cur.copy(sentTo = cur.sentTo + sentNow, lastAttemptAt = now)
        sent += sentNow.size
        if (!cur.own) relayed += sentNow.size

        if (!cur.own && directToDest) store.removeQueue(cur.key) else store.putQueue(updated)
        if (cur.own && pkt.type == PacketType.DATA) {
            listener?.onOutgoingStatus(
                pkt.msgIdHex, pkt.destHex,
                if (directToDest) DeliveryStatus.SENT else DeliveryStatus.RELAYING
            )
        }
        touch()
    }

    private fun isExpired(e: QueueEntry, pkt: MeshPacket, now: Long): Boolean =
        now - e.receivedAt > pkt.validityMin.coerceAtMost(MeshPacket.MAX_VALIDITY_MIN) * 60_000L

    private fun expire(e: QueueEntry, pkt: MeshPacket) {
        store.removeQueue(e.key)
        if (e.own && pkt.type == PacketType.DATA) {
            listener?.onOutgoingStatus(pkt.msgIdHex, pkt.destHex, DeliveryStatus.FAILED)
        }
        touch()
    }

    // ------------------------------------------------------------------ construcción de paquetes

    private fun randomId(): ByteArray {
        val b = ByteArray(8)
        do { random.nextBytes(b) } while (b.all { it == 0.toByte() })
        return b
    }

    private fun newPacket(type: Int, dest: String, ttl: Int, payload: ByteArray, validityMin: Int): MeshPacket =
        MeshPacket(
            MeshPacket.VERSION, type, 0, ttl, 0, randomId(), Hex.decode(selfId), Hex.decode(dest),
            clock.now(), validityMin, payload, null
        )

    private fun signed(p: MeshPacket) = p.withSignature(CryptoManager.sign(identity.signPriv, p.signedBytes()))

    private fun buildHello(): MeshPacket {
        val alias = profile.alias.take(24).toByteArray(Charsets.UTF_8)
        val caps = (if (config.relayEnabled) CAP_RELAY else 0) or (if (advertisesRole) CAP_ADVERTISE else 0)
        val payload = identity.signPub + identity.dhPub +
            byteArrayOf(caps.toByte(), profile.avatar.toByte(), alias.size.toByte()) + alias
        return signed(newPacket(PacketType.HELLO, NodeIds.BROADCAST, config.helloTtl, payload, 10))
    }

    private fun buildSealed(type: Int, to: NodeRecord, inner: ByteArray): MeshPacket? {
        val validity = if (type == PacketType.ACK) minOf(config.validityMinutes, 360) else config.validityMinutes
        val draft = newPacket(type, to.nodeId, config.maxHops, ByteArray(0), validity)
        val sealed = CryptoManager.seal(
            inner, identity.dhPriv, to.dhPub, draft.msgId, selfId, to.nodeId, draft.authHeader(), random
        ) ?: return null
        val payload = if (type == PacketType.DATA) identity.signPub + identity.dhPub + sealed else sealed
        return signed(
            MeshPacket(
                draft.version, draft.type, draft.flags, draft.ttl, draft.hops, draft.msgId, draft.origin,
                draft.dest, draft.timestamp, draft.validityMin, payload, null
            )
        )
    }

    private fun broadcastHello() {
        lastHelloAt = clock.now()
        val bytes = buildHello().encode()
        for (ls in links.values) sendPacketTo(ls, bytes)
    }

    // ------------------------------------------------------------------ utilidades

    private fun neighborViews(): List<NeighborView> =
        links.values.mapNotNull { ls -> ls.nodeId?.let { NeighborView(ls.link.id, it, ls.lastRx) } }

    private fun directIds(): Set<String> = links.values.mapNotNull { it.nodeId }.toSet()

    private fun nextFragId(): Int {
        fragCounter = (fragCounter + 1) and 0xFFFF
        return fragCounter
    }

    private fun sendPacketTo(ls: LinkState, bytes: ByteArray): Boolean {
        val frames = try {
            Fragmenter.split(bytes, ls.link.maxFrameBytes, nextFragId())
        } catch (e: IllegalArgumentException) {
            return false
        }
        for (f in frames) if (!ls.link.send(f)) return false
        return true
    }

    private fun touch() {
        lastActivity = clock.now()
        listener?.onStatsChanged()
    }

    companion object {
        const val CAP_RELAY = 0x01
        const val CAP_ADVERTISE = 0x02
    }
}

internal object PacketLimits {
    const val MAX_VALIDITY_MS = MeshPacket.MAX_VALIDITY_MIN * 60_000L
}
