package com.bluechat.mesh.core

/** Entrada persistente de la cola Store-and-Forward. Solo contiene el paquete CIFRADO. */
class QueueEntry(
    val key: String,
    val packet: ByteArray,
    val receivedAt: Long,
    val own: Boolean,
    val sentTo: Set<String>,
    val waves: Int,
    val lastAttemptAt: Long
) {
    fun copy(
        sentTo: Set<String> = this.sentTo,
        waves: Int = this.waves,
        lastAttemptAt: Long = this.lastAttemptAt
    ) = QueueEntry(key, packet, receivedAt, own, sentTo, waves, lastAttemptAt)
}

/** Persistencia que necesita el motor. En la app la implementa Room; en pruebas, memoria. */
interface MeshStore {
    fun putQueue(entry: QueueEntry)
    fun getQueue(): List<QueueEntry>
    fun getQueueEntry(key: String): QueueEntry?
    fun removeQueue(key: String)
    fun queueSize(): Int

    fun isSeen(key: String): Boolean
    fun markSeen(key: String, at: Long)
    fun purgeSeen(olderThan: Long)

    fun getNode(nodeId: String): NodeRecord?
    fun putNode(node: NodeRecord)
    fun allNodes(): List<NodeRecord>
}

class InMemoryMeshStore : MeshStore {
    private val queue = LinkedHashMap<String, QueueEntry>()
    private val seen = HashMap<String, Long>()
    private val nodes = HashMap<String, NodeRecord>()

    @Synchronized override fun putQueue(entry: QueueEntry) { queue[entry.key] = entry }
    @Synchronized override fun getQueue(): List<QueueEntry> = queue.values.toList()
    @Synchronized override fun getQueueEntry(key: String): QueueEntry? = queue[key]
    @Synchronized override fun removeQueue(key: String) { queue.remove(key) }
    @Synchronized override fun queueSize(): Int = queue.size

    @Synchronized override fun isSeen(key: String): Boolean = seen.containsKey(key)
    @Synchronized override fun markSeen(key: String, at: Long) { seen[key] = at }
    @Synchronized override fun purgeSeen(olderThan: Long) {
        seen.entries.removeAll { it.value < olderThan }
    }

    @Synchronized override fun getNode(nodeId: String): NodeRecord? = nodes[nodeId]
    @Synchronized override fun putNode(node: NodeRecord) { nodes[node.nodeId] = node }
    @Synchronized override fun allNodes(): List<NodeRecord> = nodes.values.toList()
}
