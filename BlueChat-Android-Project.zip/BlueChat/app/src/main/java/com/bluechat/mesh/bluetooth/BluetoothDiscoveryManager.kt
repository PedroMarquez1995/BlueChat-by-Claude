package com.bluechat.mesh.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.BluetoothLeAdvertiser
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.ParcelUuid

/**
 * Descubrimiento BLE: publicita el servicio BlueChat (para que otros nos encuentren) y escanea
 * únicamente dispositivos que lo publiciten (filtro por UUID, nunca MAC ni nombres).
 * Los permisos deben estar concedidos antes de llamar a [start] (lo garantiza MeshService).
 */
@SuppressLint("MissingPermission")
class BluetoothDiscoveryManager(
    private val context: Context,
    private val onDevice: (BluetoothDevice, Int) -> Unit,
    private val onState: (advertising: Boolean, scanning: Boolean, error: String?) -> Unit
) {
    private var scanner: BluetoothLeScanner? = null
    private var advertiser: BluetoothLeAdvertiser? = null
    private var advertising = false
    private var scanning = false
    private var error: String? = null

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            onDevice(result.device, result.rssi)
        }

        override fun onBatchScanResults(results: MutableList<ScanResult>) {
            results.forEach { onDevice(it.device, it.rssi) }
        }

        override fun onScanFailed(errorCode: Int) {
            scanning = false
            error = "Falló el escaneo Bluetooth (código $errorCode)."
            publish()
        }
    }

    private val advertiseCallback = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings) {
            advertising = true
            publish()
        }

        override fun onStartFailure(errorCode: Int) {
            advertising = false
            error = when (errorCode) {
                AdvertiseCallback.ADVERTISE_FAILED_FEATURE_UNSUPPORTED ->
                    "Este teléfono no puede anunciarse por BLE; solo podrá conectarse a otros (modo escáner)."
                AdvertiseCallback.ADVERTISE_FAILED_TOO_MANY_ADVERTISERS -> "Demasiados anunciantes BLE activos en el teléfono."
                else -> "No se pudo anunciar el servicio BLE (código $errorCode)."
            }
            publish()
        }
    }

    private fun publish() = onState(advertising, scanning, error)

    /** [visible]: anunciar este teléfono. [lowPower]: ahorro de batería (escaneo y anuncio más espaciados). */
    @Synchronized
    fun start(visible: Boolean, lowPower: Boolean) {
        stop(silent = true)
        error = null
        val adapter = context.getSystemService(BluetoothManager::class.java)?.adapter
        if (adapter == null || !adapter.isEnabled) {
            error = "Bluetooth apagado."
            publish()
            return
        }

        scanner = adapter.bluetoothLeScanner
        scanner?.let {
            val filter = ScanFilter.Builder().setServiceUuid(ParcelUuid(BleUuids.SERVICE)).build()
            val settings = ScanSettings.Builder()
                .setScanMode(if (lowPower) ScanSettings.SCAN_MODE_LOW_POWER else ScanSettings.SCAN_MODE_BALANCED)
                .setCallbackType(ScanSettings.CALLBACK_TYPE_ALL_MATCHES)
                .build()
            try {
                it.startScan(listOf(filter), settings, scanCallback)
                scanning = true
            } catch (e: Exception) {
                error = "No se pudo iniciar el escaneo: ${e.message}"
            }
        } ?: run { error = "Escáner BLE no disponible." }

        if (visible) {
            advertiser = adapter.bluetoothLeAdvertiser
            val adv = advertiser
            if (adv == null) {
                error = "Este teléfono no soporta anuncio BLE; funcionará solo como escáner."
            } else {
                val settings = AdvertiseSettings.Builder()
                    .setAdvertiseMode(
                        if (lowPower) AdvertiseSettings.ADVERTISE_MODE_LOW_POWER
                        else AdvertiseSettings.ADVERTISE_MODE_BALANCED
                    )
                    .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
                    .setConnectable(true)
                    .setTimeout(0)
                    .build()
                val data = AdvertiseData.Builder()
                    .setIncludeDeviceName(false) // no se filtra el nombre del teléfono
                    .addServiceUuid(ParcelUuid(BleUuids.SERVICE))
                    .build()
                try {
                    adv.startAdvertising(settings, data, advertiseCallback)
                } catch (e: Exception) {
                    error = "No se pudo anunciar: ${e.message}"
                }
            }
        }
        publish()
    }

    @Synchronized
    fun stop(silent: Boolean = false) {
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { advertiser?.stopAdvertising(advertiseCallback) } catch (_: Exception) {}
        scanner = null
        advertiser = null
        advertising = false
        scanning = false
        if (!silent) publish()
    }
}
