package com.bluechat.mesh.core

/** Vecino directo con identidad ya verificada (tras intercambiar HELLO). */
data class NeighborView(val linkId: String, val nodeId: String, val lastSeen: Long)

/**
 * Lógica de decisión de reenvío (sin E/S, totalmente determinista y probable).
 *
 * Estrategia para no inundar la red:
 *  1. Si el destino es vecino directo -> solo a él (unicast).
 *  2. Si hay ruta reciente aprendida (camino inverso) -> solo al siguiente salto.
 *  3. Si no, se difunde a un número limitado de vecinos (fanout), excluyendo el origen del
 *     paquete y los vecinos a los que ya se envió. Las siguientes "olas" cubren al resto.
 */
class MeshRouter(private val routeTtlMs: Long) {

    data class Route(val viaNodeId: String, val hops: Int, val updatedAt: Long)

    private val routes = HashMap<String, Route>()

    /** Aprende (o refresca) la ruta hacia [dest] pasando por el vecino [viaNodeId]. */
    fun learnRoute(dest: String, viaNodeId: String, hops: Int, now: Long) {
        val cur = routes[dest]
        val stale = cur == null || now - cur.updatedAt > routeTtlMs
        if (stale || hops <= cur!!.hops || cur.viaNodeId == viaNodeId) {
            routes[dest] = Route(viaNodeId, hops, now)
        }
    }

    fun routeFor(dest: String, now: Long): Route? {
        val r = routes[dest] ?: return null
        return if (now - r.updatedAt <= routeTtlMs) r else null
    }

    /** Olvida todas las rutas que pasaban por un vecino que se desconectó. */
    fun forgetVia(nodeId: String) {
        routes.entries.removeAll { it.value.viaNodeId == nodeId }
        routes.remove(nodeId)
    }

    fun knownRoutes(now: Long): Map<String, Route> =
        routes.filterValues { now - it.updatedAt <= routeTtlMs }

    fun select(
        dest: String,
        neighbors: List<NeighborView>,
        cameFromNodeId: String?,
        sentTo: Set<String>,
        now: Long,
        fanout: Int
    ): List<NeighborView> {
        val candidates = neighbors.filter { it.nodeId != cameFromNodeId && it.nodeId !in sentTo }
        if (candidates.isEmpty()) return emptyList()

        candidates.firstOrNull { it.nodeId == dest }?.let { return listOf(it) }

        // Si el destino es vecino directo pero ya se le envió, no se inunda a los demás.
        if (neighbors.any { it.nodeId == dest }) return emptyList()

        val route = routeFor(dest, now)
        if (route != null) {
            candidates.firstOrNull { it.nodeId == route.viaNodeId }?.let { return listOf(it) }
        }
        return candidates.sortedByDescending { it.lastSeen }.take(fanout.coerceAtLeast(1))
    }
}

/** Limitador por origen (token bucket) para frenar mensajes abusivos. */
class RateLimiter(private val clock: WallClock, private val maxKeys: Int = 512) {
    private class Bucket(var tokens: Double, var last: Long)

    private val buckets = HashMap<String, Bucket>()

    fun allow(key: String, capacity: Int, refillPerMinute: Int): Boolean {
        val now = clock.now()
        if (buckets.size >= maxKeys && !buckets.containsKey(key)) {
            buckets.entries.removeAll { now - it.value.last > 120_000 }
            if (buckets.size >= maxKeys) return false
        }
        val b = buckets.getOrPut(key) { Bucket(capacity.toDouble(), now) }
        val elapsedMin = (now - b.last) / 60_000.0
        b.tokens = minOf(capacity.toDouble(), b.tokens + elapsedMin * refillPerMinute)
        b.last = now
        if (b.tokens < 1.0) return false
        b.tokens -= 1.0
        return true
    }
}
