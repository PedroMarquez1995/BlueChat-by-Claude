package com.bluechat.mesh

import android.app.Application
import androidx.room.Room
import com.bluechat.mesh.data.AppDatabase
import com.bluechat.mesh.data.IdentityManager
import com.bluechat.mesh.data.MeshRuntime
import com.bluechat.mesh.data.SettingsRepository
import com.bluechat.mesh.service.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Contenedor manual de dependencias (suficiente para esta app; evita una librería de DI). */
class BlueChatApplication : Application() {
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val database: AppDatabase by lazy {
        Room.databaseBuilder(this, AppDatabase::class.java, "bluechat.db").build()
    }
    val identity: IdentityManager by lazy { IdentityManager(this) }
    val settings: SettingsRepository by lazy { SettingsRepository(this) }
    val notifier: NotificationHelper by lazy { NotificationHelper(this) }
    val runtime: MeshRuntime by lazy { MeshRuntime(this, database, identity, settings, notifier, appScope) }

    override fun onCreate() {
        super.onCreate()
        notifier.createChannels()
    }
}
