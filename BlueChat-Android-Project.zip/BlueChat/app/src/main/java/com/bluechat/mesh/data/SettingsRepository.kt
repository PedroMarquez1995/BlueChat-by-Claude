package com.bluechat.mesh.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "bluechat_settings")

enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class AppSettings(
    val onboardingDone: Boolean = false,
    val alias: String = "",
    val avatar: Int = 0,
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val batterySaver: Boolean = false,
    val relayEnabled: Boolean = true,
    val maxQueue: Int = 200,
    val maxHops: Int = 6,
    val notifications: Boolean = true,
    val notificationPreview: Boolean = false,
    val sendReadReceipts: Boolean = true,
    val visible: Boolean = true,
    val serviceEnabled: Boolean = false
)

class SettingsRepository(private val context: Context) {
    private object K {
        val onboarding = booleanPreferencesKey("onboarding_done")
        val alias = stringPreferencesKey("alias")
        val avatar = intPreferencesKey("avatar")
        val theme = stringPreferencesKey("theme")
        val battery = booleanPreferencesKey("battery_saver")
        val relay = booleanPreferencesKey("relay")
        val maxQueue = intPreferencesKey("max_queue")
        val maxHops = intPreferencesKey("max_hops")
        val notifications = booleanPreferencesKey("notifications")
        val preview = booleanPreferencesKey("notification_preview")
        val readReceipts = booleanPreferencesKey("read_receipts")
        val visible = booleanPreferencesKey("visible")
        val service = booleanPreferencesKey("service_enabled")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { p ->
        val d = AppSettings()
        AppSettings(
            onboardingDone = p[K.onboarding] ?: d.onboardingDone,
            alias = p[K.alias] ?: d.alias,
            avatar = p[K.avatar] ?: d.avatar,
            theme = p[K.theme]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: d.theme,
            batterySaver = p[K.battery] ?: d.batterySaver,
            relayEnabled = p[K.relay] ?: d.relayEnabled,
            maxQueue = p[K.maxQueue] ?: d.maxQueue,
            maxHops = p[K.maxHops] ?: d.maxHops,
            notifications = p[K.notifications] ?: d.notifications,
            notificationPreview = p[K.preview] ?: d.notificationPreview,
            sendReadReceipts = p[K.readReceipts] ?: d.sendReadReceipts,
            visible = p[K.visible] ?: d.visible,
            serviceEnabled = p[K.service] ?: d.serviceEnabled
        )
    }

    suspend fun current(): AppSettings = settings.first()

    suspend fun completeOnboarding(alias: String, avatar: Int, visible: Boolean, readReceipts: Boolean) {
        context.dataStore.edit {
            it[K.alias] = alias
            it[K.avatar] = avatar
            it[K.visible] = visible
            it[K.readReceipts] = readReceipts
            it[K.onboarding] = true
        }
    }

    suspend fun setProfile(alias: String, avatar: Int) = context.dataStore.edit {
        it[K.alias] = alias
        it[K.avatar] = avatar
    }.let { }

    suspend fun setTheme(v: ThemeMode) = context.dataStore.edit { it[K.theme] = v.name }.let { }
    suspend fun setBatterySaver(v: Boolean) = context.dataStore.edit { it[K.battery] = v }.let { }
    suspend fun setRelay(v: Boolean) = context.dataStore.edit { it[K.relay] = v }.let { }
    suspend fun setMaxQueue(v: Int) = context.dataStore.edit { it[K.maxQueue] = v }.let { }
    suspend fun setMaxHops(v: Int) = context.dataStore.edit { it[K.maxHops] = v }.let { }
    suspend fun setNotifications(v: Boolean) = context.dataStore.edit { it[K.notifications] = v }.let { }
    suspend fun setNotificationPreview(v: Boolean) = context.dataStore.edit { it[K.preview] = v }.let { }
    suspend fun setReadReceipts(v: Boolean) = context.dataStore.edit { it[K.readReceipts] = v }.let { }
    suspend fun setVisible(v: Boolean) = context.dataStore.edit { it[K.visible] = v }.let { }
    suspend fun setServiceEnabled(v: Boolean) = context.dataStore.edit { it[K.service] = v }.let { }
}
