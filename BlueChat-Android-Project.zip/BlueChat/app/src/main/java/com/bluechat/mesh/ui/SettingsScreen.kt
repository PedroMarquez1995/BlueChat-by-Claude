@file:OptIn(ExperimentalMaterial3Api::class)

package com.bluechat.mesh.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.bluechat.mesh.BlueChatApplication
import com.bluechat.mesh.data.ThemeMode

@Composable
fun SettingsTab(app: BlueChatApplication, actions: AppActions) {
    val vm: SettingsViewModel = viewModel(factory = AppViewModelFactory(app))
    val s by vm.settings.collectAsStateWithLifecycle()
    val id by vm.identity.collectAsStateWithLifecycle()
    val running by vm.serviceRunning.collectAsStateWithLifecycle()
    var editProfile by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 32.dp)) {
        SectionTitle("Perfil")
        Row(
            Modifier.fillMaxWidth().clickable { editProfile = true }.padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Avatar(s.alias.ifBlank { "?" }, s.avatar, 56.dp)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(s.alias.ifBlank { "Sin nombre" }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("Toca para editar nombre y avatar", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        SectionTitle("Identidad y verificación")
        InfoCard(Modifier.padding(horizontal = 16.dp)) {
            Text("Tu identificador personal", style = MaterialTheme.typography.labelMedium)
            Text(id?.nodeId ?: "…", fontFamily = FontFamily.Monospace)
            Spacer(Modifier.height(8.dp))
            Text("Tu huella (compárala en persona con tus contactos)", style = MaterialTheme.typography.labelMedium)
            Text(id?.fingerprint ?: "…", fontFamily = FontFamily.Monospace)
            Spacer(Modifier.height(6.dp))
            Text(
                "El identificador sale de tus claves públicas; no depende de tu número, de la MAC Bluetooth ni de datos del hardware.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        SectionTitle("Bluetooth y red")
        ToggleRow(
            "Modo repetidor",
            "Guardar y retransmitir mensajes cifrados de otros usuarios.",
            s.relayEnabled
        ) { vm.setRelay(it) }
        ToggleRow(
            "Modo ahorro de batería",
            "Escaneo y anuncio más espaciados: tarda más en encontrar vecinos. Se aplica al reiniciar la malla.",
            s.batterySaver
        ) { vm.setBatterySaver(it) }
        ToggleRow(
            "Ser visible para dispositivos cercanos",
            "Si se desactiva no te anuncias; otros no te encontrarán, pero tú sí podrás encontrarlos.",
            s.visible
        ) { vm.setVisible(it) }

        Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
            Text("Límite de saltos: ${s.maxHops}", style = MaterialTheme.typography.bodyLarge)
            Slider(
                value = s.maxHops.toFloat(),
                onValueChange = { vm.setMaxHops(it.toInt()) },
                valueRange = 2f..10f,
                steps = 7
            )
            Text("Límite de mensajes almacenados: ${s.maxQueue}", style = MaterialTheme.typography.bodyLarge)
            Slider(
                value = s.maxQueue.toFloat(),
                onValueChange = { vm.setMaxQueue((it / 25).toInt() * 25) },
                valueRange = 50f..500f,
                steps = 17
            )
        }
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (running) OutlinedButton(onClick = actions.stopMesh) { Text("Detener malla") }
            OutlinedButton(onClick = actions.openBatterySettings) { Text("Batería del sistema") }
        }
        Text(
            "Algunos fabricantes (Xiaomi, Huawei, Samsung, OPPO…) cierran apps en segundo plano. Si la malla se detiene sola, " +
                "excluye BlueChat de la optimización de batería.",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(16.dp)
        )

        SectionTitle("Notificaciones")
        ToggleRow("Avisar de mensajes nuevos", null, s.notifications) { vm.setNotifications(it) }
        ToggleRow(
            "Mostrar texto en la notificación",
            "Por defecto solo dice «Mensaje nuevo» para que no se lea en pantalla bloqueada.",
            s.notificationPreview
        ) { vm.setNotificationPreview(it) }

        SectionTitle("Privacidad")
        ToggleRow("Enviar confirmación de lectura", "Avisa al remitente cuando lees su mensaje.", s.sendReadReceipts) { vm.setReadReceipts(it) }

        SectionTitle("Tema visual")
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(s.theme == ThemeMode.SYSTEM, { vm.setTheme(ThemeMode.SYSTEM) }, { Text("Sistema") })
            FilterChip(s.theme == ThemeMode.LIGHT, { vm.setTheme(ThemeMode.LIGHT) }, { Text("Claro") })
            FilterChip(s.theme == ThemeMode.DARK, { vm.setTheme(ThemeMode.DARK) }, { Text("Oscuro") })
        }

        SectionTitle("Información")
        InfoCard(Modifier.padding(horizontal = 16.dp)) {
            Text("BlueChat 1.0.0", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Text(
                "Mensajería Bluetooth LE sin Internet. Sin cuentas, sin servidores, sin permiso de Internet.\n\n" +
                    "Seguridad: cifrado de extremo a extremo (X25519 + ChaCha20-Poly1305), firmas Ed25519. " +
                    "No hay secreto hacia adelante (forward secrecy) y los metadatos (quién escribe a quién, tamaño, hora) " +
                    "son visibles para los repetidores. Un teléfono con root puede extraer tus claves.\n\n" +
                    "Limitaciones: alcance de decenas de metros por salto; Android puede detener la app en segundo plano; " +
                    "una ruta de ida y vuelta es necesaria para recibir confirmaciones.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }

    if (editProfile) {
        var alias by remember { mutableStateOf(s.alias) }
        var avatar by remember { mutableStateOf(s.avatar) }
        AlertDialog(
            onDismissRequest = { editProfile = false },
            title = { Text("Editar perfil") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = alias,
                        onValueChange = { if (it.length <= 24) alias = it },
                        label = { Text("Nombre visible") },
                        singleLine = true
                    )
                    AvatarPicker(alias, avatar) { avatar = it }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = alias.trim().length >= 2,
                    onClick = { vm.setProfile(alias, avatar); editProfile = false }
                ) { Text("Guardar") }
            },
            dismissButton = { TextButton(onClick = { editProfile = false }) { Text("Cancelar") } }
        )
    }
}
