package com.bluechat.mesh.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothGattServer
import android.bluetooth.BluetoothGattServerCallback
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothStatusCodes
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.bluechat.mesh.core.Link
import com.bluechat.mesh.core.LinkEvents
import java.util.ArrayDeque
import kotlin.random.Random

/**
 * Conexiones GATT. Cada teléfono es a la vez:
 *  - servidor GATT (periférico): otros se conectan a él y le escriben en RX / reciben notificaciones en TX;
 *  - cliente GATT (central): se conecta a los teléfonos que descubre.
 * Cada conexión se expone al motor Mesh como un [Link] con cola de escritura ordenada y
 * control de flujo (una operación GATT en vuelo a la vez).
 */
@SuppressLint("MissingPermission")
class BluetoothGattManager(
    private val context: Context,
    private val events: LinkEvents,
    private val maxLinks: () -> Int
) {
    private val manager = context.getSystemService(BluetoothManager::class.java)
    private val handler = Handler(Looper.getMainLooper())
    private val lock = Any()

    private var server: BluetoothGattServer? = null
    private var txChar: BluetoothGattCharacteristic? = null

    private val links = HashMap<String, BaseLink>()          // id de enlace -> enlace activo
    private val clientGatts = java.util.concurrent.ConcurrentHashMap<String, BluetoothGatt>() // dirección -> GATT cliente en curso
    private val connecting = HashMap<String, Long>()          // dirección -> inicio del intento
    private val backoff = HashMap<String, Pair<Int, Long>>()   // dirección -> (fallos, no antes de)
    private val pendingMtu = HashMap<String, Int>()
    @Volatile private var running = false

    // ------------------------------------------------------------------ ciclo de vida

    /** Abre el servidor GATT; [onReady] se invoca cuando el servicio ya está registrado. */
    fun start(onReady: () -> Unit, onError: (String) -> Unit) {
        if (running) return
        val srv = try {
            manager?.openGattServer(context, serverCallback(onReady, onError))
        } catch (e: Exception) {
            null
        }
        if (srv == null) {
            onError("No se pudo abrir el servidor GATT.")
            return
        }
        server = srv
        running = true

        val service = BluetoothGattService(BleUuids.SERVICE, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        val rx = BluetoothGattCharacteristic(
            BleUuids.RX,
            BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE,
            BluetoothGattCharacteristic.PERMISSION_WRITE
        )
        val tx = BluetoothGattCharacteristic(
            BleUuids.TX, BluetoothGattCharacteristic.PROPERTY_NOTIFY, 0
        )
        tx.addDescriptor(
            BluetoothGattDescriptor(
                BleUuids.CCCD,
                BluetoothGattDescriptor.PERMISSION_READ or BluetoothGattDescriptor.PERMISSION_WRITE
            )
        )
        service.addCharacteristic(rx)
        service.addCharacteristic(tx)
        txChar = tx
        if (!srv.addService(service)) onError("No se pudo registrar el servicio GATT.")
    }

    fun stop() {
        running = false
        val toClose: List<BaseLink>
        synchronized(lock) {
            toClose = links.values.toList()
            links.clear()
            connecting.clear()
            pendingMtu.clear()
        }
        clientGatts.values.forEach { try { it.disconnect(); it.close() } catch (_: Exception) {} }
        clientGatts.clear()
        try { server?.close() } catch (_: Exception) {}
        server = null
        txChar = null
        toClose.forEach {
            it.markClosed()
            events.onLinkDown(it.id)
        }
    }

    fun linkCount(): Int = synchronized(lock) { links.size }

    /** Pide la señal (RSSI) de los enlaces en los que somos centrales. */
    fun tick() {
        val snapshot = synchronized(lock) { links.values.filterIsInstance<CentralLink>() }
        snapshot.forEach { try { it.gatt.readRemoteRssi() } catch (_: Exception) {} }
        val now = System.currentTimeMillis()
        // Intentos de conexión atascados
        val stuck = synchronized(lock) { connecting.filterValues { now - it > CONNECT_TIMEOUT_MS }.keys.toList() }
        stuck.forEach { addr ->
            clientGatts[addr]?.let { try { it.disconnect() } catch (_: Exception) {} }
            handler.postDelayed({ clientGatts.remove(addr)?.let { g -> try { g.close() } catch (_: Exception) {} } }, 2000)
            synchronized(lock) { connecting.remove(addr) }
            noteFailure(addr)
        }
    }

    // ------------------------------------------------------------------ conexión saliente (cliente)

    /** Intenta conectarse a un dispositivo descubierto. Idempotente y con retroceso ante fallos. */
    fun connect(device: BluetoothDevice, rssi: Int) {
        if (!running) return
        val addr = device.address ?: return
        val now = System.currentTimeMillis()
        synchronized(lock) {
            if (links.size + connecting.size >= maxLinks()) return
            if (links.containsKey("c:$addr") || links.containsKey("p:$addr") || connecting.containsKey(addr)) return
            val b = backoff[addr]
            if (b != null && now < b.second) return
            connecting[addr] = now
        }
        // Pequeña espera aleatoria: reduce conexiones cruzadas simultáneas entre dos teléfonos.
        handler.postDelayed({ doConnect(device, rssi) }, Random.nextLong(0, 900))
    }

    private fun doConnect(device: BluetoothDevice, rssi: Int) {
        val addr = device.address
        val skip = synchronized(lock) { !running || links.containsKey("p:$addr") || !connecting.containsKey(addr) }
        if (skip) {
            synchronized(lock) { connecting.remove(addr) }
            return
        }
        try {
            val cb = ClientCallback(device, rssi)
            val gatt = device.connectGatt(context, false, cb, BluetoothDevice.TRANSPORT_LE)
            if (gatt == null) {
                synchronized(lock) { connecting.remove(addr) }
                noteFailure(addr)
            } else {
                clientGatts[addr] = gatt
            }
        } catch (e: Exception) {
            synchronized(lock) { connecting.remove(addr) }
            noteFailure(addr)
        }
    }

    private fun noteFailure(addr: String) {
        synchronized(lock) {
            val fails = (backoff[addr]?.first ?: 0) + 1
            val wait = minOf(60_000L, 3_000L shl minOf(fails, 5))
            backoff[addr] = fails to (System.currentTimeMillis() + wait)
            if (backoff.size > 200) backoff.entries.removeAll { it.value.second < System.currentTimeMillis() }
        }
    }

    private fun noteSuccess(addr: String) {
        synchronized(lock) { backoff.remove(addr) }
    }

    // ------------------------------------------------------------------ enlaces

    private abstract inner class BaseLink(
        override val id: String,
        override val initiatedLocally: Boolean,
        mtu: Int
    ) : Link {
        @Volatile override var maxFrameBytes: Int = maxOf(20, mtu - 3)
        @Volatile override var rssi: Int? = null
        @Volatile var closed = false
        private val queue = ArrayDeque<ByteArray>()
        private var busy = false

        override fun send(frame: ByteArray): Boolean {
            synchronized(queue) {
                if (closed || queue.size >= MAX_QUEUE_FRAMES) return false
                queue.addLast(frame)
                pump()
            }
            return true
        }

        private fun pump() {
            if (busy) return
            val next = queue.pollFirst() ?: return
            busy = true
            if (!write(next)) {
                busy = false
                queue.clear()
                handler.post { close() }
            }
        }

        fun onWriteComplete(ok: Boolean) {
            synchronized(queue) {
                busy = false
                if (ok) pump() else {
                    queue.clear()
                    handler.post { close() }
                }
            }
        }

        fun markClosed() {
            closed = true
            synchronized(queue) { queue.clear() }
        }

        protected abstract fun write(frame: ByteArray): Boolean
    }

    private inner class CentralLink(
        val address: String,
        val gatt: BluetoothGatt,
        private val rx: BluetoothGattCharacteristic,
        mtu: Int
    ) : BaseLink("c:$address", true, mtu) {
        @Suppress("DEPRECATION")
        override fun write(frame: ByteArray): Boolean = try {
            if (Build.VERSION.SDK_INT >= 33) {
                gatt.writeCharacteristic(rx, frame, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) ==
                    BluetoothStatusCodes.SUCCESS
            } else {
                rx.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                rx.value = frame
                gatt.writeCharacteristic(rx)
            }
        } catch (e: Exception) {
            false
        }

        override fun close() {
            markClosed()
            try { gatt.disconnect() } catch (_: Exception) {}
            handler.postDelayed({ try { gatt.close() } catch (_: Exception) {} }, 3000)
        }
    }

    private inner class PeripheralLink(
        val device: BluetoothDevice,
        mtu: Int
    ) : BaseLink("p:${device.address}", false, mtu) {
        @Suppress("DEPRECATION")
        override fun write(frame: ByteArray): Boolean {
            val srv = server ?: return false
            val tx = txChar ?: return false
            return try {
                if (Build.VERSION.SDK_INT >= 33) {
                    srv.notifyCharacteristicChanged(device, tx, false, frame) == BluetoothStatusCodes.SUCCESS
                } else {
                    tx.value = frame
                    srv.notifyCharacteristicChanged(device, tx, false)
                }
            } catch (e: Exception) {
                false
            }
        }

        override fun close() {
            markClosed()
            try { server?.cancelConnection(device) } catch (_: Exception) {}
        }
    }

    private fun registerLink(link: BaseLink): Boolean {
        synchronized(lock) {
            if (!running || links.containsKey(link.id)) return false
            links[link.id] = link
        }
        return true
    }

    private fun dropLink(id: String) {
        val l = synchronized(lock) { links.remove(id) } ?: return
        l.markClosed()
        events.onLinkDown(id)
    }

    // ------------------------------------------------------------------ callbacks de cliente

    private inner class ClientCallback(val device: BluetoothDevice, val scanRssi: Int) : BluetoothGattCallback() {
        private var mtu = 23
        private var link: CentralLink? = null
        private val addr = device.address

        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                if (!gatt.requestMtu(REQUESTED_MTU)) gatt.discoverServices()
            } else {
                try { gatt.close() } catch (_: Exception) {}
                clientGatts.remove(addr)
                synchronized(lock) { connecting.remove(addr) }
                val l = link
                if (l != null) dropLink(l.id) else noteFailure(addr)
            }
        }

        override fun onMtuChanged(gatt: BluetoothGatt, mtu: Int, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) this.mtu = mtu
            gatt.discoverServices()
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            val svc = gatt.getService(BleUuids.SERVICE)
            val tx = svc?.getCharacteristic(BleUuids.TX)
            val rx = svc?.getCharacteristic(BleUuids.RX)
            val cccd = tx?.getDescriptor(BleUuids.CCCD)
            if (status != BluetoothGatt.GATT_SUCCESS || tx == null || rx == null || cccd == null) {
                noteFailure(addr)
                gatt.disconnect()
                return
            }
            gatt.setCharacteristicNotification(tx, true)
            val ok = writeCccd(gatt, cccd)
            if (!ok) {
                noteFailure(addr)
                gatt.disconnect()
            }
        }

        @Suppress("DEPRECATION")
        private fun writeCccd(gatt: BluetoothGatt, cccd: BluetoothGattDescriptor): Boolean = try {
            if (Build.VERSION.SDK_INT >= 33) {
                gatt.writeDescriptor(cccd, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE) ==
                    BluetoothStatusCodes.SUCCESS
            } else {
                cccd.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                gatt.writeDescriptor(cccd)
            }
        } catch (e: Exception) {
            false
        }

        override fun onDescriptorWrite(gatt: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
            if (descriptor.uuid != BleUuids.CCCD) return
            if (status != BluetoothGatt.GATT_SUCCESS) {
                noteFailure(addr)
                gatt.disconnect()
                return
            }
            val rx = gatt.getService(BleUuids.SERVICE)?.getCharacteristic(BleUuids.RX) ?: run {
                gatt.disconnect(); return
            }
            val l = CentralLink(addr, gatt, rx, mtu)
            l.rssi = scanRssi.takeIf { it != 0 && it > -127 }
            link = l
            synchronized(lock) { connecting.remove(addr) }
            if (!registerLink(l)) {
                gatt.disconnect()
                return
            }
            noteSuccess(addr)
            events.onLinkUp(l)
        }

        override fun onCharacteristicWrite(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            link?.onWriteComplete(status == BluetoothGatt.GATT_SUCCESS)
        }

        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            if (characteristic.uuid == BleUuids.TX) link?.let { events.onFrame(it.id, value) }
        }

        @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            if (Build.VERSION.SDK_INT >= 33) return // en 33+ llega por la sobrecarga con valor
            if (characteristic.uuid == BleUuids.TX) {
                val v = characteristic.value ?: return
                link?.let { events.onFrame(it.id, v.copyOf()) }
            }
        }

        override fun onReadRemoteRssi(gatt: BluetoothGatt, rssi: Int, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) link?.rssi = rssi
        }
    }

    // ------------------------------------------------------------------ callbacks de servidor

    private fun serverCallback(onReady: () -> Unit, onError: (String) -> Unit) = object : BluetoothGattServerCallback() {

        override fun onServiceAdded(status: Int, service: BluetoothGattService) {
            if (status == BluetoothGatt.GATT_SUCCESS) onReady() else onError("Error al registrar el servicio GATT ($status).")
        }

        override fun onConnectionStateChange(device: BluetoothDevice, status: Int, newState: Int) {
            val addr = device.address
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                val full = synchronized(lock) { links.size + connecting.size >= maxLinks() + 1 }
                if (full) try { server?.cancelConnection(device) } catch (_: Exception) {}
            } else {
                synchronized(lock) { pendingMtu.remove(addr) }
                dropLink("p:$addr")
            }
        }

        override fun onMtuChanged(device: BluetoothDevice, mtu: Int) {
            val addr = device.address
            synchronized(lock) {
                pendingMtu[addr] = mtu
                links["p:$addr"]?.maxFrameBytes = maxOf(20, mtu - 3)
            }
        }

        override fun onDescriptorWriteRequest(
            device: BluetoothDevice, requestId: Int, descriptor: BluetoothGattDescriptor,
            preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray?
        ) {
            val isCccd = descriptor.uuid == BleUuids.CCCD
            val enable = value != null && value.contentEquals(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
            if (responseNeeded) {
                try {
                    server?.sendResponse(
                        device, requestId,
                        if (isCccd) BluetoothGatt.GATT_SUCCESS else BluetoothGatt.GATT_FAILURE, 0, null
                    )
                } catch (_: Exception) {}
            }
            if (!isCccd || !enable) return
            val addr = device.address
            val mtu = synchronized(lock) { pendingMtu[addr] } ?: 23
            val l = PeripheralLink(device, mtu)
            if (registerLink(l)) {
                events.onLinkUp(l)
            }
        }

        override fun onCharacteristicWriteRequest(
            device: BluetoothDevice, requestId: Int, characteristic: BluetoothGattCharacteristic,
            preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray?
        ) {
            if (responseNeeded) {
                try { server?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, null) } catch (_: Exception) {}
            }
            if (characteristic.uuid != BleUuids.RX || value == null || value.isEmpty()) return
            val l = synchronized(lock) { links["p:${device.address}"] } ?: return
            events.onFrame(l.id, value.copyOf())
        }

        override fun onNotificationSent(device: BluetoothDevice, status: Int) {
            val l = synchronized(lock) { links["p:${device.address}"] } ?: return
            l.onWriteComplete(status == BluetoothGatt.GATT_SUCCESS)
        }
    }

    companion object {
        const val REQUESTED_MTU = 247
        const val MAX_QUEUE_FRAMES = 512
        const val CONNECT_TIMEOUT_MS = 20_000L
    }
}
