package com.bluechat.mesh.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import com.bluechat.mesh.core.CryptoManager
import com.bluechat.mesh.core.IdentityKeys
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Crea y protege la identidad criptográfica local.
 *
 * Las claves privadas (Ed25519 + X25519) se cifran con una clave AES-256-GCM que vive en el
 * Android Keystore (respaldada por hardware cuando el dispositivo lo ofrece) y el resultado se
 * guarda en el almacenamiento privado de la app, excluido de copias de seguridad.
 *
 * LIMITACIONES (documentadas, no ocultas):
 *  - Android Keystore no soporta nativamente Ed25519/X25519 en API 26-32, por eso se envuelven.
 *    Mientras la app corre, las claves privadas están en memoria del proceso.
 *  - Un dispositivo con root o comprometido puede extraer las claves en uso.
 *  - Si se desinstala la app o se borra su almacenamiento, la identidad se pierde (no hay copia
 *    de seguridad ni recuperación; es deliberado para no depender de servidores).
 *  - Si el Keystore falla, NO se guarda nada en claro: se informa del error.
 */
class IdentityManager(private val context: Context) {

    private val file: File get() = File(context.noBackupFilesDir, "identity.bin")

    @Volatile private var cached: IdentityKeys? = null

    fun hasIdentity(): Boolean = file.exists()

    @Synchronized
    fun load(): IdentityKeys? {
        cached?.let { return it }
        if (!file.exists()) return null
        return try {
            val blob = file.readBytes()
            val iv = blob.copyOfRange(0, IV_BYTES)
            val ct = blob.copyOfRange(IV_BYTES, blob.size)
            val cipher = Cipher.getInstance(TRANSFORM)
            cipher.init(Cipher.DECRYPT_MODE, wrapKey(), GCMParameterSpec(128, iv))
            val plain = cipher.doFinal(ct)
            val keys = CryptoManager.identityFromPrivate(plain.copyOfRange(0, 32), plain.copyOfRange(32, 64))
            cached = keys
            keys
        } catch (e: Exception) {
            null
        }
    }

    /** Genera una identidad nueva (sustituye a la anterior). Lanza si el Keystore no está disponible. */
    @Synchronized
    fun create(): IdentityKeys {
        val keys = CryptoManager.generateIdentity()
        val cipher = Cipher.getInstance(TRANSFORM)
        cipher.init(Cipher.ENCRYPT_MODE, wrapKey(createIfMissing = true))
        val ct = cipher.doFinal(keys.signPriv + keys.dhPriv)
        val tmp = File(file.parentFile, "identity.bin.tmp")
        tmp.writeBytes(cipher.iv + ct)
        if (!tmp.renameTo(file)) {
            file.writeBytes(tmp.readBytes())
            tmp.delete()
        }
        cached = keys
        return keys
    }

    private fun wrapKey(createIfMissing: Boolean = false): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        check(createIfMissing) { "Clave del Keystore no encontrada" }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    companion object {
        private const val KEY_ALIAS = "bluechat_identity_wrap_v1"
        private const val TRANSFORM = "AES/GCM/NoPadding"
        private const val IV_BYTES = 12
    }
}
