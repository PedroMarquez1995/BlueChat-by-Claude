package com.bluechat.mesh.core

/**
 * Fragmentación a nivel de enlace. Cada trama BLE tiene la forma:
 *   fragId(2) | index(1) | total(1) | datos...
 * El tamaño de datos depende del MTU negociado (MTU - 3 bytes de ATT - 4 de cabecera).
 */
object Fragmenter {
    const val FRAME_HEADER = 4
    const val MIN_FRAME = 8
    const val MAX_FRAGMENTS = 255

    /** Divide [packet] en tramas de como máximo [maxFrameBytes] bytes. */
    fun split(packet: ByteArray, maxFrameBytes: Int, fragId: Int): List<ByteArray> {
        require(maxFrameBytes >= MIN_FRAME) { "MTU demasiado pequeño" }
        val chunk = maxFrameBytes - FRAME_HEADER
        val total = (packet.size + chunk - 1) / chunk
        require(total in 1..MAX_FRAGMENTS) { "Paquete demasiado grande para fragmentar" }
        val frames = ArrayList<ByteArray>(total)
        for (i in 0 until total) {
            val from = i * chunk
            val to = minOf(packet.size, from + chunk)
            val f = ByteArray(FRAME_HEADER + (to - from))
            f[0] = (fragId ushr 8).toByte()
            f[1] = fragId.toByte()
            f[2] = i.toByte()
            f[3] = total.toByte()
            System.arraycopy(packet, from, f, FRAME_HEADER, to - from)
            frames.add(f)
        }
        return frames
    }
}

/**
 * Reensambla tramas de UN enlace. Limita sesiones simultáneas y tamaño, y caduca las incompletas
 * para impedir agotamiento de memoria por tramas maliciosas.
 */
class Reassembler(
    private val clock: WallClock,
    private val maxSessions: Int = 8,
    private val timeoutMs: Long = 30_000,
    private val maxBytes: Int = MeshPacket.MAX_PACKET_BYTES
) {
    private class Session(val total: Int, val startedAt: Long) {
        val parts = arrayOfNulls<ByteArray>(total)
        var received = 0
        var bytes = 0
    }

    private val sessions = LinkedHashMap<Int, Session>()

    /** Devuelve el paquete completo cuando llega la última trama; si no, null. */
    fun accept(frame: ByteArray): ByteArray? {
        if (frame.size <= Fragmenter.FRAME_HEADER) return null
        val now = clock.now()
        purge(now)
        val fragId = ((frame[0].toInt() and 0xFF) shl 8) or (frame[1].toInt() and 0xFF)
        val index = frame[2].toInt() and 0xFF
        val total = frame[3].toInt() and 0xFF
        if (total < 1 || index >= total) return null

        if (total == 1) return frame.copyOfRange(Fragmenter.FRAME_HEADER, frame.size)

        var s = sessions[fragId]
        if (s == null) {
            if (sessions.size >= maxSessions) {
                val oldest = sessions.keys.first()
                sessions.remove(oldest)
            }
            s = Session(total, now)
            sessions[fragId] = s
        } else if (s.total != total) {
            sessions.remove(fragId) // inconsistente: se descarta
            return null
        }
        if (s.parts[index] != null) return null // duplicada
        val data = frame.copyOfRange(Fragmenter.FRAME_HEADER, frame.size)
        s.bytes += data.size
        if (s.bytes > maxBytes) {
            sessions.remove(fragId)
            return null
        }
        s.parts[index] = data
        s.received++
        if (s.received < s.total) return null

        sessions.remove(fragId)
        val out = ByteArray(s.bytes)
        var off = 0
        for (p in s.parts) {
            System.arraycopy(p!!, 0, out, off, p.size)
            off += p.size
        }
        return out
    }

    fun purge(now: Long = clock.now()) {
        val it = sessions.entries.iterator()
        while (it.hasNext()) {
            if (now - it.next().value.startedAt > timeoutMs) it.remove()
        }
    }

    fun pendingSessions(): Int = sessions.size
}
