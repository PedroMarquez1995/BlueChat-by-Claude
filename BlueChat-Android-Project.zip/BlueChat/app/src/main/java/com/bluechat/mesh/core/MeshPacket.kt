package com.bluechat.mesh.core

import java.nio.BufferUnderflowException
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * PROTOCOLO BLUECHAT MESH v1 (ver docs/PROTOCOL.md)
 *
 * Paquete (big-endian):
 *  offset  tamaño  campo
 *   0      1       version (=1)
 *   1      1       type    (1 HELLO, 2 DATA, 3 ACK)
 *   2      1       flags   (bit0 = firmado)
 *   3      1       ttl     (saltos restantes; MUTABLE por los repetidores)
 *   4      1       hops    (saltos recorridos; MUTABLE por los repetidores)
 *   5      8       msgId   (aleatorio)
 *  13      8       origin  (id del nodo emisor)
 *  21      8       dest    (id del destinatario; 0 = difusión, solo HELLO)
 *  29      8       timestamp (ms epoch del emisor)
 *  37      2       validityMin (minutos de validez)
 *  39      2       payloadLen
 *  41      n       payload
 *  41+n    64      firma Ed25519 (si flags.bit0)
 *
 * La firma cubre todo EXCEPTO ttl y hops (los modifican los repetidores).
 */
object PacketType {
    const val HELLO = 1
    const val DATA = 2
    const val ACK = 3
}

object PacketFlags {
    const val SIGNED = 0x01
}

class MeshPacket(
    val version: Int,
    val type: Int,
    val flags: Int,
    val ttl: Int,
    val hops: Int,
    val msgId: ByteArray,
    val origin: ByteArray,
    val dest: ByteArray,
    val timestamp: Long,
    val validityMin: Int,
    val payload: ByteArray,
    val signature: ByteArray?
) {
    val msgIdHex: String get() = Hex.encode(msgId)
    val originHex: String get() = Hex.encode(origin)
    val destHex: String get() = Hex.encode(dest)

    /** Clave única de deduplicación. */
    val key: String get() = originHex + msgIdHex

    val isBroadcast: Boolean get() = destHex == NodeIds.BROADCAST

    fun withHop(newTtl: Int = ttl - 1, newHops: Int = hops + 1) = MeshPacket(
        version, type, flags, newTtl, newHops, msgId, origin, dest,
        timestamp, validityMin, payload, signature
    )

    fun withSignature(sig: ByteArray) = MeshPacket(
        version, type, flags or PacketFlags.SIGNED, ttl, hops, msgId, origin, dest,
        timestamp, validityMin, payload, sig
    )

    /** Cabecera inmutable: se usa como AAD del cifrado y como parte de lo firmado. */
    fun authHeader(): ByteArray {
        val b = ByteBuffer.allocate(AUTH_HEADER_SIZE).order(ByteOrder.BIG_ENDIAN)
        b.put(version.toByte()).put(type.toByte()).put((flags or PacketFlags.SIGNED).toByte())
        b.put(msgId).put(origin).put(dest).putLong(timestamp).putShort(validityMin.toShort())
        return b.array()
    }

    /** Bytes que cubre la firma. */
    fun signedBytes(): ByteArray = authHeader() + payload

    fun encode(): ByteArray {
        val sigLen = if (signature != null) SIGNATURE_SIZE else 0
        val b = ByteBuffer.allocate(HEADER_SIZE + payload.size + sigLen).order(ByteOrder.BIG_ENDIAN)
        b.put(version.toByte()).put(type.toByte()).put(flags.toByte())
        b.put(ttl.toByte()).put(hops.toByte())
        b.put(msgId).put(origin).put(dest)
        b.putLong(timestamp).putShort(validityMin.toShort()).putShort(payload.size.toShort())
        b.put(payload)
        if (signature != null) b.put(signature)
        return b.array()
    }

    companion object {
        const val VERSION = 1
        const val HEADER_SIZE = 41
        const val AUTH_HEADER_SIZE = 3 + 8 + 8 + 8 + 8 + 2
        const val SIGNATURE_SIZE = 64
        const val MAX_PAYLOAD = 1200
        const val MAX_PACKET_BYTES = HEADER_SIZE + MAX_PAYLOAD + SIGNATURE_SIZE
        const val MAX_VALIDITY_MIN = 1440
        const val MAX_HOPS_FIELD = 32

        /** Decodifica y VALIDA. Devuelve null ante cualquier anomalía (nunca lanza). */
        fun decode(data: ByteArray): MeshPacket? {
            if (data.size < HEADER_SIZE || data.size > MAX_PACKET_BYTES) return null
            return try {
                val b = ByteBuffer.wrap(data).order(ByteOrder.BIG_ENDIAN)
                val version = b.get().toInt() and 0xFF
                val type = b.get().toInt() and 0xFF
                val flags = b.get().toInt() and 0xFF
                val ttl = b.get().toInt() and 0xFF
                val hops = b.get().toInt() and 0xFF
                val msgId = ByteArray(8).also { b.get(it) }
                val origin = ByteArray(8).also { b.get(it) }
                val dest = ByteArray(8).also { b.get(it) }
                val ts = b.getLong()
                val validity = b.getShort().toInt() and 0xFFFF
                val len = b.getShort().toInt() and 0xFFFF

                if (version != VERSION) return null
                if (type != PacketType.HELLO && type != PacketType.DATA && type != PacketType.ACK) return null
                if (flags and PacketFlags.SIGNED.inv() != 0) return null // flags desconocidos
                if (ttl > MAX_HOPS_FIELD || hops > MAX_HOPS_FIELD) return null
                if (validity < 1 || validity > MAX_VALIDITY_MIN) return null
                if (len > MAX_PAYLOAD) return null
                val signed = flags and PacketFlags.SIGNED != 0
                val expected = HEADER_SIZE + len + if (signed) SIGNATURE_SIZE else 0
                if (data.size != expected) return null
                if (ts <= 0) return null
                val destHex = Hex.encode(dest)
                if (type != PacketType.HELLO && destHex == NodeIds.BROADCAST) return null
                if (Hex.encode(origin) == NodeIds.BROADCAST) return null

                val payload = ByteArray(len).also { b.get(it) }
                val sig = if (signed) ByteArray(SIGNATURE_SIZE).also { b.get(it) } else null
                MeshPacket(version, type, flags, ttl, hops, msgId, origin, dest, ts, validity, payload, sig)
            } catch (e: BufferUnderflowException) {
                null
            } catch (e: RuntimeException) {
                null
            }
        }
    }
}

/** Contenido (ya descifrado) de un mensaje DATA/ACK. */
object InnerKind {
    const val TEXT = 1
    const val ACK_DELIVERED = 2
    const val ACK_READ = 3
}
