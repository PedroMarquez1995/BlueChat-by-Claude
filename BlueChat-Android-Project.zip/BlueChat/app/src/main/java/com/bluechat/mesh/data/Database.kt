package com.bluechat.mesh.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "nodes")
class NodeEntity(
    @PrimaryKey val nodeId: String,
    val alias: String,
    val avatar: Int,
    val signPub: ByteArray,
    val dhPub: ByteArray,
    val relayCapable: Boolean,
    val lastSeen: Long,
    val isContact: Boolean,
    val blocked: Boolean,
    val verified: Boolean
)

@Entity(tableName = "mesh_queue")
class QueueEntity(
    @PrimaryKey val key: String,
    /** Paquete CIFRADO tal cual viaja por la red. Nunca texto en claro. */
    val packet: ByteArray,
    val receivedAt: Long,
    val own: Boolean,
    val sentTo: String,
    val waves: Int,
    val lastAttemptAt: Long
)

@Entity(tableName = "seen")
class SeenEntity(@PrimaryKey val key: String, val at: Long)

@Entity(
    tableName = "messages",
    indices = [Index(value = ["peerId", "msgId", "outgoing"], unique = true), Index("peerId")]
)
class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val peerId: String,
    val msgId: String,
    val outgoing: Boolean,
    val text: String,
    val timestamp: Long,
    /** Ordinal de [com.bluechat.mesh.core.DeliveryStatus]; en mensajes entrantes se ignora. */
    val status: Int,
    val hops: Int,
    val read: Boolean
)

class UnreadCount(val peerId: String, val cnt: Int)
class PendingCount(val peerId: String, val cnt: Int)

@Dao
interface NodeDao {
    @Query("SELECT * FROM nodes WHERE nodeId = :id") fun get(id: String): NodeEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) fun put(node: NodeEntity)
    @Query("SELECT * FROM nodes") fun all(): List<NodeEntity>
    @Query("SELECT * FROM nodes") fun observeAll(): Flow<List<NodeEntity>>
    @Query("UPDATE nodes SET isContact = :v WHERE nodeId = :id") fun setContact(id: String, v: Boolean)
    @Query("UPDATE nodes SET verified = :v WHERE nodeId = :id") fun setVerified(id: String, v: Boolean)
    @Query("UPDATE nodes SET blocked = :v WHERE nodeId = :id") fun setBlocked(id: String, v: Boolean)
    @Query("SELECT COUNT(*) FROM nodes") fun count(): Int
    @Query(
        "DELETE FROM nodes WHERE nodeId IN (SELECT nodeId FROM nodes WHERE isContact = 0 AND blocked = 0 " +
            "ORDER BY lastSeen ASC LIMIT :n)"
    )
    fun deleteOldestAnonymous(n: Int)
}

@Dao
interface QueueDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) fun put(e: QueueEntity)
    @Query("SELECT * FROM mesh_queue ORDER BY receivedAt ASC") fun all(): List<QueueEntity>
    @Query("SELECT * FROM mesh_queue WHERE `key` = :key") fun get(key: String): QueueEntity?
    @Query("DELETE FROM mesh_queue WHERE `key` = :key") fun delete(key: String)
    @Query("SELECT COUNT(*) FROM mesh_queue") fun count(): Int
}

@Dao
interface SeenDao {
    @Query("SELECT COUNT(*) FROM seen WHERE `key` = :key") fun has(key: String): Int
    @Insert(onConflict = OnConflictStrategy.REPLACE) fun put(s: SeenEntity)
    @Query("DELETE FROM seen WHERE at < :olderThan") fun purge(olderThan: Long)
}

@Dao
interface MessageDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE) fun insert(m: MessageEntity): Long

    @Query("SELECT * FROM messages WHERE peerId = :peer ORDER BY timestamp ASC, id ASC")
    fun observeConversation(peer: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE id IN (SELECT MAX(id) FROM messages GROUP BY peerId) ORDER BY timestamp DESC")
    fun observeLatestPerPeer(): Flow<List<MessageEntity>>

    @Query("SELECT peerId, COUNT(*) AS cnt FROM messages WHERE outgoing = 0 AND read = 0 GROUP BY peerId")
    fun observeUnread(): Flow<List<UnreadCount>>

    @Query("SELECT peerId, COUNT(*) AS cnt FROM messages WHERE outgoing = 1 AND status IN (0,1,2) GROUP BY peerId")
    fun observePending(): Flow<List<PendingCount>>

    @Query("SELECT status FROM messages WHERE peerId = :peer AND msgId = :msgId AND outgoing = 1")
    fun statusOf(peer: String, msgId: String): Int?

    @Query("UPDATE messages SET status = :status WHERE peerId = :peer AND msgId = :msgId AND outgoing = 1")
    fun setStatus(peer: String, msgId: String, status: Int)

    @Query("SELECT * FROM messages WHERE peerId = :peer AND outgoing = 0 AND read = 0")
    fun unreadFrom(peer: String): List<MessageEntity>

    @Query("UPDATE messages SET read = 1 WHERE peerId = :peer AND outgoing = 0")
    fun markRead(peer: String)

    @Query("DELETE FROM messages WHERE peerId = :peer") fun deleteConversation(peer: String)
}

@Database(
    entities = [NodeEntity::class, QueueEntity::class, SeenEntity::class, MessageEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun nodes(): NodeDao
    abstract fun queue(): QueueDao
    abstract fun seen(): SeenDao
    abstract fun messages(): MessageDao
}
