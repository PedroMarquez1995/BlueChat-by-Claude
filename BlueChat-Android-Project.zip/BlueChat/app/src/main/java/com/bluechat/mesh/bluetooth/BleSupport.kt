package com.bluechat.mesh.bluetooth

import android.Manifest
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import java.util.UUID

object BleUuids {
    val SERVICE: UUID = UUID.fromString("7b1e0001-5a3c-4f6e-9b21-bc1e5a0c0001")

    /** El central ESCRIBE aquí (central -> periférico). */
    val RX: UUID = UUID.fromString("7b1e0002-5a3c-4f6e-9b21-bc1e5a0c0001")

    /** El periférico NOTIFICA aquí (periférico -> central). */
    val TX: UUID = UUID.fromString("7b1e0003-5a3c-4f6e-9b21-bc1e5a0c0001")
    val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
}

/** Capacidades reales del teléfono, consultadas antes de anunciar o conectar. */
data class BleCapabilities(
    val hasBleHardware: Boolean,
    val bluetoothOn: Boolean,
    val canScan: Boolean,
    val canAdvertise: Boolean
) {
    /** Mensaje comprensible cuando el dispositivo no puede participar, o null si todo está bien. */
    fun problem(): String? = when {
        !hasBleHardware -> "Este teléfono no tiene Bluetooth Low Energy: BlueChat no puede funcionar aquí."
        !bluetoothOn -> "Bluetooth está apagado. Actívalo para participar en la red."
        !canScan -> "No se pudo iniciar el escaneo Bluetooth LE."
        else -> null
    }

    companion object {
        fun read(context: Context): BleCapabilities {
            val hasBle = context.packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)
            val adapter = context.getSystemService(BluetoothManager::class.java)?.adapter
            val on = adapter?.isEnabled == true
            return BleCapabilities(
                hasBleHardware = hasBle && adapter != null,
                bluetoothOn = on,
                canScan = on && adapter?.bluetoothLeScanner != null,
                canAdvertise = on && adapter?.bluetoothLeAdvertiser != null
            )
        }
    }
}

object BlePermissions {
    /** Permisos de ejecución necesarios para participar en la red según la versión de Android. */
    fun required(): Array<String> = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_ADVERTISE
        )
        // Android 8-11: el escaneo BLE exige ubicación (no se usa el GPS para nada más).
        else -> arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    fun notification(): Array<String> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) arrayOf(Manifest.permission.POST_NOTIFICATIONS)
        else emptyArray()

    fun hasBluetooth(context: Context): Boolean = required().all {
        ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
    }

    fun hasNotifications(context: Context): Boolean = notification().all {
        ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
    }

    fun missing(context: Context): List<String> = (required() + notification()).filter {
        ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
    }
}
