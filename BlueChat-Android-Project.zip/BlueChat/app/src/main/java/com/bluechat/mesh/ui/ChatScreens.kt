@file:OptIn(ExperimentalMaterial3Api::class)

package com.bluechat.mesh.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.bluechat.mesh.BlueChatApplication
import com.bluechat.mesh.core.DeliveryStatus
import com.bluechat.mesh.core.NodeIds
import com.bluechat.mesh.data.MessageEntity
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState

@Composable
fun ChatScreen(app: BlueChatApplication, peerId: String, onBack: () -> Unit, onOpenContact: () -> Unit) {
    val vm: ChatViewModel = viewModel(key = "chat-$peerId", factory = AppViewModelFactory(app, peerId))
    val messages by vm.messages.collectAsStateWithLifecycle()
    val peer by vm.peer.collectAsStateWithLifecycle()
    val live by vm.live.collectAsStateWithLifecycle()
    val notice by vm.notice.collectAsStateWithLifecycle()
    val transport by vm.transport.collectAsStateWithLifecycle()

    var draft by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()
    val snackbar = remember { SnackbarHostState() }

    DisposableEffect(peerId) {
        vm.setActive(true)
        onDispose { vm.setActive(false) }
    }
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
            vm.markRead()
        }
    }
    LaunchedEffect(notice) {
        notice?.let { snackbar.showSnackbar(it); vm.clearNotice() }
    }

    val alias = peer?.alias ?: "Usuario ${NodeIds.short(peerId)}"
    val blocked = peer?.blocked == true

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver") }
                },
                title = {
                    Row(Modifier.clickable(onClick = onOpenContact), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(alias, peer?.avatar ?: 0, 38.dp)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(alias, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            val tag = if (peer?.verified == true) " · verificado" else ""
                            Text(
                                connectionLabel(live) + tag,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (live?.direct == true) Color(0xFF2E9E5B) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = onOpenContact) { Icon(Icons.Filled.Info, contentDescription = "Información del contacto") }
                }
            )
        },
        bottomBar = {
            Column(Modifier.navigationBarsPadding().imePadding()) {
                if (!transport.running) {
                    Text(
                        "La malla está detenida: los mensajes quedan pendientes hasta que actives la participación en Inicio.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                }
                if (blocked) {
                    Text(
                        "Contacto bloqueado. Desbloquéalo en su ficha para enviar y recibir mensajes.",
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(16.dp)
                    )
                } else {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.Bottom
                    ) {
                        OutlinedTextField(
                            value = draft,
                            onValueChange = { draft = it },
                            placeholder = { Text("Mensaje cifrado") },
                            modifier = Modifier.weight(1f),
                            maxLines = 5,
                            shape = RoundedCornerShape(24.dp),
                            supportingText = {
                                val bytes = draft.toByteArray(Charsets.UTF_8).size
                                if (bytes > 500) Text("$bytes / 600 bytes")
                            }
                        )
                        Spacer(Modifier.width(8.dp))
                        Button(
                            onClick = { vm.send(draft) { draft = "" } },
                            enabled = draft.isNotBlank(),
                            shape = RoundedCornerShape(50),
                            contentPadding = ButtonDefaults.ContentPadding,
                            modifier = Modifier.padding(bottom = 22.dp)
                        ) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Enviar") }
                    }
                }
            }
        }
    ) { padding ->
        if (messages.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                EmptyState(
                    "Sin mensajes todavía",
                    "Los mensajes viajan cifrados de extremo a extremo. Si no hay ruta, quedarán pendientes y se enviarán cuando aparezca un vecino."
                )
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(messages, key = { it.id }) { m -> MessageBubble(m) }
            }
        }
    }
}

@Composable
private fun MessageBubble(m: MessageEntity) {
    val mine = m.outgoing
    val bg = if (mine) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
    val fg = if (mine) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
    val status = if (mine) DeliveryStatus.values().getOrNull(m.status) else null

    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Column(
            Modifier.widthIn(max = 300.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 18.dp, topEnd = 18.dp,
                        bottomStart = if (mine) 18.dp else 4.dp, bottomEnd = if (mine) 4.dp else 18.dp
                    )
                )
                .background(bg)
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Text(m.text, color = fg)
            Spacer(Modifier.height(2.dp))
            Row(Modifier.align(Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                Text(formatTime(m.timestamp), style = MaterialTheme.typography.labelSmall, color = fg.copy(alpha = 0.75f))
                if (status != null) {
                    Spacer(Modifier.width(6.dp))
                    Text(
                        statusGlyph(status),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (status == DeliveryStatus.READ) Color(0xFF7DF9FF) else fg.copy(alpha = 0.85f)
                    )
                }
                if (!mine && m.hops > 1) {
                    Spacer(Modifier.width(6.dp))
                    Text("${m.hops} saltos", style = MaterialTheme.typography.labelSmall, color = fg.copy(alpha = 0.6f))
                }
            }
            if (status != null) {
                Text(
                    statusLabel(status),
                    style = MaterialTheme.typography.labelSmall,
                    color = fg.copy(alpha = 0.7f),
                    modifier = Modifier.align(Alignment.End)
                )
            }
        }
    }
}

@Composable
fun ContactScreen(app: BlueChatApplication, peerId: String, onBack: () -> Unit, onChat: () -> Unit) {
    val vm: ContactViewModel = viewModel(key = "contact-$peerId", factory = AppViewModelFactory(app, peerId))
    val peer by vm.peer.collectAsStateWithLifecycle()
    val live by vm.live.collectAsStateWithLifecycle()
    var confirmDelete by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Contacto") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver") }
                }
            )
        }
    ) { padding ->
        val p = peer
        if (p == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                EmptyState("Contacto desconocido", "Aún no se ha recibido la identidad de este usuario por Bluetooth.")
            }
            return@Scaffold
        }
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(p.alias, p.avatar, 64.dp)
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(p.alias, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(connectionLabel(live), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Visto: ${agoText(p.lastSeen)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            InfoCard {
                Text("Verificación de identidad", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Para asegurarte de que hablas con la persona correcta (y no con alguien que se hace pasar por ella), " +
                        "compara estos números EN PERSONA con los que muestra su teléfono en su ficha. Deben ser idénticos.",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(10.dp))
                Text("Huella de ${p.alias}", style = MaterialTheme.typography.labelMedium)
                Text(vm.fingerprintOf(p), style = MaterialTheme.typography.bodyLarge, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                Spacer(Modifier.height(8.dp))
                Text("Tu huella", style = MaterialTheme.typography.labelMedium)
                Text(vm.myFingerprint, style = MaterialTheme.typography.bodyLarge, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                Spacer(Modifier.height(6.dp))
                Text("ID: ${p.nodeId}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(10.dp))
                if (p.verified) {
                    OutlinedButton(onClick = { vm.setVerified(false) }) { Text("Quitar verificación") }
                } else {
                    Button(onClick = { vm.setVerified(true) }) { Text("Coinciden: marcar como verificado") }
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    "La lectura de códigos QR no está implementada en esta versión; la comparación de huellas es el método disponible.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Button(onClick = onChat, modifier = Modifier.fillMaxWidth(), enabled = !p.blocked) { Text("Enviar mensaje") }
            if (p.isContact) {
                OutlinedButton(onClick = { vm.setContact(false) }, modifier = Modifier.fillMaxWidth()) { Text("Quitar de contactos") }
            } else {
                OutlinedButton(onClick = { vm.setContact(true) }, modifier = Modifier.fillMaxWidth()) { Text("Agregar a contactos") }
            }
            OutlinedButton(onClick = { vm.setBlocked(!p.blocked) }, modifier = Modifier.fillMaxWidth()) {
                Text(if (p.blocked) "Desbloquear" else "Bloquear", color = MaterialTheme.colorScheme.error)
            }
            OutlinedButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Borrar conversación", color = MaterialTheme.colorScheme.error)
            }
        }
    }

    if (confirmDelete) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("¿Borrar la conversación?") },
            text = { Text("Se eliminará el historial local de este chat. No afecta al otro teléfono.") },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = { vm.deleteConversation(); confirmDelete = false }) { Text("Borrar") }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { confirmDelete = false }) { Text("Cancelar") }
            }
        )
    }
}
