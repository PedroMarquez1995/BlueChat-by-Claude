package com.bluechat.mesh.core

/**
 * Un enlace punto a punto con un vecino (en producción, una conexión GATT; en pruebas, un
 * enlace simulado en memoria). El motor Mesh solo conoce esta interfaz, nunca Bluetooth.
 */
interface Link {
    /** Identificador local del enlace (p. ej. dirección GATT). NO es la identidad del usuario. */
    val id: String

    /** true si este teléfono inició la conexión (rol central). */
    val initiatedLocally: Boolean

    /** Tamaño máximo de una trama (MTU - 3), puede crecer tras negociar el MTU. */
    val maxFrameBytes: Int

    /** Última intensidad de señal medida, o null si no hay medición válida. */
    val rssi: Int?

    /** Encola una trama para envío ordenado. false si el enlace está cerrado o saturado. */
    fun send(frame: ByteArray): Boolean

    fun close()
}

/** Contrato que el motor expone a cualquier transporte (BLE real o simulado). */
interface LinkEvents {
    fun onLinkUp(link: Link)
    fun onLinkDown(linkId: String)
    fun onFrame(linkId: String, frame: ByteArray)
}
