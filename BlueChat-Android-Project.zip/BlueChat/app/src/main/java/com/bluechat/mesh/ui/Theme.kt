package com.bluechat.mesh.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape
import com.bluechat.mesh.data.ThemeMode

val BcBlue = Color(0xFF1E6BFF)
val BcNavy = Color(0xFF0A1F44)
val BcElectric = Color(0xFF00B2FF)

private val LightColors = lightColorScheme(
    primary = BcBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD9E5FF),
    onPrimaryContainer = BcNavy,
    secondary = BcElectric,
    onSecondary = Color.White,
    tertiary = Color(0xFF0057D9),
    background = Color(0xFFF6F8FD),
    onBackground = Color(0xFF0B1220),
    surface = Color.White,
    onSurface = Color(0xFF0B1220),
    surfaceVariant = Color(0xFFE6ECF7),
    onSurfaceVariant = Color(0xFF45506A),
    error = Color(0xFFD32F2F)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF6FA0FF),
    onPrimary = Color(0xFF002564),
    primaryContainer = Color(0xFF123A8C),
    onPrimaryContainer = Color(0xFFD9E5FF),
    secondary = BcElectric,
    onSecondary = Color(0xFF00232F),
    tertiary = Color(0xFF8FB6FF),
    background = Color(0xFF0B1220),
    onBackground = Color(0xFFE4E9F5),
    surface = Color(0xFF111B30),
    onSurface = Color(0xFFE4E9F5),
    surfaceVariant = Color(0xFF1B2745),
    onSurfaceVariant = Color(0xFFA9B4CE),
    error = Color(0xFFFF8A80)
)

private val BcShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun BlueChatTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        shapes = BcShapes,
        content = content
    )
}
