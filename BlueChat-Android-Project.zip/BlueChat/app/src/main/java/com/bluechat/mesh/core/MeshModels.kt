package com.bluechat.mesh.core

/** Estado de entrega de un mensaje saliente. Solo DELIVERED/READ implican confirmación del destinatario. */
enum class DeliveryStatus {
    /** Guardado localmente, aún sin entregar a ningún vecino. */
    PENDING,
    /** Entregado a un vecino que ES el destinatario (aún sin confirmación criptográfica). */
    SENT,
    /** Entregado a un vecino intermediario que debe retransmitirlo. */
    RELAYING,
    /** El destinatario confirmó la recepción con un ACK firmado. */
    DELIVERED,
    /** El destinatario confirmó la lectura. */
    READ,
    /** No entregado / caducado sin confirmación. */
    FAILED;

    val rank: Int get() = ordinal
}

data class MeshConfig(
    val maxHops: Int = 6,
    val validityMinutes: Int = 1440,
    val relayEnabled: Boolean = true,
    val maxQueue: Int = 200,
    val maxLinks: Int = 5,
    val helloIntervalMs: Long = 30_000,
    val helloTtl: Int = 3,
    val retryIntervalMs: Long = 20_000,
    val maxWaves: Int = 4,
    val fanout: Int = 2,
    val routeTtlMs: Long = 10 * 60_000L,
    val maxTextBytes: Int = 600,
    val maxPacketsPerOriginPerMinute: Int = 40
)

/** Datos del perfil propio que se anuncian a los vecinos. */
data class Profile(val alias: String, val avatar: Int)

/** Registro persistente de un nodo conocido (contacto potencial). */
data class NodeRecord(
    val nodeId: String,
    val alias: String,
    val avatar: Int,
    val signPub: ByteArray,
    val dhPub: ByteArray,
    val relayCapable: Boolean,
    val lastSeen: Long,
    val isContact: Boolean = false,
    val blocked: Boolean = false,
    val verified: Boolean = false
) {
    val fingerprint: String get() = CryptoManager.fingerprint(signPub, dhPub)
}

/** Vista de un nodo para la interfaz. hops: 1 = vecino directo; 0 = desconocido. */
data class NodeInfo(
    val nodeId: String,
    val alias: String,
    val avatar: Int,
    val hops: Int,
    val direct: Boolean,
    val viaNodeId: String?,
    val lastSeen: Long,
    val isContact: Boolean,
    val blocked: Boolean,
    val verified: Boolean,
    val relayCapable: Boolean
)

data class NeighborInfo(
    val linkId: String,
    val nodeId: String?,
    val alias: String?,
    val since: Long,
    val rssi: Int?
)

data class IncomingMessage(
    val msgId: String,
    val from: String,
    val text: String,
    val timestamp: Long,
    val hops: Int
)

data class MeshStats(
    val queued: Int,
    val relayed: Long,
    val sent: Long,
    val received: Long,
    val duplicatesDropped: Long,
    val invalidDropped: Long,
    val rateLimited: Long,
    val lastActivity: Long
)

/**
 * Eventos del motor hacia la aplicación. Se invocan con el cerrojo del motor tomado:
 * las implementaciones deben ser rápidas y NO llamar de vuelta al motor (publicar en un Flow/canal).
 */
interface MeshListener {
    fun onNeighborsChanged(neighbors: List<NeighborInfo>) {}
    fun onNodeUpdated(node: NodeInfo) {}
    fun onMessageReceived(message: IncomingMessage) {}
    /** peerNodeId = destinatario del mensaje saliente, para validar que el ACK viene de quien debe. */
    fun onOutgoingStatus(msgId: String, peerNodeId: String, status: DeliveryStatus) {}
    fun onStatsChanged() {}
}

sealed class SendResult {
    data class Queued(val msgId: String) : SendResult()
    object UnknownRecipient : SendResult()
    object TooLong : SendResult()
    object Blocked : SendResult()
    object Empty : SendResult()
    object CryptoFailure : SendResult()
}
