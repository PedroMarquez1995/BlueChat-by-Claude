package com.bluechat.mesh

import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.lifecycleScope
import com.bluechat.mesh.bluetooth.BlePermissions
import com.bluechat.mesh.service.MeshService
import com.bluechat.mesh.ui.AppActions
import com.bluechat.mesh.ui.BlueChatApp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private var openPeer by mutableStateOf<String?>(null)
    private var permissionsVersion by mutableIntStateOf(0)
    private var startAfterPermissions = false

    private val app get() = application as BlueChatApplication

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            permissionsVersion++
            if (startAfterPermissions && BlePermissions.hasBluetooth(this)) startMesh()
            startAfterPermissions = false
        }

    private val enableBluetoothLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (BlePermissions.hasBluetooth(this)) startMesh()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        openPeer = intent?.getStringExtra(EXTRA_PEER)

        val actions = AppActions(
            startMesh = { requestAndStart() },
            stopMesh = { MeshService.stop(this) },
            enableBluetooth = { requestEnableBluetooth() },
            openAppSettings = {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null))
                )
            },
            openBatterySettings = { openBatterySettings() }
        )

        setContent {
            BlueChatApp(
                app = app,
                actions = actions,
                requestPermissions = { permissionLauncher.launch(BlePermissions.required() + BlePermissions.notification()) },
                openPeer = openPeer,
                onPeerConsumed = { openPeer = null },
                permissionsVersion = permissionsVersion
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        openPeer = intent.getStringExtra(EXTRA_PEER)
    }

    override fun onStart() {
        super.onStart()
        // Recuperación tras cierre inesperado: si el usuario dejó la malla activada, se reanuda.
        lifecycleScope.launch {
            val s = app.settings.current()
            if (s.onboardingDone && s.serviceEnabled && BlePermissions.hasBluetooth(this@MainActivity)) {
                app.runtime.ensureEngine()
                if (!app.runtime.serviceRunning.value) startMesh()
            }
        }
    }

    private fun requestAndStart() {
        val missing = BlePermissions.missing(this)
        if (missing.isNotEmpty()) {
            startAfterPermissions = true
            permissionLauncher.launch(missing.toTypedArray())
        } else {
            startMesh()
        }
    }

    private fun startMesh() {
        lifecycleScope.launch {
            app.runtime.ensureEngine()
            MeshService.start(this@MainActivity)
        }
    }

    @Suppress("MissingPermission")
    private fun requestEnableBluetooth() {
        // En Android 12+ ACTION_REQUEST_ENABLE necesita BLUETOOTH_CONNECT.
        if (!BlePermissions.hasBluetooth(this)) {
            startAfterPermissions = true
            permissionLauncher.launch(BlePermissions.required())
            return
        }
        try {
            enableBluetoothLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        }
    }

    private fun openBatterySettings() {
        val pm = getSystemService(PowerManager::class.java)
        val intent = if (Build.VERSION.SDK_INT >= 23 && pm?.isIgnoringBatteryOptimizations(packageName) == false) {
            Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
        } else {
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null))
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    companion object {
        const val EXTRA_PEER = "bluechat.peer"
    }
}
