package com.bluechat.mesh.data

import android.content.Context
import com.bluechat.mesh.core.DeliveryStatus
import com.bluechat.mesh.core.IncomingMessage
import com.bluechat.mesh.core.MeshConfig
import com.bluechat.mesh.core.MeshEngine
import com.bluechat.mesh.core.MeshListener
import com.bluechat.mesh.core.MeshStats
import com.bluechat.mesh.core.NeighborInfo
import com.bluechat.mesh.core.NodeInfo
import com.bluechat.mesh.core.NodeIds
import com.bluechat.mesh.core.NodeRecord
import com.bluechat.mesh.core.Profile
import com.bluechat.mesh.core.SendResult
import com.bluechat.mesh.service.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.Executors

/** Estado observable del transporte Bluetooth (lo actualiza [com.bluechat.mesh.bluetooth.BleMeshTransport]). */
data class TransportState(
    val running: Boolean = false,
    val advertising: Boolean = false,
    val scanning: Boolean = false,
    val error: String? = null
)

/**
 * Une el motor Mesh (núcleo puro) con Room, notificaciones y la interfaz.
 * Es el único [MeshListener]: persiste mensajes y estados y publica StateFlows para la UI.
 */
class MeshRuntime(
    private val context: Context,
    private val db: AppDatabase,
    private val identity: IdentityManager,
    private val settings: SettingsRepository,
    private val notifier: NotificationHelper,
    private val scope: CoroutineScope
) : MeshListener {

    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "bluechat-events").apply { isDaemon = true } }
        .asCoroutineDispatcher()

    private val _engine = MutableStateFlow<MeshEngine?>(null)
    val engine: StateFlow<MeshEngine?> = _engine.asStateFlow()

    private val _neighbors = MutableStateFlow<List<NeighborInfo>>(emptyList())
    val neighbors: StateFlow<List<NeighborInfo>> = _neighbors.asStateFlow()

    private val _nodes = MutableStateFlow<List<NodeInfo>>(emptyList())
    val nodes: StateFlow<List<NodeInfo>> = _nodes.asStateFlow()

    private val _stats = MutableStateFlow<MeshStats?>(null)
    val stats: StateFlow<MeshStats?> = _stats.asStateFlow()

    private val _serviceRunning = MutableStateFlow(false)
    val serviceRunning: StateFlow<Boolean> = _serviceRunning.asStateFlow()

    private val _transport = MutableStateFlow(TransportState())
    val transport: StateFlow<TransportState> = _transport.asStateFlow()

    /** Conversación abierta en pantalla: no se notifica sus mensajes. */
    @Volatile var activePeer: String? = null

    private val refreshSignal = Channel<Unit>(Channel.CONFLATED)

    @Volatile private var lastSettings = AppSettings()
    @Volatile private var canAdvertise = true

    init {
        scope.launch(worker) {
            for (u in refreshSignal) {
                refreshNow()
                delay(400) // limita la frecuencia de actualización de la UI
            }
        }
        scope.launch {
            settings.settings.collect { s ->
                lastSettings = s
                _engine.value?.let { applyConfig(it, s) }
            }
        }
    }

    fun setServiceRunning(v: Boolean) { _serviceRunning.value = v }
    fun setTransportState(s: TransportState) { _transport.value = s }
    fun setCanAdvertise(v: Boolean) { canAdvertise = v }

    private fun applyConfig(e: MeshEngine, s: AppSettings) {
        e.updateConfig(
            e.getConfig().copy(maxHops = s.maxHops, relayEnabled = s.relayEnabled, maxQueue = s.maxQueue)
        )
    }

    /** Crea el motor si existe una identidad. Idempotente. */
    suspend fun ensureEngine(): MeshEngine? {
        _engine.value?.let { return it }
        val keys = identity.load() ?: return null
        val s = settings.current()
        lastSettings = s
        val e = MeshEngine(
            identity = keys,
            profile = Profile(s.alias.ifBlank { "Usuario" }, s.avatar),
            store = RoomMeshStore(db),
            config = MeshConfig(maxHops = s.maxHops, relayEnabled = s.relayEnabled, maxQueue = s.maxQueue),
            advertisesRole = canAdvertise && s.visible
        )
        e.listener = this
        _engine.value = e
        requestRefresh()
        return e
    }

    fun requestRefresh() { refreshSignal.trySend(Unit) }

    private fun refreshNow() {
        val e = _engine.value ?: return
        _neighbors.value = e.neighbors()
        _nodes.value = e.knownNodes()
        _stats.value = e.stats()
    }

    // ----------------------------------------------------------------- API para ViewModels

    fun sendText(peerId: String, text: String): SendResult? {
        val e = _engine.value ?: return null
        return e.sendText(peerId, text.trim()) { msgId ->
            db.messages().insert(
                MessageEntity(
                    peerId = peerId, msgId = msgId, outgoing = true, text = text.trim(),
                    timestamp = System.currentTimeMillis(), status = DeliveryStatus.PENDING.ordinal,
                    hops = 0, read = true
                )
            )
        }
    }

    /** Marca como leídos los mensajes entrantes y, si la privacidad lo permite, avisa al remitente. */
    fun markConversationRead(peerId: String) {
        val unread = db.messages().unreadFrom(peerId)
        if (unread.isEmpty()) return
        db.messages().markRead(peerId)
        notifier.cancelMessage(peerId)
        if (lastSettings.sendReadReceipts) {
            val e = _engine.value ?: return
            unread.forEach { e.sendReadReceipt(peerId, it.msgId) }
        }
    }

    fun setBlocked(nodeId: String, blocked: Boolean) {
        db.nodes().setBlocked(nodeId, blocked)
        _engine.value?.setBlocked(nodeId, blocked)
        requestRefresh()
    }

    fun updateProfile(alias: String, avatar: Int) {
        _engine.value?.updateProfile(Profile(alias, avatar))
    }

    // ----------------------------------------------------------------- MeshListener
    // Se ejecuta con el cerrojo del motor: solo se encola trabajo, nada de E/S aquí.

    override fun onNeighborsChanged(neighbors: List<NeighborInfo>) { requestRefresh() }
    override fun onNodeUpdated(node: NodeInfo) { requestRefresh() }
    override fun onStatsChanged() { requestRefresh() }

    override fun onMessageReceived(message: IncomingMessage) {
        scope.launch(worker) {
            val rowId = db.messages().insert(
                MessageEntity(
                    peerId = message.from, msgId = message.msgId, outgoing = false, text = message.text,
                    timestamp = message.timestamp, status = 0, hops = message.hops, read = false
                )
            )
            if (rowId == -1L) return@launch
            if (activePeer == message.from) {
                markConversationRead(message.from)
            } else if (lastSettings.notifications) {
                val alias = db.nodes().get(message.from)?.alias ?: "Usuario ${NodeIds.short(message.from)}"
                notifier.showMessage(message.from, alias, if (lastSettings.notificationPreview) message.text else null)
            }
        }
    }

    override fun onOutgoingStatus(msgId: String, peerNodeId: String, status: DeliveryStatus) {
        scope.launch(worker) {
            val cur = db.messages().statusOf(peerNodeId, msgId)?.let { DeliveryStatus.values()[it] } ?: return@launch
            if (allowed(cur, status)) db.messages().setStatus(peerNodeId, msgId, status.ordinal)
        }
    }

    private fun allowed(cur: DeliveryStatus, new: DeliveryStatus): Boolean = when {
        cur == DeliveryStatus.READ -> false
        cur == DeliveryStatus.DELIVERED -> new == DeliveryStatus.READ
        new == DeliveryStatus.FAILED -> cur == DeliveryStatus.PENDING || cur == DeliveryStatus.SENT || cur == DeliveryStatus.RELAYING
        cur == DeliveryStatus.FAILED -> true // una confirmación tardía corrige un "no entregado"
        else -> new.rank >= cur.rank
    }
}
