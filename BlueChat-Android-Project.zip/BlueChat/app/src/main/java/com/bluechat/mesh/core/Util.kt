package com.bluechat.mesh.core

/** Utilidades sin dependencias de Android (el núcleo Mesh se prueba en JVM puro). */
object Hex {
    private val DIGITS = "0123456789abcdef".toCharArray()

    fun encode(bytes: ByteArray): String {
        val out = CharArray(bytes.size * 2)
        for (i in bytes.indices) {
            val v = bytes[i].toInt() and 0xFF
            out[i * 2] = DIGITS[v ushr 4]
            out[i * 2 + 1] = DIGITS[v and 0x0F]
        }
        return String(out)
    }

    fun decode(hex: String): ByteArray {
        require(hex.length % 2 == 0) { "Hex de longitud impar" }
        val out = ByteArray(hex.length / 2)
        for (i in out.indices) {
            val hi = Character.digit(hex[i * 2], 16)
            val lo = Character.digit(hex[i * 2 + 1], 16)
            require(hi >= 0 && lo >= 0) { "Carácter hex inválido" }
            out[i] = ((hi shl 4) or lo).toByte()
        }
        return out
    }
}

/** Reloj inyectable para poder probar caducidades sin esperar. */
fun interface WallClock {
    fun now(): Long
}

object SystemWallClock : WallClock {
    override fun now(): Long = System.currentTimeMillis()
}

object NodeIds {
    const val LENGTH_BYTES = 8
    val BROADCAST: String = "0".repeat(LENGTH_BYTES * 2)

    /** Etiqueta corta legible (primeros 4 bytes). */
    fun short(id: String): String = id.take(8)
}
