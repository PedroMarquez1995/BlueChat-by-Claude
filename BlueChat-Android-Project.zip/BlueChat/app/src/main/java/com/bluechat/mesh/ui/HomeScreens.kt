@file:OptIn(ExperimentalMaterial3Api::class)

package com.bluechat.mesh.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.bluechat.mesh.BlueChatApplication
import com.bluechat.mesh.bluetooth.BleCapabilities
import com.bluechat.mesh.bluetooth.BlePermissions
import com.bluechat.mesh.core.NodeIds
import com.bluechat.mesh.core.NodeInfo

/** Acciones que dependen de la Activity (permisos, ajustes del sistema, servicio). */
class AppActions(
    val startMesh: () -> Unit,
    val stopMesh: () -> Unit,
    val enableBluetooth: () -> Unit,
    val openAppSettings: () -> Unit,
    val openBatterySettings: () -> Unit
)

@Composable
fun HomeScreen(
    app: BlueChatApplication,
    actions: AppActions,
    onOpenChat: (String) -> Unit,
    onOpenContact: (String) -> Unit
) {
    var tab by rememberSaveable { mutableStateOf(0) }
    val home: HomeViewModel = viewModel(factory = AppViewModelFactory(app))
    val net: NetworkViewModel = viewModel(factory = AppViewModelFactory(app))
    val transport by home.transport.collectAsStateWithLifecycle()
    val neighbors by home.neighbors.collectAsStateWithLifecycle()
    val serviceRunning by home.serviceRunning.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val caps = remember(transport, serviceRunning) { BleCapabilities.read(ctx) }
    val direct = neighbors.count { it.nodeId != null }

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = { Text("BlueChat", fontWeight = FontWeight.Bold) }
                )
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatusPill(if (caps.bluetoothOn) "Bluetooth activo" else "Bluetooth apagado", caps.bluetoothOn)
                    StatusPill(
                        if (serviceRunning && transport.running) "Malla activa" else "Malla detenida",
                        serviceRunning && transport.running
                    )
                    StatusPill("$direct cercanos", direct > 0)
                }
            }
        },
        floatingActionButton = {
            if (tab == 0) {
                FloatingActionButton(onClick = { tab = 1 }) {
                    Icon(Icons.Filled.Add, contentDescription = "Nueva conversación")
                }
            }
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Filled.Home, null) }, label = { Text("Chats") })
                NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Filled.Person, null) }, label = { Text("Cercanos") })
                NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Filled.Share, null) }, label = { Text("Malla") })
                NavigationBarItem(tab == 3, { tab = 3 }, { Icon(Icons.Filled.Settings, null) }, label = { Text("Ajustes") })
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (tab) {
                0 -> ChatsTab(home, actions, caps, onOpenChat)
                1 -> NearbyTab(net, onOpenChat, onOpenContact)
                2 -> MeshTab(net, actions)
                else -> SettingsTab(app, actions)
            }
        }
    }
}

// ----------------------------------------------------------------------------- Chats

@Composable
private fun ChatsTab(home: HomeViewModel, actions: AppActions, caps: BleCapabilities, onOpenChat: (String) -> Unit) {
    val convs by home.conversations.collectAsStateWithLifecycle()
    val serviceRunning by home.serviceRunning.collectAsStateWithLifecycle()
    val transport by home.transport.collectAsStateWithLifecycle()
    val stats by home.stats.collectAsStateWithLifecycle()

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 88.dp)) {
        item {
            val problem = caps.problem()
            if (!serviceRunning || problem != null || transport.error != null) {
                InfoCard(
                    Modifier.padding(16.dp),
                    container = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        if (serviceRunning) "Atención" else "Participación en la malla detenida",
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        problem ?: transport.error
                            ?: "Para enviar, recibir y retransmitir mensajes BlueChat necesita estar activo. Mientras esté detenido, tus mensajes quedan pendientes.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (!caps.bluetoothOn && caps.hasBleHardware) {
                            Button(onClick = actions.enableBluetooth) { Text("Activar Bluetooth") }
                        }
                        if (!serviceRunning && caps.hasBleHardware) {
                            Button(onClick = actions.startMesh) { Text("Activar malla") }
                        }
                    }
                }
            }
        }
        val queued = stats?.queued ?: 0
        if (queued > 0) {
            item {
                Text(
                    "$queued mensajes en cola esperando una ruta",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }
        }
        if (convs.isEmpty()) {
            item {
                EmptyState(
                    "Aún no hay conversaciones",
                    "Pulsa + para ver los usuarios BlueChat detectados cerca y escribirles. Solo aparecen usuarios reales detectados por Bluetooth."
                )
            }
        }
        items(convs, key = { it.peerId }) { c ->
            ConversationRow(c) { onOpenChat(c.peerId) }
            HorizontalDivider(Modifier.padding(start = 76.dp), color = MaterialTheme.colorScheme.surfaceVariant)
        }
    }
}

@Composable
private fun ConversationRow(c: ConversationItem, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(c.alias, c.avatar, 48.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row {
                Text(c.alias, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Text(formatDayTime(c.lastTime), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                val prefix = if (c.lastOutgoing) (c.lastStatus?.let { statusGlyph(it) + " " } ?: "") else ""
                Text(
                    prefix + c.lastText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.weight(1f)
                )
                if (c.unread > 0) {
                    Spacer(Modifier.width(8.dp))
                    Box(
                        Modifier.clip(CircleShape).background(MaterialTheme.colorScheme.primary).padding(horizontal = 8.dp, vertical = 2.dp)
                    ) { Text("${c.unread}", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.labelSmall) }
                }
            }
            Row {
                Text(
                    if (c.direct) "Directo" else if (c.hops > 1) "Indirecto · ${c.hops} saltos" else "Sin ruta",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (c.direct) Color(0xFF2E9E5B) else MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (c.pending > 0) {
                    Text(
                        "  ·  ${c.pending} sin confirmar",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------- Cercanos

@Composable
private fun NearbyTab(net: NetworkViewModel, onOpenChat: (String) -> Unit, onOpenContact: (String) -> Unit) {
    val nodes by net.nodes.collectAsStateWithLifecycle()
    val neighbors by net.neighbors.collectAsStateWithLifecycle()
    val rssiByNode = neighbors.filter { it.nodeId != null }.associate { it.nodeId!! to it.rssi }
    val sorted = nodes.filter { !it.blocked }.sortedWith(
        compareByDescending<NodeInfo> { it.direct }.thenByDescending { it.isContact }.thenByDescending { it.lastSeen }
    )

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { SectionTitle("Usuarios BlueChat detectados") }
        if (sorted.isEmpty()) {
            item {
                EmptyState(
                    "Nadie detectado todavía",
                    "Con la malla activa, BlueChat busca otros teléfonos con la app abierta o en segundo plano. Acércate a ellos y espera unos segundos."
                )
            }
        }
        items(sorted, key = { it.nodeId }) { n ->
            Row(
                Modifier.fillMaxWidth().clickable { onOpenContact(n.nodeId) }.padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Avatar(n.alias, n.avatar, 46.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(n.alias, fontWeight = FontWeight.SemiBold)
                        if (n.verified) Text("  ✔ verificado", style = MaterialTheme.typography.labelSmall, color = Color(0xFF2E9E5B))
                    }
                    val state = if (n.direct) "Disponible ahora" else if (n.hops > 1) "Alcanzable vía malla" else "Visto ${agoText(n.lastSeen)}"
                    Text(state, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    val sig = if (n.direct) signalLabel(rssiByNode[n.nodeId]) else null
                    Text(
                        connectionLabel(n) + (if (sig != null) " · $sig" else "") + (if (n.relayCapable) " · repetidor" else ""),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (n.direct) Color(0xFF2E9E5B) else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Button(onClick = { onOpenChat(n.nodeId) }, contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)) { Text("Chatear") }
                    if (!n.isContact) {
                        OutlinedButton(
                            onClick = { net.addContact(n.nodeId) },
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 2.dp),
                            modifier = Modifier.padding(top = 4.dp)
                        ) { Text("Agregar") }
                    } else {
                        Text("Contacto", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 6.dp))
                    }
                }
            }
            HorizontalDivider(Modifier.padding(start = 74.dp), color = MaterialTheme.colorScheme.surfaceVariant)
        }
    }
}

// ----------------------------------------------------------------------------- Malla

@Composable
private fun MeshTab(net: NetworkViewModel, actions: AppActions) {
    val neighbors by net.neighbors.collectAsStateWithLifecycle()
    val nodes by net.nodes.collectAsStateWithLifecycle()
    val stats by net.stats.collectAsStateWithLifecycle()
    val transport by net.transport.collectAsStateWithLifecycle()
    val running by net.serviceRunning.collectAsStateWithLifecycle()
    val settings by net.settings.collectAsStateWithLifecycle()

    val bound = neighbors.filter { it.nodeId != null }
    val indirect = nodes.filter { !it.direct && it.hops > 1 }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        InfoCard(Modifier.padding(16.dp)) {
            Text("Participación en la red", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(
                when {
                    !running -> "Detenida. Este teléfono no envía, recibe ni retransmite."
                    transport.running && transport.advertising -> "Activa: escaneando y visible para otros."
                    transport.running -> "Activa solo como escáner (no visible o sin soporte de anuncio BLE)."
                    else -> "Iniciando o esperando Bluetooth…"
                },
                style = MaterialTheme.typography.bodyMedium
            )
            transport.error?.let {
                Spacer(Modifier.height(6.dp))
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(10.dp))
            if (running) {
                OutlinedButton(onClick = actions.stopMesh) { Text("Detener participación") }
            } else {
                Button(onClick = actions.startMesh) { Text("Activar participación") }
            }
        }

        ToggleRow(
            "Retransmitir mensajes de otros",
            "Actúa como repetidor: guarda y reenvía mensajes cifrados. Consume batería.",
            settings.relayEnabled
        ) { net.setRelay(it) }

        SectionTitle("Resumen")
        InfoCard(Modifier.padding(horizontal = 16.dp)) {
            StatLine("Vecinos conectados (directos)", "${bound.size}")
            StatLine("Nodos conocidos", "${nodes.size}")
            StatLine("Alcanzables indirectamente", "${indirect.size}")
            StatLine("Mensajes en cola", "${stats?.queued ?: 0}")
            StatLine("Mensajes retransmitidos", "${stats?.relayed ?: 0}")
            StatLine("Paquetes recibidos válidos", "${stats?.received ?: 0}")
            StatLine("Duplicados descartados", "${stats?.duplicatesDropped ?: 0}")
            StatLine("Inválidos / limitados", "${stats?.invalidDropped ?: 0} / ${stats?.rateLimited ?: 0}")
            StatLine("Última actividad", agoText(stats?.lastActivity ?: 0))
        }

        SectionTitle("Vecinos directamente conectados")
        if (bound.isEmpty()) {
            Text("Ninguno.", Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        bound.forEach { n ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                Column(Modifier.weight(1f)) {
                    Text(n.alias ?: "Usuario ${NodeIds.short(n.nodeId!!)}", fontWeight = FontWeight.Medium)
                    Text("Conectado ${agoText(n.since)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(signalLabel(n.rssi) ?: "señal n/d", style = MaterialTheme.typography.labelMedium)
            }
        }

        SectionTitle("Nodos conocidos indirectamente")
        if (indirect.isEmpty()) {
            Text("Ninguno por ahora.", Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        indirect.sortedBy { it.hops }.forEach { n ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                Column(Modifier.weight(1f)) {
                    Text(n.alias, fontWeight = FontWeight.Medium)
                    val via = nodes.firstOrNull { it.nodeId == n.viaNodeId }?.alias
                    Text(
                        "${n.hops} saltos" + (via?.let { " · vía $it" } ?: ""),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(agoText(n.lastSeen), style = MaterialTheme.typography.labelSmall)
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            "Los saltos y rutas se aprenden de los anuncios recibidos y pueden estar desactualizados.",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
    }
}

@Composable
private fun StatLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}
