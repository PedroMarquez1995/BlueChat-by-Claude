package com.bluechat.mesh.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bluechat.mesh.core.DeliveryStatus
import com.bluechat.mesh.core.NodeInfo
import java.text.DateFormat
import java.util.Date

val AvatarColors = listOf(
    Color(0xFF1E6BFF), Color(0xFF00B2FF), Color(0xFF0057D9), Color(0xFF5B5BD6),
    Color(0xFF0097A7), Color(0xFF2E7D32), Color(0xFFEF6C00), Color(0xFFC2185B)
)

@Composable
fun Avatar(alias: String, index: Int, size: Dp = 44.dp) {
    val color = AvatarColors[index.mod(AvatarColors.size)]
    Box(
        modifier = Modifier.size(size).clip(CircleShape).background(color),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = alias.trim().firstOrNull()?.uppercase() ?: "?",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = (size.value * 0.42f).sp
        )
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.SemiBold,
        modifier = modifier.padding(horizontal = 16.dp, vertical = 8.dp)
    )
}

@Composable
fun InfoCard(
    modifier: Modifier = Modifier,
    container: Color = MaterialTheme.colorScheme.surfaceVariant,
    content: @Composable () -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = container)
    ) {
        Column(Modifier.padding(16.dp)) { content() }
    }
}

@Composable
fun StatusPill(label: String, ok: Boolean, modifier: Modifier = Modifier) {
    val dot = if (ok) Color(0xFF2ECC71) else Color(0xFFFFA000)
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
        Spacer(Modifier.width(6.dp))
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun ToggleRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.width(12.dp))
        androidx.compose.material3.Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun EmptyState(title: String, text: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ----------------------------------------------------------------------------- formato

fun formatTime(ts: Long): String = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(ts))

fun formatDayTime(ts: Long): String {
    val now = System.currentTimeMillis()
    return if (now - ts < 20 * 3_600_000L) formatTime(ts)
    else DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(ts))
}

fun agoText(ts: Long): String {
    if (ts <= 0) return "—"
    val s = (System.currentTimeMillis() - ts) / 1000
    return when {
        s < 5 -> "ahora"
        s < 60 -> "hace ${s}s"
        s < 3600 -> "hace ${s / 60} min"
        s < 86400 -> "hace ${s / 3600} h"
        else -> "hace ${s / 86400} d"
    }
}

/** Estados honestos: "Entregado" solo si el destinatario lo confirmó. */
fun statusLabel(s: DeliveryStatus): String = when (s) {
    DeliveryStatus.PENDING -> "Pendiente · sin vecino disponible"
    DeliveryStatus.SENT -> "Enviado al destinatario · sin confirmar"
    DeliveryStatus.RELAYING -> "En retransmisión · sin confirmar"
    DeliveryStatus.DELIVERED -> "Entregado"
    DeliveryStatus.READ -> "Leído"
    DeliveryStatus.FAILED -> "No entregado (caducó)"
}

fun statusGlyph(s: DeliveryStatus): String = when (s) {
    DeliveryStatus.PENDING -> "○"
    DeliveryStatus.SENT -> "✓"
    DeliveryStatus.RELAYING -> "⇢"
    DeliveryStatus.DELIVERED -> "✓✓"
    DeliveryStatus.READ -> "✓✓"
    DeliveryStatus.FAILED -> "✕"
}

fun connectionLabel(n: NodeInfo?): String = when {
    n == null -> "Sin ruta conocida"
    n.direct -> "Conexión directa"
    n.hops > 1 -> "Indirecta · ${n.hops} saltos"
    else -> "Sin ruta conocida"
}

/** RSSI aproximado -> texto cualitativo. No se convierte a distancia (no es fiable). */
fun signalLabel(rssi: Int?): String? = when {
    rssi == null || rssi == 0 || rssi < -120 -> null
    rssi >= -60 -> "Señal fuerte"
    rssi >= -75 -> "Señal media"
    else -> "Señal débil"
}
