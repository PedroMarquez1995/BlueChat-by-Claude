@file:OptIn(ExperimentalMaterial3Api::class)

package com.bluechat.mesh.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardCapitalization

/** Logotipo original: globo de chat con tres nodos conectados. */
@Composable
fun BlueChatLogo(size: androidx.compose.ui.unit.Dp = 112.dp) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        drawRoundRect(
            brush = Brush.linearGradient(listOf(BcBlue, BcElectric)),
            topLeft = Offset(w * 0.06f, h * 0.10f),
            size = Size(w * 0.88f, h * 0.66f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.2f, w * 0.2f)
        )
        // cola del globo
        val tail = androidx.compose.ui.graphics.Path().apply {
            moveTo(w * 0.24f, h * 0.70f)
            lineTo(w * 0.20f, h * 0.92f)
            lineTo(w * 0.46f, h * 0.74f)
            close()
        }
        drawPath(tail, BcBlue)
        val a = Offset(w * 0.30f, h * 0.55f)
        val b = Offset(w * 0.50f, h * 0.30f)
        val c = Offset(w * 0.70f, h * 0.55f)
        val stroke = w * 0.03f
        drawLine(Color.White, a, b, stroke, StrokeCap.Round)
        drawLine(Color.White, b, c, stroke, StrokeCap.Round)
        drawLine(Color.White, a, c, stroke, StrokeCap.Round)
        drawCircle(Color.White, w * 0.065f, a)
        drawCircle(Color.White, w * 0.065f, c)
        drawCircle(BcNavy, w * 0.085f, b)
        drawCircle(Color.White, w * 0.06f, b)
    }
}

@Composable
fun WelcomeScreen(onStart: () -> Unit) {
    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(BcNavy, Color(0xFF123A8C))))
            .statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(36.dp))
        BlueChatLogo()
        Spacer(Modifier.height(20.dp))
        Text("BlueChat", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Bold)
        Text("Conectados sin Internet", color = BcElectric, fontSize = 18.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(32.dp))
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Color(0x1AFFFFFF)).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Cómo funciona", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
            Bullet("Los teléfonos con BlueChat se encuentran por Bluetooth, sin Internet, datos móviles, Wi-Fi ni SIM.")
            Bullet("Si dos teléfonos no se alcanzan, otros con BlueChat pueden retransmitir el mensaje cifrado entre ellos.")
            Bullet("Solo el destinatario puede leer el mensaje. Los intermediarios ven únicamente lo necesario para reenviarlo.")
            Bullet("El alcance es de unas decenas de metros por salto y depende de paredes y del teléfono.")
        }
        Spacer(Modifier.height(32.dp))
        Button(
            onClick = onStart,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(28.dp)
        ) { Text("Comenzar", fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }
    }
}

@Composable
private fun Bullet(text: String) {
    Row(verticalAlignment = Alignment.Top) {
        Text("•  ", color = BcElectric, fontWeight = FontWeight.Bold)
        Text(text, color = Color(0xFFE4E9F5), fontSize = 15.sp)
    }
}

@Composable
fun AvatarPicker(alias: String, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        AvatarColors.forEachIndexed { i, _ ->
            Box(
                Modifier.weight(1f).clip(CircleShape)
                    .border(if (i == selected) 3.dp else 0.dp, MaterialTheme.colorScheme.onBackground, CircleShape)
                    .clickable { onSelect(i) },
                contentAlignment = Alignment.Center
            ) { Avatar(alias.ifBlank { "?" }, i, 36.dp) }
        }
    }
}

@Composable
fun ProfileScreen(
    busy: Boolean,
    error: String?,
    onCreate: (alias: String, avatar: Int, visible: Boolean, readReceipts: Boolean) -> Unit
) {
    var alias by rememberSaveable { mutableStateOf("") }
    var avatar by rememberSaveable { mutableStateOf(0) }
    var visible by rememberSaveable { mutableStateOf(true) }
    var receipts by rememberSaveable { mutableStateOf(true) }

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Crea tu perfil", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(
            "No hay cuentas ni servidores. Tu identidad es un par de claves criptográficas que se genera y se guarda solo en este teléfono.",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        OutlinedTextField(
            value = alias,
            onValueChange = { if (it.length <= 24) alias = it },
            label = { Text("Nombre visible") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
            modifier = Modifier.fillMaxWidth()
        )
        Text("Avatar", style = MaterialTheme.typography.titleSmall)
        AvatarPicker(alias, avatar) { avatar = it }

        Text("Privacidad", style = MaterialTheme.typography.titleSmall)
        ToggleRow(
            "Ser visible para dispositivos cercanos",
            "Si lo desactivas no te anuncias por Bluetooth, pero sigues pudiendo buscar a otros.",
            visible
        ) { visible = it }
        ToggleRow(
            "Enviar confirmación de lectura",
            "Avisa al remitente cuando abres su mensaje.",
            receipts
        ) { receipts = it }

        if (error != null) Text(error, color = MaterialTheme.colorScheme.error)

        Button(
            onClick = { onCreate(alias.trim(), avatar, visible, receipts) },
            enabled = alias.trim().length >= 2 && !busy,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(27.dp)
        ) { Text(if (busy) "Generando claves…" else "Crear identidad") }
    }
}

@Composable
fun PermissionsScreen(missingBluetooth: Boolean, onRequest: () -> Unit, onContinue: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Permisos necesarios", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        InfoCard {
            Text("Bluetooth cercano", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(
                "Para encontrar y conectarse a otros teléfonos. En Android 12 o superior son los permisos «Dispositivos cercanos». " +
                    "En Android 8-11 Android exige el permiso de ubicación para escanear Bluetooth; BlueChat no usa el GPS ni guarda tu ubicación.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
        InfoCard {
            Text("Notificaciones", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(
                "Para avisarte de mensajes nuevos y mostrar que BlueChat está activo en segundo plano (Android 13+).",
                style = MaterialTheme.typography.bodyMedium
            )
        }
        Text(
            "BlueChat no solicita el permiso de Internet: es imposible que envíe datos fuera de Bluetooth.",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Button(
            onClick = onRequest,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(27.dp)
        ) { Text(if (missingBluetooth) "Conceder permisos" else "Permisos concedidos") }
        OutlinedButton(
            onClick = onContinue,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(27.dp)
        ) { Text(if (missingBluetooth) "Continuar sin Bluetooth (sin mensajería)" else "Continuar") }
    }
}
