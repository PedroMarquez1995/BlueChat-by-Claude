package com.bluechat.mesh.service

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.bluechat.mesh.MainActivity
import com.bluechat.mesh.R

class NotificationHelper(private val context: Context) {

    fun createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_SERVICE, context.getString(R.string.channel_service), NotificationManager.IMPORTANCE_LOW)
                .apply { description = context.getString(R.string.channel_service_desc); setShowBadge(false) }
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_MESSAGES, context.getString(R.string.channel_messages), NotificationManager.IMPORTANCE_HIGH)
                .apply { description = context.getString(R.string.channel_messages_desc) }
        )
    }

    private fun openAppIntent(peerId: String?): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            if (peerId != null) putExtra(MainActivity.EXTRA_PEER, peerId)
        }
        return PendingIntent.getActivity(
            context, peerId?.hashCode() ?: 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun serviceNotification(neighbors: Int, queued: Int, relay: Boolean): Notification {
        val stop = PendingIntent.getService(
            context, 1,
            Intent(context, MeshService::class.java).setAction(MeshService.ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val text = context.getString(
            if (relay) R.string.service_text_relay else R.string.service_text_no_relay, neighbors, queued
        )
        return NotificationCompat.Builder(context, CHANNEL_SERVICE)
            .setSmallIcon(R.drawable.ic_stat_mesh)
            .setContentTitle(context.getString(R.string.service_title))
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(openAppIntent(null))
            .addAction(0, context.getString(R.string.service_stop), stop)
            .build()
    }

    @SuppressLint("MissingPermission")
    fun updateService(neighbors: Int, queued: Int, relay: Boolean) {
        if (!canNotify()) return
        NotificationManagerCompat.from(context).notify(SERVICE_ID, serviceNotification(neighbors, queued, relay))
    }

    @SuppressLint("MissingPermission")
    fun showMessage(peerId: String, alias: String, text: String?) {
        if (!canNotify()) return
        val n = NotificationCompat.Builder(context, CHANNEL_MESSAGES)
            .setSmallIcon(R.drawable.ic_stat_mesh)
            .setContentTitle(alias)
            .setContentText(text ?: context.getString(R.string.notification_new_message))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setContentIntent(openAppIntent(peerId))
            .build()
        NotificationManagerCompat.from(context).notify(peerId.hashCode(), n)
    }

    fun cancelMessage(peerId: String) {
        NotificationManagerCompat.from(context).cancel(peerId.hashCode())
    }

    private fun canNotify(): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    companion object {
        const val CHANNEL_SERVICE = "bluechat_service"
        const val CHANNEL_MESSAGES = "bluechat_messages"
        const val SERVICE_ID = 4201
    }
}
