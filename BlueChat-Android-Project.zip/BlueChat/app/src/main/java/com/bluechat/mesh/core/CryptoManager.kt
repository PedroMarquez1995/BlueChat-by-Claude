package com.bluechat.mesh.core

import org.bouncycastle.crypto.agreement.X25519Agreement
import org.bouncycastle.crypto.digests.SHA256Digest
import org.bouncycastle.crypto.generators.HKDFBytesGenerator
import org.bouncycastle.crypto.modes.ChaCha20Poly1305
import org.bouncycastle.crypto.params.AEADParameters
import org.bouncycastle.crypto.params.Ed25519PrivateKeyParameters
import org.bouncycastle.crypto.params.Ed25519PublicKeyParameters
import org.bouncycastle.crypto.params.HKDFParameters
import org.bouncycastle.crypto.params.KeyParameter
import org.bouncycastle.crypto.params.X25519PrivateKeyParameters
import org.bouncycastle.crypto.params.X25519PublicKeyParameters
import org.bouncycastle.crypto.signers.Ed25519Signer
import java.security.MessageDigest
import java.security.SecureRandom

/**
 * Claves de identidad de un usuario: Ed25519 (firma) + X25519 (acuerdo de claves).
 * El identificador de nodo es el hash de ambas claves públicas (auto-certificante:
 * no depende de MAC, teléfono ni identificadores de hardware).
 */
class IdentityKeys(
    val signPriv: ByteArray,
    val signPub: ByteArray,
    val dhPriv: ByteArray,
    val dhPub: ByteArray
) {
    val nodeId: String = CryptoManager.nodeIdFor(signPub, dhPub)
    val fingerprint: String get() = CryptoManager.fingerprint(signPub, dhPub)
}

/**
 * Operaciones criptográficas. No se inventa ningún algoritmo; se combinan primitivas estándar
 * de Bouncy Castle:
 *  - Ed25519 (RFC 8032) para firmas.
 *  - X25519 (RFC 7748) para acuerdo de claves.
 *  - HKDF-SHA256 (RFC 5869) para derivar la clave simétrica.
 *  - ChaCha20-Poly1305 (RFC 8439) para cifrado autenticado (AEAD).
 *
 * LIMITACIÓN CONOCIDA: el acuerdo es estático-estático, por lo que NO hay secreto hacia
 * adelante (forward secrecy): si una clave privada se compromete, los mensajes capturados
 * antes podrían descifrarse. Un futuro protocolo tipo Double Ratchet lo resolvería.
 */
object CryptoManager {
    const val SIGNATURE_BYTES = 64
    const val KEY_BYTES = 32
    const val NONCE_BYTES = 12
    const val TAG_BYTES = 16
    const val SEAL_OVERHEAD = NONCE_BYTES + TAG_BYTES

    private val sharedRandom = SecureRandom()

    fun generateIdentity(random: SecureRandom = sharedRandom): IdentityKeys {
        val signPriv = Ed25519PrivateKeyParameters(random)
        val dhPriv = X25519PrivateKeyParameters(random)
        return IdentityKeys(
            signPriv = signPriv.encoded,
            signPub = signPriv.generatePublicKey().encoded,
            dhPriv = dhPriv.encoded,
            dhPub = dhPriv.generatePublicKey().encoded
        )
    }

    fun identityFromPrivate(signPriv: ByteArray, dhPriv: ByteArray): IdentityKeys {
        val sp = Ed25519PrivateKeyParameters(signPriv, 0)
        val dp = X25519PrivateKeyParameters(dhPriv, 0)
        return IdentityKeys(
            signPriv = signPriv.copyOf(),
            signPub = sp.generatePublicKey().encoded,
            dhPriv = dhPriv.copyOf(),
            dhPub = dp.generatePublicKey().encoded
        )
    }

    private fun sha256(vararg parts: ByteArray): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        parts.forEach { md.update(it) }
        return md.digest()
    }

    fun nodeIdFor(signPub: ByteArray, dhPub: ByteArray): String =
        Hex.encode(sha256(signPub, dhPub).copyOf(NodeIds.LENGTH_BYTES))

    /** Huella legible para comparar en persona: 12 grupos de 5 dígitos. */
    fun fingerprint(signPub: ByteArray, dhPub: ByteArray): String {
        val h = sha256(signPub, dhPub)
        val groups = ArrayList<String>(12)
        for (i in 0 until 12) {
            val v = ((h[i * 2].toInt() and 0xFF) shl 8) or (h[i * 2 + 1].toInt() and 0xFF)
            groups.add((v % 100000).toString().padStart(5, '0'))
        }
        return groups.joinToString(" ")
    }

    fun sign(signPriv: ByteArray, data: ByteArray): ByteArray {
        val signer = Ed25519Signer()
        signer.init(true, Ed25519PrivateKeyParameters(signPriv, 0))
        signer.update(data, 0, data.size)
        return signer.generateSignature()
    }

    fun verify(signPub: ByteArray, data: ByteArray, signature: ByteArray): Boolean = try {
        if (signPub.size != KEY_BYTES || signature.size != SIGNATURE_BYTES) {
            false
        } else {
            val verifier = Ed25519Signer()
            verifier.init(false, Ed25519PublicKeyParameters(signPub, 0))
            verifier.update(data, 0, data.size)
            verifier.verifySignature(signature)
        }
    } catch (e: Exception) {
        false
    }

    private fun deriveKey(
        myDhPriv: ByteArray,
        peerDhPub: ByteArray,
        msgId: ByteArray,
        senderId: String,
        recipientId: String
    ): ByteArray? = try {
        val agreement = X25519Agreement()
        agreement.init(X25519PrivateKeyParameters(myDhPriv, 0))
        val shared = ByteArray(agreement.agreementSize)
        agreement.calculateAgreement(X25519PublicKeyParameters(peerDhPub, 0), shared, 0)
        val hkdf = HKDFBytesGenerator(SHA256Digest())
        val info = "bluechat/v1/msg".toByteArray(Charsets.UTF_8) +
            senderId.toByteArray(Charsets.UTF_8) + recipientId.toByteArray(Charsets.UTF_8)
        hkdf.init(HKDFParameters(shared, msgId, info))
        val key = ByteArray(KEY_BYTES)
        hkdf.generateBytes(key, 0, KEY_BYTES)
        key
    } catch (e: Exception) {
        null // punto de baja entropía / clave inválida
    }

    /** Cifra y autentica. Devuelve nonce(12) || texto cifrado || etiqueta(16). */
    fun seal(
        plaintext: ByteArray,
        myDhPriv: ByteArray,
        peerDhPub: ByteArray,
        msgId: ByteArray,
        senderId: String,
        recipientId: String,
        aad: ByteArray,
        random: SecureRandom = sharedRandom
    ): ByteArray? {
        val key = deriveKey(myDhPriv, peerDhPub, msgId, senderId, recipientId) ?: return null
        val nonce = ByteArray(NONCE_BYTES).also { random.nextBytes(it) }
        val cipher = ChaCha20Poly1305()
        cipher.init(true, AEADParameters(KeyParameter(key), TAG_BYTES * 8, nonce, aad))
        val out = ByteArray(cipher.getOutputSize(plaintext.size))
        var n = cipher.processBytes(plaintext, 0, plaintext.size, out, 0)
        n += cipher.doFinal(out, n)
        return nonce + out.copyOf(n)
    }

    /** Verifica y descifra. Devuelve null si la etiqueta no coincide (manipulado o clave errónea). */
    fun open(
        sealed: ByteArray,
        myDhPriv: ByteArray,
        peerDhPub: ByteArray,
        msgId: ByteArray,
        senderId: String,
        recipientId: String,
        aad: ByteArray
    ): ByteArray? {
        if (sealed.size < SEAL_OVERHEAD) return null
        val key = deriveKey(myDhPriv, peerDhPub, msgId, senderId, recipientId) ?: return null
        return try {
            val nonce = sealed.copyOfRange(0, NONCE_BYTES)
            val cipher = ChaCha20Poly1305()
            cipher.init(false, AEADParameters(KeyParameter(key), TAG_BYTES * 8, nonce, aad))
            val ct = sealed.copyOfRange(NONCE_BYTES, sealed.size)
            val out = ByteArray(cipher.getOutputSize(ct.size))
            var n = cipher.processBytes(ct, 0, ct.size, out, 0)
            n += cipher.doFinal(out, n)
            out.copyOf(n)
        } catch (e: Exception) {
            null
        }
    }
}
