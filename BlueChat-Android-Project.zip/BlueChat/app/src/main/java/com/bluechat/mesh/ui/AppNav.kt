package com.bluechat.mesh.ui

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.bluechat.mesh.BlueChatApplication
import com.bluechat.mesh.bluetooth.BlePermissions
import androidx.compose.ui.platform.LocalContext

object Routes {
    const val WELCOME = "welcome"
    const val PROFILE = "profile"
    const val PERMISSIONS = "permissions"
    const val HOME = "home"
    const val CHAT = "chat/{peerId}"
    const val CONTACT = "contact/{peerId}"
    fun chat(id: String) = "chat/$id"
    fun contact(id: String) = "contact/$id"
}

@Composable
fun BlueChatApp(
    app: BlueChatApplication,
    actions: AppActions,
    requestPermissions: () -> Unit,
    openPeer: String?,
    onPeerConsumed: () -> Unit,
    permissionsVersion: Int
) {
    val startup: StartupViewModel = viewModel(factory = AppViewModelFactory(app))
    val settings by startup.settings.collectAsStateWithLifecycle()
    val busy by startup.busy.collectAsStateWithLifecycle()
    val error by startup.error.collectAsStateWithLifecycle()
    val s = settings

    BlueChatTheme(s?.theme ?: com.bluechat.mesh.data.ThemeMode.SYSTEM) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            if (s == null) {
                Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background))
                return@Surface
            }
            val nav = rememberNavController()
            val ctx = LocalContext.current
            val start = if (s.onboardingDone) Routes.HOME else Routes.WELCOME

            LaunchedEffect(openPeer, s.onboardingDone) {
                if (openPeer != null && s.onboardingDone) {
                    nav.navigate(Routes.chat(openPeer)) { launchSingleTop = true }
                    onPeerConsumed()
                }
            }

            NavHost(
                navController = nav,
                startDestination = start,
                enterTransition = { fadeIn(tween(220)) + slideInHorizontally(tween(260)) { it / 8 } },
                exitTransition = { fadeOut(tween(160)) },
                popEnterTransition = { fadeIn(tween(220)) },
                popExitTransition = { fadeOut(tween(160)) + slideOutHorizontally(tween(240)) { it / 8 } }
            ) {
                composable(Routes.WELCOME) {
                    WelcomeScreen(onStart = { nav.navigate(Routes.PROFILE) })
                }
                composable(Routes.PROFILE) {
                    ProfileScreen(busy = busy, error = error) { alias, avatar, visible, receipts ->
                        startup.completeOnboarding(alias, avatar, visible, receipts) {
                            nav.navigate(Routes.PERMISSIONS) { popUpTo(Routes.WELCOME) { inclusive = true } }
                        }
                    }
                }
                composable(Routes.PERMISSIONS) {
                    // permissionsVersion fuerza recomposición cuando cambia el resultado del diálogo del sistema
                    val missing = permissionsVersion >= 0 && !BlePermissions.hasBluetooth(ctx)
                    PermissionsScreen(
                        missingBluetooth = missing,
                        onRequest = requestPermissions,
                        onContinue = {
                            if (!missing) actions.startMesh()
                            nav.navigate(Routes.HOME) { popUpTo(Routes.PERMISSIONS) { inclusive = true } }
                        }
                    )
                }
                composable(Routes.HOME) {
                    HomeScreen(
                        app = app,
                        actions = actions,
                        onOpenChat = { nav.navigate(Routes.chat(it)) },
                        onOpenContact = { nav.navigate(Routes.contact(it)) }
                    )
                }
                composable(Routes.CHAT, arguments = listOf(navArgument("peerId") { type = NavType.StringType })) { entry ->
                    val id = entry.arguments?.getString("peerId").orEmpty()
                    ChatScreen(
                        app = app, peerId = id,
                        onBack = { nav.popBackStack() },
                        onOpenContact = { nav.navigate(Routes.contact(id)) }
                    )
                }
                composable(Routes.CONTACT, arguments = listOf(navArgument("peerId") { type = NavType.StringType })) { entry ->
                    val id = entry.arguments?.getString("peerId").orEmpty()
                    ContactScreen(
                        app = app, peerId = id,
                        onBack = { nav.popBackStack() },
                        onChat = {
                            // Si ya venimos del chat, solo volvemos; si no, lo abrimos.
                            if (!nav.popBackStack(Routes.CHAT, false)) nav.navigate(Routes.chat(id))
                        }
                    )
                }
            }
        }
    }
}
