package com.bluechat.mesh.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.bluechat.mesh.BlueChatApplication
import com.bluechat.mesh.core.CryptoManager
import com.bluechat.mesh.core.DeliveryStatus
import com.bluechat.mesh.core.MeshStats
import com.bluechat.mesh.core.NeighborInfo
import com.bluechat.mesh.core.NodeIds
import com.bluechat.mesh.core.NodeInfo
import com.bluechat.mesh.core.SendResult
import com.bluechat.mesh.data.AppSettings
import com.bluechat.mesh.data.MessageEntity
import com.bluechat.mesh.data.NodeEntity
import com.bluechat.mesh.data.ThemeMode
import com.bluechat.mesh.data.TransportState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModelFactory(
    private val app: BlueChatApplication,
    private val peerId: String? = null
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when {
        modelClass.isAssignableFrom(StartupViewModel::class.java) -> StartupViewModel(app) as T
        modelClass.isAssignableFrom(HomeViewModel::class.java) -> HomeViewModel(app) as T
        modelClass.isAssignableFrom(NetworkViewModel::class.java) -> NetworkViewModel(app) as T
        modelClass.isAssignableFrom(SettingsViewModel::class.java) -> SettingsViewModel(app) as T
        modelClass.isAssignableFrom(ChatViewModel::class.java) -> ChatViewModel(app, requireNotNull(peerId)) as T
        modelClass.isAssignableFrom(ContactViewModel::class.java) -> ContactViewModel(app, requireNotNull(peerId)) as T
        else -> throw IllegalArgumentException("ViewModel desconocido: ${modelClass.name}")
    }
}

// ============================================================================ arranque / onboarding

class StartupViewModel(private val app: BlueChatApplication) : ViewModel() {
    val settings: StateFlow<AppSettings?> =
        app.settings.settings.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private val _busy = MutableStateFlow(false)
    val busy = _busy.asStateFlow()
    private val _error = MutableStateFlow<String?>(null)
    val error = _error.asStateFlow()

    /** Crea la identidad criptográfica y guarda el perfil. [onDone] se llama en el hilo principal. */
    fun completeOnboarding(alias: String, avatar: Int, visible: Boolean, readReceipts: Boolean, onDone: () -> Unit) {
        if (_busy.value) return
        _busy.value = true
        _error.value = null
        viewModelScope.launch(Dispatchers.IO) {
            try {
                if (!app.identity.hasIdentity() || app.identity.load() == null) app.identity.create()
                app.settings.completeOnboarding(alias.trim(), avatar, visible, readReceipts)
                app.runtime.ensureEngine()
                _busy.value = false
                launch(Dispatchers.Main) { onDone() }
            } catch (e: Exception) {
                _busy.value = false
                _error.value = "No se pudo crear la identidad segura en este teléfono: ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }
}

// ============================================================================ inicio / conversaciones

data class ConversationItem(
    val peerId: String,
    val alias: String,
    val avatar: Int,
    val lastText: String,
    val lastTime: Long,
    val lastOutgoing: Boolean,
    val lastStatus: DeliveryStatus?,
    val unread: Int,
    val pending: Int,
    val direct: Boolean,
    val hops: Int,
    val blocked: Boolean
)

class HomeViewModel(private val app: BlueChatApplication) : ViewModel() {
    private val db = app.database
    private val runtime = app.runtime

    val conversations: StateFlow<List<ConversationItem>> = combine(
        db.messages().observeLatestPerPeer(),
        db.nodes().observeAll(),
        db.messages().observeUnread(),
        db.messages().observePending(),
        runtime.nodes
    ) { latest, nodes, unread, pending, live ->
        val byId = nodes.associateBy { it.nodeId }
        val liveById = live.associateBy { it.nodeId }
        latest.map { m ->
            val n = byId[m.peerId]
            val l = liveById[m.peerId]
            ConversationItem(
                peerId = m.peerId,
                alias = n?.alias ?: "Usuario ${NodeIds.short(m.peerId)}",
                avatar = n?.avatar ?: 0,
                lastText = m.text,
                lastTime = m.timestamp,
                lastOutgoing = m.outgoing,
                lastStatus = if (m.outgoing) DeliveryStatus.values().getOrNull(m.status) else null,
                unread = unread.firstOrNull { it.peerId == m.peerId }?.cnt ?: 0,
                pending = pending.firstOrNull { it.peerId == m.peerId }?.cnt ?: 0,
                direct = l?.direct == true,
                hops = l?.hops ?: 0,
                blocked = n?.blocked == true
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val neighbors: StateFlow<List<NeighborInfo>> = runtime.neighbors
    val nodes: StateFlow<List<NodeInfo>> = runtime.nodes
    val stats: StateFlow<MeshStats?> = runtime.stats
    val transport: StateFlow<TransportState> = runtime.transport
    val serviceRunning: StateFlow<Boolean> = runtime.serviceRunning
    val settings: StateFlow<AppSettings> =
        app.settings.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())
}

// ============================================================================ dispositivos cercanos y malla

class NetworkViewModel(private val app: BlueChatApplication) : ViewModel() {
    private val runtime = app.runtime
    val neighbors = runtime.neighbors
    val nodes = runtime.nodes
    val stats = runtime.stats
    val transport = runtime.transport
    val serviceRunning = runtime.serviceRunning
    val settings: StateFlow<AppSettings> =
        app.settings.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    fun setRelay(v: Boolean) {
        viewModelScope.launch { app.settings.setRelay(v) }
    }

    fun addContact(nodeId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            app.database.nodes().setContact(nodeId, true)
            runtime.requestRefresh()
        }
    }

    fun removeContact(nodeId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            app.database.nodes().setContact(nodeId, false)
            runtime.requestRefresh()
        }
    }

    fun refresh() = runtime.requestRefresh()
}

// ============================================================================ chat

class ChatViewModel(private val app: BlueChatApplication, val peerId: String) : ViewModel() {
    private val db = app.database
    private val runtime = app.runtime

    val messages: StateFlow<List<MessageEntity>> =
        db.messages().observeConversation(peerId).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val peer: StateFlow<NodeEntity?> = db.nodes().observeAll()
        .map { list -> list.firstOrNull { it.nodeId == peerId } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val live: StateFlow<NodeInfo?> = runtime.nodes
        .map { list -> list.firstOrNull { it.nodeId == peerId } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val transport = runtime.transport

    private val _notice = MutableStateFlow<String?>(null)
    val notice = _notice.asStateFlow()

    fun clearNotice() { _notice.value = null }

    fun send(text: String, onSent: () -> Unit) {
        if (text.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            val r = runtime.sendText(peerId, text)
            when (r) {
                is SendResult.Queued -> launch(Dispatchers.Main) { onSent() }
                SendResult.TooLong -> _notice.value = "El mensaje es demasiado largo (máximo 600 bytes)."
                SendResult.UnknownRecipient -> _notice.value = "Este contacto aún no se ha detectado por Bluetooth; no hay claves para cifrar."
                SendResult.Blocked -> _notice.value = "Has bloqueado a este contacto."
                SendResult.Empty -> {}
                SendResult.CryptoFailure -> _notice.value = "No se pudo cifrar el mensaje."
                null -> _notice.value = "La identidad aún no está lista."
            }
        }
    }

    fun setActive(active: Boolean) {
        runtime.activePeer = if (active) peerId else null
        if (active) markRead()
    }

    fun markRead() {
        viewModelScope.launch(Dispatchers.IO) { runtime.markConversationRead(peerId) }
    }
}

// ============================================================================ contacto / verificación

class ContactViewModel(private val app: BlueChatApplication, val peerId: String) : ViewModel() {
    private val db = app.database

    val peer: StateFlow<NodeEntity?> = db.nodes().observeAll()
        .map { list -> list.firstOrNull { it.nodeId == peerId } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val live: StateFlow<NodeInfo?> = app.runtime.nodes
        .map { list -> list.firstOrNull { it.nodeId == peerId } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val myFingerprint: String = app.identity.load()?.fingerprint ?: ""

    fun fingerprintOf(n: NodeEntity): String = CryptoManager.fingerprint(n.signPub, n.dhPub)

    fun setContact(v: Boolean) = viewModelScope.launch(Dispatchers.IO) { db.nodes().setContact(peerId, v); app.runtime.requestRefresh() }
    fun setVerified(v: Boolean) = viewModelScope.launch(Dispatchers.IO) { db.nodes().setVerified(peerId, v); app.runtime.requestRefresh() }
    fun setBlocked(v: Boolean) = viewModelScope.launch(Dispatchers.IO) { app.runtime.setBlocked(peerId, v) }
    fun deleteConversation() = viewModelScope.launch(Dispatchers.IO) { db.messages().deleteConversation(peerId) }
}

// ============================================================================ ajustes

data class OwnIdentity(val nodeId: String, val fingerprint: String)

class SettingsViewModel(private val app: BlueChatApplication) : ViewModel() {
    private val repo = app.settings

    val settings: StateFlow<AppSettings> = repo.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())
    val serviceRunning = app.runtime.serviceRunning
    val transport = app.runtime.transport

    private val _identity = MutableStateFlow<OwnIdentity?>(null)
    val identity = _identity.asStateFlow()

    init {
        viewModelScope.launch(Dispatchers.IO) {
            app.identity.load()?.let { _identity.value = OwnIdentity(it.nodeId, it.fingerprint) }
        }
    }

    fun setProfile(alias: String, avatar: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            repo.setProfile(alias.trim(), avatar)
            app.runtime.updateProfile(alias.trim(), avatar)
        }
    }

    fun setTheme(t: ThemeMode) = viewModelScope.launch { repo.setTheme(t) }
    fun setBatterySaver(v: Boolean) = viewModelScope.launch { repo.setBatterySaver(v) }
    fun setRelay(v: Boolean) = viewModelScope.launch { repo.setRelay(v) }
    fun setMaxQueue(v: Int) = viewModelScope.launch { repo.setMaxQueue(v) }
    fun setMaxHops(v: Int) = viewModelScope.launch { repo.setMaxHops(v) }
    fun setNotifications(v: Boolean) = viewModelScope.launch { repo.setNotifications(v) }
    fun setNotificationPreview(v: Boolean) = viewModelScope.launch { repo.setNotificationPreview(v) }
    fun setReadReceipts(v: Boolean) = viewModelScope.launch { repo.setReadReceipts(v) }
    fun setVisible(v: Boolean) = viewModelScope.launch { repo.setVisible(v) }
}
