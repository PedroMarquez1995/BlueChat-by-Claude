package com.bluechat.mesh.service

import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.bluechat.mesh.BlueChatApplication
import com.bluechat.mesh.R
import com.bluechat.mesh.bluetooth.BleCapabilities
import com.bluechat.mesh.bluetooth.BlePermissions
import com.bluechat.mesh.bluetooth.BluetoothDiscoveryManager
import com.bluechat.mesh.bluetooth.BluetoothGattManager
import com.bluechat.mesh.data.TransportState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Servicio en primer plano (tipo connectedDevice) que mantiene viva la participación en la red.
 *
 * LIMITES REALES: Android puede detener el proceso (ahorro de batería agresivo de algunos
 * fabricantes, "Force stop", memoria). START_STICKY intenta reiniciarlo, pero no está garantizado.
 * La cola Store-and-Forward está en disco, así que no se pierde nada ya almacenado.
 */
class MeshService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var loop: Job? = null
    private var gatt: BluetoothGattManager? = null
    private var discovery: BluetoothDiscoveryManager? = null
    private var receiverRegistered = false
    private val transportMutex = Mutex()
    private var appliedBattery: Boolean? = null
    private var appliedVisible: Boolean? = null
    private var lastNotif = Triple(-1, -1, true)

    private val app get() = application as BlueChatApplication

    private val btReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != BluetoothAdapter.ACTION_STATE_CHANGED) return
            when (intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)) {
                BluetoothAdapter.STATE_ON -> scope.launch { startTransport() }
                BluetoothAdapter.STATE_OFF -> stopTransport("Bluetooth apagado. Se reanudará al encenderlo.")
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            scope.launch { app.settings.setServiceEnabled(false) }
            shutdown()
            return START_NOT_STICKY
        }
        if (!BlePermissions.hasBluetooth(this)) {
            // Sin permisos Android prohíbe el tipo connectedDevice: no se arranca.
            app.runtime.setTransportState(TransportState(error = "Faltan permisos de Bluetooth."))
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            ServiceCompat.startForeground(
                this, NotificationHelper.SERVICE_ID,
                app.notifier.serviceNotification(0, 0, true),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            )
        } catch (e: Exception) {
            // Android 12+ impide iniciar servicios en primer plano desde segundo plano en algunos casos.
            app.runtime.setTransportState(TransportState(error = "Android no permitió iniciar el servicio: ${e.message}"))
            stopSelf()
            return START_NOT_STICKY
        }
        scope.launch {
            // Tras un reinicio automático (intent nulo) respetamos lo que eligió el usuario.
            if (intent == null && !app.settings.current().serviceEnabled) {
                shutdown()
                return@launch
            }
            app.settings.setServiceEnabled(true)
            app.runtime.setServiceRunning(true)
            registerBtReceiver()
            startTransport()
            startLoop()
        }
        return START_STICKY
    }

    private fun registerBtReceiver() {
        if (receiverRegistered) return
        ContextCompat.registerReceiver(
            this, btReceiver, IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED
        )
        receiverRegistered = true
    }

    private suspend fun startTransport() = transportMutex.withLock {
        val caps = BleCapabilities.read(this)
        caps.problem()?.let {
            app.runtime.setTransportState(TransportState(running = false, error = it))
            return@withLock
        }
        stopTransportQuiet()
        app.runtime.setCanAdvertise(caps.canAdvertise)
        val engine = app.runtime.ensureEngine()
        if (engine == null) {
            app.runtime.setTransportState(TransportState(error = "Aún no existe una identidad."))
            return@withLock
        }
        val s = app.settings.current()
        appliedBattery = s.batterySaver
        appliedVisible = s.visible
        val g = BluetoothGattManager(this, engine) { engine.getConfig().maxLinks }
        val d = BluetoothDiscoveryManager(
            this,
            onDevice = { device, rssi -> g.connect(device, rssi) },
            onState = { adv, scan, err ->
                app.runtime.setTransportState(TransportState(running = true, advertising = adv, scanning = scan, error = err))
            }
        )
        gatt = g
        discovery = d
        g.start(
            onReady = { d.start(visible = s.visible && caps.canAdvertise, lowPower = s.batterySaver) },
            onError = { app.runtime.setTransportState(TransportState(running = false, error = it)) }
        )
    }

    private fun stopTransportQuiet() {
        discovery?.stop(silent = true)
        gatt?.stop()
        discovery = null
        gatt = null
    }

    private fun stopTransport(message: String?) {
        stopTransportQuiet()
        app.runtime.setTransportState(TransportState(running = false, error = message))
    }

    private fun startLoop() {
        if (loop?.isActive == true) return
        loop = scope.launch {
            var n = 0
            while (isActive) {
                val engine = app.runtime.engine.value
                val s = app.settings.current()
                if (gatt != null && (s.batterySaver != appliedBattery || s.visible != appliedVisible)) {
                    startTransport() // aplica ahorro de batería / visibilidad
                }
                engine?.tick()
                if (n % 3 == 0) gatt?.tick()
                if (engine != null) {
                    val neighbors = engine.neighbors().count { it.nodeId != null }
                    val queued = engine.stats().queued
                    val cur = Triple(neighbors, queued, s.relayEnabled)
                    if (cur != lastNotif) {
                        lastNotif = cur
                        app.notifier.updateService(neighbors, queued, s.relayEnabled)
                    }
                }
                n++
                delay(if (s.batterySaver) 10_000 else 5_000)
            }
        }
    }

    private fun shutdown() {
        loop?.cancel()
        stopTransport(null)
        app.runtime.setServiceRunning(false)
        if (receiverRegistered) {
            try { unregisterReceiver(btReceiver) } catch (_: Exception) {}
            receiverRegistered = false
        }
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        loop?.cancel()
        stopTransportQuiet()
        app.runtime.setServiceRunning(false)
        app.runtime.setTransportState(TransportState())
        if (receiverRegistered) {
            try { unregisterReceiver(btReceiver) } catch (_: Exception) {}
            receiverRegistered = false
        }
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.bluechat.mesh.action.STOP"

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, MeshService::class.java))
        }

        fun stop(context: Context) {
            context.startService(Intent(context, MeshService::class.java).setAction(ACTION_STOP))
        }
    }
}
